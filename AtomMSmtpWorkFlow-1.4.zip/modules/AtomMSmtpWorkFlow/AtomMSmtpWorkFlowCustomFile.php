<?php 
class AtomMSmtpWorkFlowCustom{
        function postEnable(){
                $validator = new Settings_AtomMSmtpWorkFlow_LicenseManager_Model();

                $licensekey_records = $validator->getRecordDetails();
                $license_key = $licensekey_records['msmtpworkflow_license_key'];
                $license_key = Vtiger_Functions::fromProtectedText($license_key);
                $is_validate = $validator->apiCall($license_key,'validate');
                $is_active = $validator->apiCall($license_key,'is_active');
                if($is_validate['iskeyvalid'] && $is_active['iskeyactive']){
                        $this->createCustomWorkflow();
                        $this->addHeaderJs();
                }
        }
	function preUninstall(){
		global $adb;
                $this->removeHeaderJs();
                $this->removeLicenseSettingsLink();
                $this->removeCustomWorkflow();
	}
        function postDisable(){
                global $adb;
                $this->removeHeaderJs();
                $this->removeLicenseSettingsLink();
                $this->removeCustomWorkflow();
        }
         public function LicenseSettingsLink(){
                global $adb;
                $name = "Atom MSmtp Workflow License Manager";
                $description = "Configure License Manager";
                $linkto = "index.php?parent=Settings&module=AtomMSmtpWorkFlow&view=LicenseManagerEdit";
                $result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
                //error_log( "SELECT * FROM vtiger_settings_field WHERE name= '{$name}'" , 3 , "/tmp/AtomsMSmtp.log" );
                $num_rows = $adb->num_rows($result);
                if($num_rows == 0) {
                        $otherSettingsBlock = $adb->pquery('SELECT * FROM vtiger_settings_blocks WHERE label=?', array('LBL_OTHER_SETTINGS'));
                        $otherSettingsBlockCount = $adb->num_rows($otherSettingsBlock);

                        if ($otherSettingsBlockCount > 0) {
                                $blockid = $adb->query_result($otherSettingsBlock, 0, 'blockid');
                                $sequenceResult = $adb->pquery("SELECT max(sequence) as sequence FROM vtiger_settings_blocks WHERE blockid=?", array($blockid));
                                if ($adb->num_rows($sequenceResult)) {
                                        $sequence = $adb->query_result($sequenceResult, 0, 'sequence');
                                }
                        }

                        $fieldid = $adb->getUniqueID('vtiger_settings_field');
                                                                                                                                                                                                                      $adb->pquery("INSERT INTO vtiger_settings_field(fieldid, blockid, name, iconpath, description, linkto, sequence, active , pinned) VALUES(?,?,?,?,?,?,?,?,?)", array($fieldid, $blockid, $name, '',$description, $linkto, $sequence++, 0 , 1));

                        $adb->pquery("UPDATE vtiger_settings_field_seq SET id = ?",array($fieldid));
                        //echo("$name Settings Added <br/>");
                }else{
                        //echo("$name Already present <br/>");                   
                } 
        }                                         

        public function addHeaderJs(){
            global $adb;
            $linklabel = "AtomMSmtpHeader";
            $linkurl = "layouts/v7/modules/AtomMSmtpWorkFlow/resources/AtomMSmtpHeader.js";
            $result = $adb->pquery("SELECT * FROM vtiger_links WHERE linklabel = ? AND linkurl = ? ",array($linklabel,$linkurl));
            $num_rows = $adb->num_rows($result);
            if($num_rows == 0){
                $sql = $adb->pquery('Select MAX(linkid) as id from vtiger_links',array());
                $linkid = $adb->query_result($sql,'0','id');
                $linkid++;                                                                                                                                                                                    $adb->pquery("INSERT INTO `vtiger_links`( `linkid`,`tabid`, `linktype`, `linklabel`, `linkurl`, `linkicon`, `sequence`, `handler_path`, `handler_class`, `handler`, `parent_link`) VALUES (?,?,?,?,?,?,?,?,?,?,?)",array($linkid,3,'HEADERSCRIPT',$linklabel,$linkurl,'','0','','','',NULL));
            }
        }
        public function createCustomWorkflow(){
            global $adb;
            include_once( 'modules/com_vtiger_workflow/VTTaskManager.inc' );
            $taskType = "VTMSmtpTask";
            $result = $adb->pquery("SELECT * FROM com_vtiger_workflow_tasktypes where tasktypename=?",array($taskType));
            if( $adb->num_rows($result) == 0 ) {
                $taskType = array("name"=>$taskType, "label"=>"Send Mail Multiple SMTP", "classname"=>$taskType, "classpath"=>"modules/AtomMSmtpWorkFlow/tasks/$taskType.php", "templatepath"=>"modules/AtomMSmtpWorkFlow/Tasks/$taskType.tpl", "modules"=>$defaultModules, "sourcemodule"=>'AtomMSmtpWorkFlow');
                VTTaskType::registerTaskType($taskType);
            }
        }
        public function removeHeaderJs(){
            $linklabel = "AtomMSmtpHeader";
            $linkurl = "layouts/v7/modules/AtomMSmtpWorkFlow/resources/AtomMSmtpHeader.js";
            Vtiger_Link::deleteLink(3,'HEADERSCRIPT',$linklabel,$linkurl);
        }
        public function removeCustomWorkflow(){
            global $adb;
            $taskType = "VTMSmtpTask";
            $result = $adb->pquery("SELECT * FROM com_vtiger_workflow_tasktypes WHERE tasktypename= ?",array($taskType));
            $num_rows = $adb->num_rows($result);
            if($num_rows == 1) {
                $adb->pquery("DELETE FROM com_vtiger_workflow_tasktypes WHERE tasktypename = ?", array($taskType));
            }
        }
        public function removeLicenseSettingsLink(){
            global $adb;
            $name = "Atom MSmtp Workflow License Manager";      
            $description = "Configure License Manager";     
            $linkto = "index.php?parent=Settings&module=AtomMSmtpWorkFlow&view=LicenseManagerEdit";
            $result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
            $num_rows = $adb->num_rows($result);
            if($num_rows == 1) {
                $adb->pquery("DELETE FROM vtiger_settings_field WHERE name = ?", array($name));
            } 

        }
}

?>

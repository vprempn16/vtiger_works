<?php 
class Settings_AtomMSmtpWorkFlow_LicenseManager_Model extends Vtiger_Base_Model{

    private $api_url = 'https://demo.gamma.atomlines.com/wp/wpstore/wp-json/license-managersettings/v1/validate';


    public function getLicenseViewUrl() {
        global $site_URL;
        return $site_URL.'index.php?module=AtomMSmtpWorkFlow&parent=Settings&view=LicenseManagerEdit';
    }

    public function apiCall($license_key,$action) {
        if($license_key != '' && $action != ''){
            global $site_URL;
            $url = 'https://demo.gamma.atomlines.com/wp/wpstore/wp-json/atomlicense-manageraddon/v1/' .$action. '?license_key=' . urlencode($license_key).'&site_Url='.urlencode($site_URL);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    'Content-Type: application/json',
            ]);
            $response = curl_exec($ch);
            if (curl_errno($ch)) {
                return [
                    'status' => false,
                    'error' => curl_error($ch),
                ];
            }
            curl_close($ch);
            return json_decode($response, true);
        }else{
            return ["License key or Action empty"];
        }
    }
    public function getRecordDetails($id=""){
        global $adb;
        $columns = Array("msmtpworkflow_license_key");
        $return = Array();

        $result = $adb->pquery("SELECT * FROM atom_license_manager",array());
        $num_rows = $adb->num_rows($result);
        if($num_rows > 0){
            for($i=0;$i<$num_rows; $i++){
                $meta_key = $adb->query_result($result,$i,'meta_key');
                $meta_value = $adb->query_result($result,$i,'meta_value');
                $return[$meta_key] =  $meta_value;
            }
        }
        return $return;

    }
    public function ActivateSettings(){
        $this->addHeaderJs();
        $this->createCustomWorkflow();
    }
    public function addHeaderJs(){
        global $adb;
        $linklabel = "AtomMSmtpHeader";   
        $linkurl = "layouts/v7/modules/AtomMSmtpWorkFlow/resources/AtomMSmtpHeader.js";      
        $result = $adb->pquery("SELECT * FROM vtiger_links WHERE linklabel = ? AND linkurl = ? ",array($linklabel,$linkurl));   
        $num_rows = $adb->num_rows($result); 
        if($num_rows == 0){      
            $sql = $adb->pquery('Select MAX(linkid) as id from vtiger_links',array());
            $linkid = $adb->query_result($sql,'0','id');
            $linkid++;                                                                                                                                                                                    $adb->pquery("INSERT INTO `vtiger_links`( `linkid`,`tabid`, `linktype`, `linklabel`, `linkurl`, `linkicon`, `sequence`, `handler_path`, `handler_class`, `handler`, `parent_link`) VALUES (?,?,?,?,?,?,?,?,?,?,?)",array($linkid,3,'HEADERSCRIPT',$linklabel,$linkurl,'','0','','','',NULL));
        }
    }
    public function createCustomWorkflow(){
        global $adb;
        include_once( 'modules/com_vtiger_workflow/VTTaskManager.inc' );
        $taskType = "VTMSmtpTask"; 
        $result = $adb->pquery("SELECT * FROM com_vtiger_workflow_tasktypes where tasktypename=?",array($taskType));
        if( $adb->num_rows($result) == 0 ) {
            $taskType = array("name"=>$taskType, "label"=>"Send Mail Multiple SMTP", "classname"=>$taskType, "classpath"=>"modules/AtomMSmtpWorkFlow/tasks/$taskType.php", "templatepath"=>"modules/AtomMSmtpWorkFlow/Tasks/$taskType.tpl", "modules"=>$defaultModules, "sourcemodule"=>'AtomMSmtpWorkFlow');       
            VTTaskType::registerTaskType($taskType);           
        }       
    }
    public function DeactivateSettings(){
        $this->removeHeaderJs();
        $this->removeCustomWorkflow();
    }
    public function removeHeaderJs(){
        $linklabel = "AtomMSmtpHeader";
        $linkurl = "layouts/v7/modules/AtomMSmtpWorkFlow/resources/AtomMSmtpHeader.js";
        Vtiger_Link::deleteLink(3,'HEADERSCRIPT',$linklabel,$linkurl);
    }
    public function removeCustomWorkflow(){
        global $adb;
        $taskType = "VTMSmtpTask";
        $result = $adb->pquery("SELECT * FROM com_vtiger_workflow_tasktypes WHERE tasktypename= ?",array($taskType));
        $num_rows = $adb->num_rows($result);
        if($num_rows == 1) {
            $adb->pquery("DELETE FROM com_vtiger_workflow_tasktypes WHERE tasktypename = ?", array($taskType));
        }
    }
}

?>


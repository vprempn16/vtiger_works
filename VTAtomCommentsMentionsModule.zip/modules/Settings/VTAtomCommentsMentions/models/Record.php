<?php
class Settings_VTAtomCommentsMentions_Record_Model extends Vtiger_Base_Model{

}
?>

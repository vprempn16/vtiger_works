<?php
class CustomInventoryPDF{
	function vtlib_handler($moduleName, $eventType) {
		if ($moduleName == 'CustomInventoryPDF') {
			$db = PearDatabase::getInstance();
			if ($eventType == 'module.disabled') {
				$this->removeHeaderJs();
			} else if ($eventType == 'module.enabled') {
				$this->insertHeaderLink();
			} else if( $eventType == 'module.preuninstall' ) {

			} else if( $eventType == 'module.postinstall' ) {
				$this->insertHeaderLink();
			} else if( $eventType == 'module.postupdate' ) {
				$this->insertHeaderLink();
			}
		}
	}
	function insertHeaderLink(){
                global $adb;
                $linklabel = "CustomInventoryPDF";
                $linkurl = "layouts/v7/modules/CustomInventoryPDF/resources/CustomInventoryPDF.js";
                $result = $adb->pquery("SELECT * FROM vtiger_links WHERE linklabel = ? AND linkurl = ? ",array($linklabel,$linkurl));
                $num_rows = $adb->num_rows($result);
                if($num_rows == 0){
                        $moduleName='Home';
                        $moduleInstance = Vtiger_Module::getInstance($moduleName);
                        $moduleInstance->addLink('HEADERSCRIPT', $linklabel,$linkurl);
                }
        }
	public function removeHeaderJs(){
		$linklabel = "CustomInventoryPDF";
		$linkurl = "layouts/v7/modules/CustomInventoryPDF/resources/CustomInventoryPDF.js";
		Vtiger_Link::deleteLink( 0 , 'HEADERSCRIPT' , $linklabel , $linkurl );
	}
} 



?>

<?php 

/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/

//ini_set('display_errors','on'); version_compare(PHP_VERSION, '5.5.0') <= 0 ? error_reporting(E_WARNING & ~E_NOTICE & ~E_DEPRECATED) : error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);   // DEBUGGING

class Settings_AtomCurrencyConverter_UpdateCurrency_Action extends  Settings_Vtiger_Basic_Action {

	public function process(Vtiger_Request $request) {
		global $current_user,$adb;
		$response = new Vtiger_Response();
		$result = false;
		$message = 'failed';
		$directUpdate = $request->get('direct_update');
		$frequencyMap = ['onehour' => '1 hour','12hours' => '12 hours','daily' => '1 day','monthly' => '1 month'];
		$sql = $adb->pquery('SELECT * FROM atom_currency_configuration',array());
		if($adb->num_rows($sql) > 0){
			for($i=0;$i<$adb->num_rows($sql);$i++){
				$meta_key = $adb->query_result($sql,$i,'meta_key');
				$meta_value = $adb->query_result($sql,$i,'meta_value');
				$config[$meta_key] =  $meta_value;
			}
			if($config){
				$result =  AtomCurrencyConverter_Record_Model::updateCurrency($config,$frequencyMap,$directUpdate);
				if($result){
					$message='success';
				}
			}
		}
		$response->setResult(array('success'=>$result,'message'=>$message));
		$response->emit();
	}
}

?>

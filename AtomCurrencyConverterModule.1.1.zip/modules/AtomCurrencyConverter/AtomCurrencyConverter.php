<?php
class AtomCurrencyConverter{

        function vtlib_handler($moduleName, $eventType) {
                global $adb;
                if($eventType == 'module.postinstall') {
                        $this->SettingsLink();
                        $this->createTable();
			$this->createScheduler();
                } else if($eventType == 'module.enabled') {
                        $this->SettingsLink();
                } else if($eventType == 'module.disabled') {
                } else if($eventType == 'module.preuninstall') {
                        // TODO Handle actions when this module is about to be deleted.
                } else if($eventType == 'module.preupdate') {
                        // TODO Handle actions before this module is updated.
                } else if($eventType == 'module.postupdate') {
                        $this->SettingsLink();
			$this->createTable();
			$this->createScheduler();
                }
        }
	function createTable(){
		global $adb;
		$tbl_name = "atom_currency_configuration";
		$table_sql[$tbl_name] = "CREATE TABLE `{$tbl_name}` (
			`id` int NOT NULL AUTO_INCREMENT,
			`meta_key` varchar(255) NOT NULL,
			`meta_value` longtext NOT NULL,
			PRIMARY KEY (`id`))";
		foreach($table_sql as $table_name => $sql){
			$table_exist_result = $adb->pquery("SHOW TABLES LIKE '$table_name'",array());

			$num_rows = $adb->num_rows($table_exist_result);
			if($num_rows == 0){
				$adb->pquery($sql,array());
			}
		}
		$adb->pquery("UPDATE vtiger_tab SET customized = 0 WHERE name = 'SRColor'",array());
	}
	function SettingsLink(){
                global $adb;
                $name = "Atom Currency Converter";
                $description ="";
                $linkto = "index.php?parent=Settings&module=AtomCurrencyConverter&view=Edit";
                $result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
                $num_rows = $adb->num_rows($result);
                if($num_rows == 0) {
                        $otherSettingsBlock = $adb->pquery('SELECT * FROM vtiger_settings_blocks WHERE label=?', array('LBL_CONFIGURATION'));
                        $otherSettingsBlockCount = $adb->num_rows($otherSettingsBlock);

                        if ($otherSettingsBlockCount > 0) {
                                $blockid = $adb->query_result($otherSettingsBlock, 0, 'blockid');
                                $sequenceResult = $adb->pquery("SELECT max(sequence) as sequence FROM vtiger_settings_blocks WHERE blockid=?", array($blockid));
                                if ($adb->num_rows($sequenceResult)) {
                                        $sequence = $adb->query_result($sequenceResult, 0, 'sequence');
                                }
                        }

                        $fieldid = $adb->getUniqueID('vtiger_settings_field');                                                                                                                                        $adb->pquery("INSERT INTO vtiger_settings_field(fieldid, blockid, name, iconpath, description, linkto, sequence, active , pinned) VALUES(?,?,?,?,?,?,?,?,?)", array($fieldid, $blockid, $name, '',$description, $linkto, $sequence++, 0 , 1));

                        $adb->pquery("UPDATE vtiger_settings_field_seq SET id = ?",array($fieldid));
                }
	}
	function createScheduler(){
		global $adb;
		$Scheduledlabel = "Call for update currency rate";
		$Scheduledresult = $adb->pquery( "select * from vtiger_cron_task where name = ?" , array( $Scheduledlabel ) );
		if( $adb->num_rows( $Scheduledresult ) <= 0 ){
			$vtiger_cron_task_last_id = $adb->pquery( "select * from vtiger_cron_task order by id desc limit 1" , array() );
			if( $adb->num_rows( $vtiger_cron_task_last_id ) > 0)
			{
				$id = $adb->query_result( $vtiger_cron_task_last_id , 0 , 'id' );
				$id++;
				$adb->pquery( "insert into vtiger_cron_task ( id , name , handler_file , frequency , laststart , lastend , status , module , sequence , description ) values ( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? )" , array( $id , $Scheduledlabel , "modules/AtomCurrencyConverter/cron/AtomConverter.php" , 900 , 0 , 0 , 1 , "AtomCurrencyConverter" , $id , $Scheduledlabel ) );
			}
		}
	}
}



?>

<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/

class AtomCurrencyConverter_Record_Model extends Vtiger_Base_Model {

	public function updateCurrency($config,$frequencyMap,$direct_update=false){
		global $adb;
		if($config){
			$frequency = $config['frequency'];
			if (isset($frequencyMap[$frequency])) {
				$formattedFrequency = $frequencyMap[$frequency];
				$apikey = $config['api_key'];
				$lastApiCall = strtotime($config['lastapi_cal']);
				$nextApiCallTime = strtotime("+$formattedFrequency", $lastApiCall);
				$currentTime = time();
				$currentMonthYear = strtoupper(date('M-Y'));
				if($currentTime >= $nextApiCallTime || $direct_update == true){
					$currencyData = AtomCurrencyConverter_Record_Model::getCurrecyRate($apikey);
					if($currencyData != ''){
						if(isset($currencyData['data'])) {
							foreach($currencyData['data'] as $currencyCode => $rate) {
								$adb->pquery('UPDATE vtiger_currency_info SET conversion_rate = ? WHERE currency_code = ?',array($rate,$currencyCode));
							}
						}
						$addCount = AtomCurrencyConverter_Record_Model::addMonthCount($currentMonthYear);
						$lastapi_cal = AtomCurrencyConverter_Record_Model::lastApiCalEntry();
						return true;
					}
				}
			}
		}else{
			return false;
		}
	}
	public function lastApiCalEntry(){
		global $adb;
		$checklastapi_calexist = $adb->pquery("SELECT * FROM atom_currency_configuration WHERE meta_key=?",array('lastapi_cal'));
		$num_row = $adb->num_rows($checklastapi_calexist);
		$meta_value  = date('Y-m-d H:i:s');
		if($num_row > 0){
			$adb->pquery("UPDATE atom_currency_configuration SET meta_value = ? WHERE meta_key=?",array($meta_value,'lastapi_cal'));
		}else{
			$adb->pquery("INSERT INTO atom_currency_configuration (meta_key, meta_value) VALUES(?,?)",array('lastapi_cal',$meta_value));
		}
		return true;
	}
	public function addMonthCount($currentMonthYear){
		global $adb;
		$newCount = 0;
		$monthQue = $adb->pquery("SELECT * FROM atom_currency_configuration WHERE meta_key=?",array($currentMonthYear));
		if($adb->num_rows($monthQue) > 0) {
			$currentCount = (int)$adb->query_result($monthQue,0,'meta_value');
			$newCount = $currentCount + 1;
			$adb->pquery("UPDATE atom_currency_configuration SET meta_value = ? WHERE meta_key=?",array($newCount,$currentMonthYear));
		}else{
			$adb->pquery("INSERT INTO atom_currency_configuration (meta_key, meta_value) VALUES(?,?)",array($currentMonthYear,1));	
		}
		return true;
	}	
	public function checkApiKey($apikey){
		$return = false;
		if($apikey != ''){
			$apiUrl = 'https://api.freecurrencyapi.com/v1/latest?apikey='.$apikey;
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $apiUrl);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$response = curl_exec($ch);
			$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			if (curl_errno($ch)) {
				return false;
			}
			if($response) {
				if($httpCode == 200){
					$return = true;
				}else{
					$return = false;	
				}
			}
			curl_close($ch);
		}
		return $return;
	}	
	public function getCurrecyRate($apikey){
		global $adb;
		$currencyData = array();
		$currency_res = $adb->pquery("SELECT * FROM vtiger_currency_info WHERE deleted =0",array());
		if($adb->num_rows($currency_res) > 0){
                        for($i=0;$i<$adb->num_rows($currency_res);$i++){
                                $currency_code = $adb->query_result($currency_res,$i,'currency_code');
				$defaultid = $adb->query_result($currency_res,$i,'defaultid');
                                $currencyData[] =  $currency_code;
				if($defaultid == -11){
					$base_currency = $currency_code;
				}
			}
		}
		$currenciesParam = implode('%2C', $currencyData);
		$apiUrl = 'https://api.freecurrencyapi.com/v1/latest?apikey='.$apikey.'&currencies='.$currenciesParam.'&base_currency='.$base_currency;	
		//$apiUrl = "https://api.freecurrencyapi.com/v1/latest?apikey={$apikey}&currencies={$currenciesParam}&base_currency={$base_currency}";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $apiUrl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                curl_close($ch);
                if (curl_errno($ch)) {
                      return false;
                }
                if($response) {
                        $currency = json_decode($response, true);
                    	//$currency['data'] = array('AUD'=>1.4991202494,'EUR'=>0.9017701301,'USD'=>1);
                }
                return $currency;
        }	

}


?>

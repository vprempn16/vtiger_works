<?php
//ini_set('display_errors','on'); version_compare(PHP_VERSION, '5.5.0') <= 0 ? error_reporting(E_WARNING & ~E_NOTICE & ~E_DEPRECATED) : error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);   // DEBUGGING
//chdir('../../../');
include_once "config.inc.php";
//include_once 'include/Webservices/Relation.php';
include_once 'includes/main/WebUI.php';
include_once 'vtlib/Vtiger/Module.php';
include_once 'vtlib/Vtiger/Module.php';
include_once 'vtlib/Vtiger/Functions.php';
class AtomConverter {
        function __construct(){
                $this->updateCurrencyRate();
        }
	function updateCurrencyRate(){
		global $adb;
		$frequencyMap = ['onehour' => '1 hour','12hours' => '12 hours','daily' => '1 day','monthly' => '1 month'];
		$sql = $adb->pquery('SELECT * FROM atom_currency_configuration',array());
		if($adb->num_rows($sql) > 0){
			for($i=0;$i<$adb->num_rows($sql);$i++){
				$meta_key = $adb->query_result($sql,$i,'meta_key');
                                $meta_value = $adb->query_result($sql,$i,'meta_value');
                                $config[$meta_key] =  $meta_value;
			}
			$config['api_key'] = Vtiger_Functions::fromProtectedText($config['api_key']);
			if($config) {
				$result =  AtomCurrencyConverter_Record_Model::updateCurrency($config,$frequencyMap);
			}
		}
	}
}

$Cron = new AtomConverter();


?>

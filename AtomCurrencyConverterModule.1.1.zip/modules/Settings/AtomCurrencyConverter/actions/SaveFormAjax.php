<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/

//ini_set('display_errors','on'); version_compare(PHP_VERSION, '5.5.0') <= 0 ? error_reporting(E_WARNING & ~E_NOTICE & ~E_DEPRECATED) : error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);   // DEBUGGING

class Settings_AtomCurrencyConverter_SaveFormAjax_Action extends  Settings_Vtiger_Basic_Action {

        public function process(Vtiger_Request $request) {
		global $current_user,$adb;
		$response = new Vtiger_Response();
		$data = $request->get('formData');
		parse_str($data,$formData);
		$frequency = $formData['frequency'];	
		$api_key = $formData['api_key'];	
		$result = false;
		$message = "Failed";
		if($api_key == ''){
			$api_key = $this->getValue('api_key');
		}
		$api_key = Vtiger_Functions::fromProtectedText($api_key);
		$checkApiKey = AtomCurrencyConverter_Record_Model::checkApiKey($api_key);
		if(!$checkApiKey){
			$message = 'Please Enter Valid Api key';
                        $result = false;
		}
		if($frequency && $checkApiKey){
			if($formData['api_key'] == ''){
				$formData['api_key'] = $api_key;
			}
			$formData['api_key'] = Vtiger_Functions::toProtectedText($formData['api_key']);
			foreach($formData as $key => $value){
				if($key == 'frequency' || $key == 'api_key'){
					$this->setVelue($key,$value);
				}
			}
			$message = 'Success';
			$result = true;
		}
		$response->setResult(array('success'=>$result,'message'=>$message));
		$response->emit();

	}
	function getValue($metakey){
		global $current_user,$adb;
		$value = false;
                $sql = $adb->pquery("SELECT * FROM atom_currency_configuration where meta_key=?",array($metakey));
		if($adb->num_rows($sql) > 0){
			$value = $adb->query_result($sql,0,'meta_value');
		}
		return $value;
	}
	function setVelue($metakey,$metavalue){
		 global $current_user,$adb;
		 $sql =  $adb->pquery("SELECT * FROM atom_currency_configuration where meta_key=? ",array($metakey));
		 if($adb->num_rows($sql) > 0){
		 	$adb->pquery("UPDATE atom_currency_configuration SET meta_value = ?  WHERE  meta_key = ?",array($metavalue,$metakey));	
		 }else{
		 	$adb->pquery("INSERT INTO atom_currency_configuration (meta_key, meta_value) VALUES (?,?)",array($metakey,$metavalue));
		 }
		 return true;
	}

}

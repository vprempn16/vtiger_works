<?php 
class ServiceCompetencyHandler{
    function handleEvent($eventName, $entityData) {
        global $adb,$currentUser;
        $recordid = $entityData->getId();
        $currentUser = Users_Record_Model::getCurrentUserModel();
        $entityDelta = new VTEntityDelta();
        if ($eventName == 'vtiger.entity.beforesave') {
                    $moduleName = $entityData->getModuleName();
            if($moduleName == 'ServiceCompetency'){
                $roleMapping = array(1 =>'Not Started',2 => 'Learner',3 => 'Implementer',4 =>'Reviewer',5 => 'Project Manager');
                $recordId = $entityData->getId();
                $consultantrating = $entityData->get('consultantrating');
                $consultantrole = $roleMapping[$consultantrating];
                if($consultantrole != ''){
                    $entityData->set('consultantrole',$consultantrole);
                }
                $approvalstatus = $entityData->get('approvalstatus');
                if($approvalstatus == 'Approval'){
                    $entityData->set('scstatus','Active');
                }
                if($approvalstatus == 'Declined Approval' || $approvalstatus == 'Pending Approval' ){
                    $entityData->set('scstatus','Inactive');
                }
                $old_values = $entityDelta->getOldEntity($moduleName, $recordId);
                if (!$entityData->isNew()) {
                    $modBasicRes = $adb->pquery("SELECT id FROM vtiger_modtracker_basic WHERE crmid = ? ORDER BY id DESC LIMIT 1", [$recordId]);
                    $old_datas = [];
                    if ($adb->num_rows($modBasicRes) > 0) {
                        $lastId = $adb->query_result($modBasicRes, 0, 'id');
                        $modDetailRes = $adb->pquery("SELECT fieldname, prevalue, postvalue FROM vtiger_modtracker_detail WHERE id = ?", [$lastId]);
                        while ($row = $adb->fetch_array($modDetailRes)) {
                            $old_datas[$row['fieldname']] = [
                                'prevalue' => $row['prevalue'],
                                'postvalue' => $row['postvalue']
                            ];
                        }
                    }
                    $oldApproval = $old_values->get('approvalstatus');
                    $oldRating   = $old_values->get('consultantrating');
                    $oldStatus   = isset($old_datas['scstatus']['prevalue']) ? $old_datas['scstatus']['prevalue'] : $old_values->get('scstatus');

                    $isApprovalChanged = ($oldApproval != $approvalstatus);
                    $isRatingChanged   = ($oldRating != $consultantrating);

                    if ($approvalstatus == 'Declined Approval' && $isApprovalChanged && $currentUser->isAdminUser()) {
                        $oldApproval = isset($old_datas['approvalstatus']['prevalue']) ? $old_datas['approvalstatus']['prevalue'] : $old_values->get('approvalstatus');
                        $oldRating = isset($old_datas['consultantrating']['prevalue']) ? $old_datas['consultantrating']['prevalue'] : $old_values->get('consultantrating');
                        $entityData->set('consultantrating', $oldRating);
                        $entityData->set('scstatus', $oldStatus);
                        $consultantrole = $roleMapping[$oldRating];
                        $entityData->set('consultantrole',$consultantrole);
                    }
                    if ($isRatingChanged) {
                        $entityData->set('approvalstatus', 'Pending Approval');
                        $entityData->set('scstatus', 'Inactive');
                    }
                }else{
                    $entityData->set('approvalstatus', 'Pending Approval');
                    $entityData->set('scstatus', 'Inactive');
                }
            }
        }
        if($eventName == 'vtiger.entity.aftersave'){
            $moduleName = $entityData->getModuleName();
            $requestData = $_POST;
            if($moduleName == "ServiceCompetency" && $currentUser->isAdminUser() ){
                    $recordId = $entityData->getId();
                    $approvalstatus = $entityData->get('approvalstatus');
                    $isapprovalStatusChanged = $entityDelta->hasChanged($moduleName, $recordId, 'approvalstatus');
                    if($approvalstatus == 'Declined Approval' && $isapprovalStatusChanged){
                        $oldRating = $entityDelta->getOldValue($moduleName,$entityData->getId(),'consultantrating');
                        $scModel = Vtiger_Record_Model::getInstanceById($recordId, $moduleName);
                        $scModel->set('id', $recordId);
                        $scModel->set('mode', 'edit');
                        $scModel->set('consultantrating', $oldRating);
                        $scModel->save();
                    }
            }
            if (in_array($moduleName, ['SalesOrder'])) {
                $totalProductsCount = $requestData['totalProductCount'];
                $inventoryData = [];
                $productLists = [];
                foreach ($requestData as $key => $value) {
                    if (preg_match('/^hdnProductId(\d+)$/', $key, $matches) && $key != "hdnProductId0"  ) {
                        $rowNum = $matches[1];
                        if (isset($requestData["lineItemType{$rowNum}"]) && $requestData["lineItemType{$rowNum}"] == "Services" ) {
                            $productLists[] = $value;
                        }
                    }
                }
                $inventoryData = [];
                $atomglobalpricehike = $requestData['global_pricehike'];
                foreach ($requestData as $key => $value) {
                    if( preg_match('/^consultantname(\d+)$/', $key, $matches)){
                        $consultantList[] = $value;
                    }
                    if( preg_match('/^servicecompetencyid(\d+)$/', $key, $matches)){
                        $compentencyidList[] = $value; 
                    }
                }
                foreach ($productLists as $index => $productId) {
                    $inventoryData[] = [
                        'productid' => $productId,
                        'consultantname' => $consultantList[$index] ?? '',
                        'servicecompetencyid'=> $compentencyidList[$index] ?? '',
                    ];
                }
                $query = "SELECT lineitem_id, productid, sequence_no FROM vtiger_inventoryproductrel WHERE id = ? ORDER BY sequence_no";
                $result = $adb->pquery($query, [$recordid]);
                $inventoryIndex = 0;
                while ($row = $adb->fetch_array($result)) {
                    $lineItemId = $row['lineitem_id'];
                    $productId = $row['productid'];
                    $sequenceNo = $row['sequence_no'];
                    if (!isset($inventoryData[$inventoryIndex])) {
                        continue;
                    }
                    $variant = $inventoryData[$inventoryIndex];
                    if ($variant['productid'] == $productId) {
                        $consultantname = $variant['consultantname'] ?? null;
                        $servicecompetencyid = $variant['servicecompetencyid'] ?? null;
                        $updateQuery = "UPDATE vtiger_inventoryproductrel SET consultantname =? , servicecompetencyid =? WHERE id = ? AND lineitem_id = ?";
                        $adb->pquery($updateQuery, [$consultantname,$servicecompetencyid,$recordid, $lineItemId]);
                        $inventoryIndex++;
                    }
                }
                if (empty($productLists)) {
                    $query = "
                        SELECT *
                        FROM vtiger_inventoryproductrel AS rel
                        WHERE rel.id = ? 
                        ORDER BY rel.sequence_no
                        ";
                    $result = $adb->pquery($query, [$recordid]);
                    while ($row = $adb->fetch_array($result)) {
                        $productId    = $row['productid'];
                        $sequence_no  = $row['sequence_no'];
                        $consultant   = $row['consultantname'];
                        $serviceComp  = $row['servicecompetencyid'];
                        $listPrice    = $row['listprice'] ?? '';
                        $qty          = $row['quantity'] ?? '';

                        $productLists[]     = $productId;
                        $consultantList[]   = $consultant;
                        $compentencyidList[]= $serviceComp;
                        $idx = (int)$sequence_no;
                        $requestData["consultantname{$idx}"]       = $consultant;
                        $requestData["listPrice{$idx}"]            = $listPrice;
                        $requestData["servicecompetencyid{$idx}"]  = $serviceComp;
                        $requestData["hdnProductId{$idx}"]         = $productId;
                        $requestData["qty{$idx}"]                  = $qty;
                    }
                }

                $i = 1;
                $wsId = $entityData->getId();
                $entityDelta = new VTEntityDelta();
                $sostatus = $entityData->get('sostatus');
                $isStatusChanged = $entityDelta->hasChanged($moduleName, $wsId, 'sostatus');
                $oldStatus = $entityDelta->getOldValue($moduleName,$entityData->getId(),'sostatus');
                if ($sostatus != 'Approved' && !$isStatusChanged ) {
                    return; // stop if SO not approved

                }
                if($sostatus == 'Created' || $sostatus == 'Delivered' || $sostatus == 'Cancelled'){
                    return;
                }
                foreach($productLists as $index => $serviceid){
                    $servieModel = Vtiger_Record_Model::getInstanceById($serviceid,"Services");
                    if($servieModel && $requestData["consultantname{$i}"] != ''){
                        $assigned_user_id = $requestData["consultantname{$i}"];
                        $subject = (!empty($requestData['subject'])) ? $requestData['subject'] : $entityData->get('subject');
                        $startdate = (!empty($requestData['startdate'])) ? $requestData['startdate'] : $entityData->get('startdate');
                        $duedate = (!empty($requestData['duedate'])) ? $requestData['duedate'] : $entityData->get('duedate');
                        $sc_related_to = $requestData["record"];
                        if($sc_related_to == ''){
                            $sc_related_to = $entityData->getId();
                        }
                        $checkServiceContractsql = $adb->pquery("SELECT * FROM `vtiger_servicecontracts` INNER JOIN vtiger_crmentity ON  vtiger_crmentity.crmid = vtiger_servicecontracts.servicecontractsid WHERE vtiger_crmentity.deleted = ? AND vtiger_servicecontracts.servicename = ? AND vtiger_servicecontracts.sc_related_to = ? AND vtiger_crmentity.smownerid = ?",array(0,$serviceid,$sc_related_to,$assigned_user_id));
                        if($adb->num_rows($checkServiceContractsql) == 0){
                            $recordModel = Vtiger_Record_Model::getCleanInstance("ServiceContracts");
                            $subject = $subject .' - '. $servieModel->get('servicename');
                            $recordModel->set('mode','');
                            $recordModel->set('subject',$subject);
                            $recordModel->set('start_date',$startdate);
                            $recordModel->set('end_date',$duedate);
                            $recordModel->set('assigned_user_id',$assigned_user_id);
                            $recordModel->set('total_units',$requestData["qty{$i}"]);
                            $recordModel->set('contract_status','In Progress');
                            $recordModel->set('permandaycost',$requestData["listPrice{$i}"]);
                            $recordModel->set('servicename',$requestData["hdnProductId{$i}"]);
                            $recordModel->set('sc_related_to',$sc_related_to);
                            $recordModel->save();
                        }
                    }
                    $i++;
                }
            }
            if($moduleName == 'ServiceContracts'){
                $consultantname = $requestData['assigned_user_id'];
                $servicename = $requestData['servicename'];
                $serviceContractRecordId = $entityData->getId();
                $this->createTicketsForServiceContract($serviceContractRecordId);
            }
        }
    }
    private function createTicketsForServiceContract($serviceContractRecordId) {
        global $adb;
        // Get ServiceContract info
        $scResult = $adb->pquery("SELECT smownerid, servicename, sc_related_to
                FROM vtiger_servicecontracts 
                INNER JOIN vtiger_crmentity ce ON ce.crmid = servicecontractsid AND ce.deleted = 0
                WHERE servicecontractsid = ?", [$serviceContractRecordId]);
        if ($adb->num_rows($scResult) == 0) return;

        $consultantId = $adb->query_result($scResult, 0, 'smownerid');
        $serviceId = $adb->query_result($scResult, 0, 'servicename');
        $salesOrderId = $adb->query_result($scResult, 0, 'sc_related_to');

        if (empty($consultantId) || empty($serviceId) || empty($salesOrderId)) return;

        // Get Sales Order start and due date
        $soRes = $adb->pquery("SELECT startdate, duedate FROM vtiger_salesorder WHERE salesorderid = ?", [$salesOrderId]);
        if ($adb->num_rows($soRes) == 0) return;

        $startDate = $adb->query_result($soRes, 0, 'startdate');
        $dueDate   = $adb->query_result($soRes, 0, 'duedate');

        $start = new DateTime($startDate);
        $end   = new DateTime($dueDate);

        if ($end < $start) return;

        // Get ticketcount from ServiceCompetency (for same consultant + service)
        $compRes = $adb->pquery("
                SELECT tickets_count
                FROM vtiger_servicecompetency
                INNER JOIN vtiger_crmentity ce ON ce.crmid = servicecompetencyid AND ce.deleted = 0
                WHERE servicename = ? AND consultantname = ?", [$serviceId, $consultantId]);
        if ($adb->num_rows($compRes) == 0) return;

        $ticketCount = (int)$adb->query_result($compRes, 0, 'tickets_count');
        if ($ticketCount <= 0) return;

        // Get all dates between start and end
        $dates = [];
        $period = new DatePeriod($start, new DateInterval('P1D'), (clone $end)->modify('+1 day'));
        foreach ($period as $date) {
            $dates[] = $date->format('Y-m-d');
        }

        // Find consultant's already used ticket dates
        $usedRes = $adb->pquery("
                SELECT DATE(cf_792) AS tdate
                FROM vtiger_ticketcf tt
                INNER JOIN vtiger_crmentity ce ON tt.ticketid = ce.crmid
                WHERE ce.deleted = 0 AND ce.smownerid = ?", [$consultantId]);
        $usedDates = [];
        while ($row = $adb->fetch_array($usedRes)) {
            $usedDates[] = $row['tdate'];
        }

        // Determine free dates within range
        $freeDates = array_diff($dates, $usedDates);

        $finalDates = [];
        // Use all free dates first
        foreach ($freeDates as $d) {
            $finalDates[] = $d;
            if (count($finalDates) >= $ticketCount) break;
        }

        // If not enough free dates, reuse some used dates
        if (count($finalDates) < $ticketCount) {
            $remaining = $ticketCount - count($finalDates);
            $fillDates = array_slice($usedDates ?: $dates, 0, $remaining);
            $finalDates = array_merge($finalDates, $fillDates);
        }

        // Double check we have enough dates
        if (empty($finalDates)) return;

        // Create tickets
        foreach ($finalDates as $ticketDate) {
            try {
                $ticketModel = Vtiger_Record_Model::getCleanInstance('HelpDesk');
                $ticketModel->set('mode', '');
                $ticketModel->set('ticket_title', 'Service Ticket - ' . $ticketDate);
                $ticketModel->set('assigned_user_id', $consultantId);
                $ticketModel->set('ticketstatus', 'Open');
                $ticketModel->set('ticketpriorities', 'Low');
                $ticketModel->set('cf_792', $ticketDate);
                $ticketModel->save();

                $ticketId = $ticketModel->getId();

                // Insert relation entry between ServiceContract and Ticket
                $checkRel = $adb->pquery(
                        "SELECT 1 FROM vtiger_crmentityrel
                        WHERE crmid = ? AND relcrmid = ? AND module = ? AND relmodule = ?",
                        [$serviceContractRecordId, $ticketId, 'ServiceContracts', 'HelpDesk']
                        );

                if($adb->num_rows($checkRel) == 0) {
                    $adb->pquery(
                            "INSERT INTO vtiger_crmentityrel (crmid, module, relcrmid, relmodule) VALUES (?, ?, ?, ?)",
                            [$serviceContractRecordId, 'ServiceContracts', $ticketId, 'HelpDesk']
                            );
                }
            } catch (Exception $e) {
                error_log("[ServiceContracts Ticket Creation] " . $e->getMessage());
            }
        }
    }
}



?>

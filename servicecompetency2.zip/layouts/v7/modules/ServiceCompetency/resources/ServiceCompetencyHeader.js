jQuery.Class("ServiceCompetencyHeader_Js",{},{

     addColumnInPageLoad: function (){
        var currentModule = app.getModuleName();
        if (["SalesOrder"].indexOf(currentModule) === -1 || app.getViewName() != 'Edit') {
            return;
        }
        var clonerow = jQuery('#lineItemTab tr.lineItemCloneCopy');
        var cloneTd = clonerow.find('td').eq(1);
        var cloneQuantityTd = clonerow.find('td').eq(2);
        var headTr = jQuery('#lineItemTab tbody tr').eq(0);
        var headTd = headTr.find('td').eq(2);
        var consultantTd = clonerow.find(".consultant-details");
        var headQuantityTd = headTr.find('td').eq(2);
        var consultantHeader = headTr.find(".consultant-header");
        if(consultantHeader.length === 0){
            headTd.after('<td class="consultant-header" ><strong>Consultant Name </strong></td>');
        }
        if(consultantTd.length === 0) {
            cloneQuantityTd.after('<td style="width:300px;" class="consultant-details"></td>');
        }
        var thisInstance = this;
        var recordId = jQuery("input[name='record']").val();
        if(recordId === ""){
            var url = window.location.href;
            var params = new URLSearchParams(url.split('?')[1]);
            recordId = ['invoice_id', 'quote_id', 'salesorder_id', 'purchaseorder_id','record'].map(p => new URLSearchParams(window.location.search).get(p)).find(Boolean);
        }

        if(!recordId) {
            return;
        }
        var params = {
            module: "ServiceCompetency",
            action: "GetLineItemDetails",
            record: recordId,
        }; 
        app.helper.showProgress();
        app.request.post({ data: params }).then(
        function(err, data) {
            app.helper.hideProgress();
                if (err === null && data.success === true) {
                    var lineItemDetails = JSON.parse(data.lineItemDetails);
                    jQuery('#lineItemTab tr.lineItemRow').each(function (index, tr) {
                        var seqNo = index + 1;
                        var row = jQuery(tr);
                        var lineItemRow = jQuery(this);
                        var rowNum = lineItemRow.attr("data-row-num"); // Get row number (1,2,3...)
                        if(rowNum != undefined && rowNum != 0){
                        var quantityTd = lineItemRow.find('td').eq(2);
                        if (lineItemRow.find(".atompricehike-td").length === 0) {
                            quantityTd.after('<td class="consultant-details"></td>'); 
                        }
                        var consultantCell = row.find('.consultant-details');
                        consultantCell.html(''); // Clear
                        if (lineItemDetails[seqNo] && lineItemDetails[seqNo].consultants_list && lineItemDetails[seqNo].module == "Services" ){
                            var consultantData = lineItemDetails[seqNo].consultants_list;
                            var selectedVal = lineItemDetails[seqNo].consultantname || '';
                            var  servicecompetencyid = lineItemDetails[seqNo].servicecompetencyid || '';
                            var select = jQuery('<select id="consultantname" class="consultant-select form-control" name="consultantname'+ seqNo +'"><option value="">Select an option</option></select>');
                            var inputField = jQuery('<input type="hidden" name="servicecompetencyid'+ seqNo +'" id="servicecompetencyid" value=0>');
                            var roleLabel = $('<br><span class="consultant-role" style="margin-left:10px; font-weight:bold; color:#333;"></span>').text('Role: ' + lineItemDetails[seqNo].consultantrole);
                            consultantData.forEach(function (opt) {
                                    var option = jQuery('<option>').val(opt.id).text(opt.name).attr('data-servicecompetencyid',opt.servicecompetencyid);
                                    if (opt.id == selectedVal) {
                                        option.attr('selected', 'selected');
                                    }
                                    select.append(option);
                            });
                            consultantCell.append(select);
                            consultantCell.append(inputField);
                            consultantCell.find("select#consultantname").after(roleLabel);
                            select.select2({ width: '100%', placeholder: 'Select Consultant' });    
                        }
                        }
                    });
                }                
        });
     },
     showConsultantInDetail : function(){
        var thisInstance = this;
            var url = window.location.href;
            var params = new URLSearchParams(url.split('?')[1]);
            var currentModule = app.getModuleName();
            if (["SalesOrder"].indexOf(currentModule) === -1  || app.getViewName() != 'Detail' && params.get('requestMode') != 'full'){
                return;
            }
            var headTr = jQuery('.lineItemsTable tbody tr').eq(0);
            var headTd = headTr.find('td').eq(0);
            var quantityHead = headTr.find('td').eq(1);
            if(headTr.find('.pricehike-header').length === 0){
                quantityHead.after('<td class="consultant-header" ><strong>Consultant Name </strong></td>');
            }
            var recordId = jQuery("input#recordId").val();
            if (!recordId) {
                return;
            }
            var params = {
                module: "ServiceCompetency",
                action: "GetLineItemDetails",
                record: recordId,
            };
            app.helper.showProgress();
            app.request.post({ data: params }).then(
                function(err, data) {
                app.helper.hideProgress();
                if (err === null && data.success === true) {
                    var lineItemDetails = JSON.parse(data.lineItemDetails);
                                        var i = 0;
                    jQuery(".lineItemTableDiv table.lineItemsTable tbody tr").each(function() {
                            var lineItemRow = jQuery(this);
                            var rowNum = lineItemRow.attr("data-row-num");
                            if(i != 0){
                                var consultantnameTd = lineItemRow.find(".consultantname-value");

                                if (consultantnameTd.length === 0) {
                                    lineItemRow.find("td").eq(1).after('<td class="consultantname-value"></td>');
                                    consultantnameTd = lineItemRow.find(".consultantname-value");
                                }

                                if(lineItemDetails[i]){
                                        matchedData = lineItemDetails[i];
                                }
                                var tdfieldValue = lineItemRow.find("td").eq(0).find('a.fieldValue');
                                var productUrl = tdfieldValue.attr('href');
                                var productParams = new URLSearchParams(productUrl.split('?')[1]);
                                var productRecordId = productParams.get('record');
                                if (productRecordId == matchedData.productid) {
                                console.log(matchedData);
                                    var consultantName = matchedData.consultantName || '';
                                    var roleLabel = $('<br><br><span class="consultant-role" style=" font-weight:bold; color:#333;"></span>').text('Role: ' + matchedData.consultantrole);
                                    if(consultantName != ''){
                                        var previewHtml = `<span class="consult-value">${consultantName}</span>`;
                                        consultantnameTd.prepend(previewHtml);
                                        consultantnameTd.find('.consult-value').after(roleLabel);
                                    }
                                }
                            }       
                        i++;
                    });       
                }
            });
     },
     changeSellingPrice : function(){
        var thisInstance =  this;
        $(document).on('change', 'select#consultantname', function () {
            var id = $(this).find("option:selected").val();
            var servicecompetencyid = $(this).find("option:selected").attr('data-servicecompetencyid');
            var $row = $(this).closest('tr');
            $row.find('.consultant-role').remove();
            var recordId = $row.find('input.selectedModuleId').val();
            $row.find('input#servicecompetencyid').val(servicecompetencyid);
            if(id != ''){
                var params = {
                    module: "ServiceCompetency",
                    action: "GetRoleAndPrice",
                    record: recordId,
                    user_id : id,
                }; 
                app.request.get({ data: params }).then(function(err, data) {
                    if (err === null && data.success === true) {
                        var details = JSON.parse(data.details);
                        $row.find('input.listPrice').val(details.selling_price).blur();
                         var roleLabel = $('<br><span class="consultant-role" style="margin-left:10px; font-weight:bold; color:#333;"></span>')
                        .text('Role: ' + details.consultantrole);
                        $row.find('select#consultantname').after(roleLabel);
                    }
                });
                
            }
        });
     },
     registerEvents : function(){
        this.addColumnInPageLoad();
        this.showConsultantInDetail();
        this.changeSellingPrice();
     }
});
jQuery(document).ready(function(e){
        var instance = new ServiceCompetencyHeader_Js();
        instance.registerEvents();
        $(document).ajaxComplete(function( event,xhr,settings ){
            if (settings.hasOwnProperty("url") ){
                var url =settings.url;
                if(url != ''){
                    var params = new URLSearchParams(url.split('?')[1]);
                    var module =  params.get('module');
                    var requestMode = params.get('requestMode');
                    var view = params.get('view');
                    if(requestMode == 'full' && view == 'Detail'){
                                instance.showConsultantInDetail();
                    }
                }
            }

        });
});


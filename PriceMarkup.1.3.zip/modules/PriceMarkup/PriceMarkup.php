<?php
class PriceMarkup{
    function vtlib_handler($moduleName, $eventType) {
        if ($moduleName == 'PriceMarkup') {
            $db = PearDatabase::getInstance();
            include_once 'modules/PriceMarkup/PriceMarkupCustom.php';
            $PriceMarkupCustom = new PriceMarkupCustom();
            if ($eventType == 'module.disabled') {
                $PriceMarkupCustom->postDisable();
            } else if ($eventType == 'module.enabled') {
                    $PriceMarkupCustom->postEnable();
            } else if( $eventType == 'module.preuninstall' ) {
                $PriceMarkupCustom->postDisable();
            } else if( $eventType == 'module.postinstall' ) {
                $PriceMarkupCustom->postInstall();
            } else if( $eventType == 'module.postupdate' ) {
               $PriceMarkupCustom->postUpdate();
            }
        }
    }
}

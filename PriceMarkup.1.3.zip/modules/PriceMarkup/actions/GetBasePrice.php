<?php
class PriceMarkup_GetBasePrice_Action extends Vtiger_Action_Controller {
    public function process(Vtiger_Request $request) {
        global $adb;
        $moduleName = $request->get('module');
        $recordId = $request->get('record');
        $currentModel = Vtiger_Record_Model::getInstanceById($recordId);
   	 if (!$recordId) {
            $response = new Vtiger_Response();
            $response->setResult(['success' => false, 'message' => 'No record ID found']);
            $response->emit();
            return;
	 }
	$baseprice = $currentModel->get('unit_price'); 	
	$response = new Vtiger_Response();
        $response->setResult([
            'success' => true,
            'baseprice' => $baseprice,
        ]);
        $response->emit(); 
    }
}

<?php 

class Settings_ServiceCompetency_Record_Model extends  Vtiger_Base_Model {

    public function getMenuItem() {
        $menuItem = Settings_Vtiger_MenuItem_Model::getInstance('Role Pricing');
        return $menuItem;
    }
    public function getRecordDetails(){
        global $adb;
        $retun = Array();
        $result = $adb->pquery("SELECT * FROM atom_role_pricing",array( ));
        $num_rows = $adb->num_rows($result);
        if($num_rows > 0){
            for($i=0;$i<$num_rows;$i++){
                $options = $adb->query_result($result,$i,'meta_value');
                $key = $adb->query_result($result,$i,'meta_key');
                $return[$key] = $options;
            }
        }
        return $return;

    } 
    
}

<?php 
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

class Settings_AtomsMSmtp_DeleteModule_Action extends Settings_Vtiger_Basic_Action {

	public function process(Vtiger_Request $request) {
		global $adb;

		try {
			$moduleName = $request->getModule();

			// ✅ 1. Delete the module instance
			$moduleInstance = Vtiger_Module::getInstance($moduleName);
			if ($moduleInstance) {
				$moduleInstance->delete();
			}

			// ✅ 2. Delete all entries from vtiger_atoms_msmtp
			$adb->pquery("DELETE FROM vtiger_atoms_msmtp", []);

			// ✅ 3. Return success response
			$response = new Vtiger_Response();
			$response->setResult([
				'success' => true,
				'message' => vtranslate('AtomMSmtp module uninstalled successfully.', $moduleName)
			]);
			$response->emit();
		} catch (Exception $e) {
			$response = new Vtiger_Response();
			$response->setError('Uninstallation Failed: ' . $e->getMessage());
			$response->emit();
		}
	}
}


?>


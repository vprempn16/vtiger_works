<?php

class Settings_AtomsMSmtp_serverDeleteAjax_Action extends Settings_Vtiger_Basic_Action {

        public function process(Vtiger_Request $request) {
                global $current_user,$adb;
                $response = new Vtiger_Response();
		$serverid = $request->get('serverid');
                try{
			$adb->pquery("DELETE FROM vtiger_atoms_msmtp WHERE id=?",array($serverid));		
                        $response->setResult('OK');
                }catch(Exception $e) {
                        $response->setError($e->getCode(), $e->getMessage());
                }
                $response->emit();
        }
}
?>

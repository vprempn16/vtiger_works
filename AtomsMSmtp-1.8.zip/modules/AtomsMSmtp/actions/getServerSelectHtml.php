<?php

class AtomsMSmtp_getServerSelectHtml_Action extends Vtiger_Action_Controller {

	public function process(Vtiger_Request $request) {
		global $adb , $current_user ;
		$return = '';
        $success =  false;
        $response = new Vtiger_Response();
		$current_user_id = $current_user->id;
		$taskType = $request->get('taskType');
		$result = $adb->pquery("SELECT * FROM vtiger_atoms_msmtp WHERE config_type = ?",array('public'));		
		$num_rows = $adb->num_rows($result);
		$systemresult = $adb->pquery( "SELECT * FROM vtiger_systems where server_type = ? limit 1" , array( "email" ) );
		$systemnumrows = $adb->num_rows( $systemresult );

		if($num_rows > 0){
			if($taskType  == 'VTEmailTask'){
				$html  = '<div class="row form-group"><div class="col-sm-6 col-xs-6"><div class="row"><div class="col-sm-3 col-xs-3"><span>Select Mail Server<span class="redColor">*</span></span></div><div class="col-sm-8 col-xs-8">';
			}else{
				$html  = '<div class="row "><div class="col-lg-12"><div class="col-lg-2"><span>Select Mail Server<span class="redColor">*</span></span></div><div class="col-lg-6">';
			}
			$html .= '<select data-rule-required ="true" name="serverMSId" id="serverMSId">';
			$html .= '<option value="">Select an option</value>';
			if( $systemnumrows > 0 ) {
				$server_username = $adb->query_result($systemresult,0,'server_username');
				$html .= '<option value="default">'.vtranslate( "Default" , "Vtiger" )." (".$server_username. ")".'</value>';		
			}
			for($i=0;$i<$num_rows;$i++){
				$server_username = $adb->query_result($result,$i,'server_username');
				$server_name = $adb->query_result( $result , $i , "name" );
				$server_id = $adb->query_result($result,$i,'id');
				$sharedusers = Zend_Json::decode( decode_html ( $adb->query_result( $result , $i , "sharedusers" ) ) );
				if(!empty($sharedusers)){
					if( in_array( $current_user_id , $sharedusers ) ) {
						$html .= '<option value="'.$server_id.'">'.$server_name." (".$server_username. ")".'</value>';
					}
				}
			}
			$html .= '</select>';
			if($taskType  == 'VTEmailTask'){
				 $html .= '</div></div></div><div class="col-sm-5 col-xs-5"></div></div>';
			}else{
				$html .= '</div><div class="col-lg-4"></div></div></div>';
			}
			$return = $html;		
            $success = true;
		}
        $validator = new Settings_AtomsMSmtp_LicenseManager_Model();

        $licensekey_records = $validator->getRecordDetails();
        $license_key = $licensekey_records['smtp_api_key'];
        $license_key = Vtiger_Functions::fromProtectedText($license_key);
        $maskedKey = substr($license_key, 0, 4) . str_repeat('*', strlen($license_key) - 8) . substr($license_key, -4);
        $is_validate = $validator->apiCall($license_key,'validate');
        $is_active = $validator->apiCall($license_key,'is_active');

        if(!$is_validate['iskeyvalid']){
            $success = false;
            $return = '';
        }
        if(!$is_active['iskeyactive']){
            $success = false;
            $return = '';
        }
        $res = array('success'=>$success,'mailServerHtml'=> $return);
        $response->setResult($res);                 
        $response->emit();
	}
}
?>

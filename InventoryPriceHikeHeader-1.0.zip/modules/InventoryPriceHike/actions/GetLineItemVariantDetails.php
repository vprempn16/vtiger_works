<?php 
class InventoryPriceHike_GetLineItemVariantDetails_Action extends Vtiger_Action_Controller {
    public function process(Vtiger_Request $request) {
        global $adb;
        $recordId = $request->get('record');
        $conversionRate = $conversionRateForPurchaseCost = 1;
        if (!$recordId) {
            $response = new Vtiger_Response();
            $response->setResult(['success' => false, 'message' => 'No record ID found']);
            $response->emit();
            return;
        }
        $query = "SELECT lineitem_id, productid,sequence_no ,atomglobalpricehike FROM vtiger_inventoryproductrel WHERE id = ?";
        $result = $adb->pquery($query, [$recordId]);
        $variantDetails = [];
        $listPriceValuesList = $listPricesList = array();
        while ($row = $adb->fetch_array($result)) {
            $id = $row['lineitem_id'];
            $sequence_no = $row['sequence_no'];
            $productid = $row['productid'];
            $recordModel = Vtiger_Record_Model::getInstanceById($productid);
            //$listPriceList[$productid] = $recordModel->get('unit_price');
            $priceDetails = $recordModel->getPriceDetails();
            foreach ($priceDetails as $currencyDetails) {
                if ($currencyId == $currencyDetails['curid']) {
                    $conversionRate = $currencyDetails['conversionrate'];
                }
            }
            $listPricesList[$productid] = (float)$recordModel->get('unit_price') * (float)$conversionRate;
            $listPriceValuesList[$productid]   = $recordModel->getListPriceValues($recordModel->getId()); 
            $variantDetails[$sequence_no] = [
                'productid' => $row['productid'],
                'lineItemId' => $row['lineitem_id'],
                'pricehike' => $row['atompricehike'],
                'globalpricehike' => $row['atomglobalpricehike'],
                'listPrice' => $listPricesList[$productid],
                'listpricevalues'       => $listPriceValuesList[$productid],
            ];
            $variantDetails['globalpricehike'] = $row['atomglobalpricehike'];
        }

        $response = new Vtiger_Response();
        $response->setResult([
            'success' => true,
            'globalpricehike' => $variantDetails['globalpricehike'],
            'variantDetails' => json_encode($variantDetails),
        ]);
        $response->emit();
    }
}

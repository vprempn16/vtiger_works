<?php
class InventoryPriceHikeHandler extends VTEventHandler{
    function handleEvent($eventName, $entityData) {
        global $adb;
        $recordid = $entityData->getId();
        if ($eventName == 'vtiger.entity.aftersave') {
            $moduleName = $entityData->getModuleName();
            $requestData = $_POST;
            if (in_array($moduleName, ['Invoice', 'SalesOrder', 'Quotes','PurchaseOrder'])) {
                $totalProductsCount = $requestData['totalProductCount'];
                $inventoryData = [];
                $productLists = [];
                foreach ($requestData as $key => $value) {
                    if (preg_match('/^hdnProductId(\d+)$/', $key, $matches) && $key != "hdnProductId0"  ) {
                        $rowNum = $matches[1];
                        if (isset($requestData["lineItemType{$rowNum}"]) && $requestData["lineItemType{$rowNum}"] == "Products" || $requestData["lineItemType{$rowNum}"] == "Services" ) {
                            $productLists[] = $value;
                        }
                    }
                }
                $inventoryData = [];
                $atomglobalpricehike = $requestData['global_pricehike'];
                foreach ($requestData as $key => $value) {
                    if( preg_match('/^atomsorgprice(\d+)$/', $key, $matches)){
                        $orgpriceList[] = $value;
                    }
                
                }

                foreach ($productLists as $index => $productId) {
                    $inventoryData[] = [
                        'productid' => $productId,
                        'atomorgprice' => $orgpriceList[$index] ?? '',
                    ];
                }
                $query = "SELECT lineitem_id, productid, sequence_no FROM vtiger_inventoryproductrel WHERE id = ? ORDER BY sequence_no";
                $result = $adb->pquery($query, [$recordid]);

                $inventoryIndex = 0; 
                while ($row = $adb->fetch_array($result)) {
                    $lineItemId = $row['lineitem_id'];
                    $productId = $row['productid'];
                    $sequenceNo = $row['sequence_no'];

                    if (!isset($inventoryData[$inventoryIndex])) {
                        continue;
                    }

                    $variant = $inventoryData[$inventoryIndex]; 

                    if ($variant['productid'] == $productId) {  
                        $atomorgprice = $variant['atomorgprice'];

                        $updateQuery = "UPDATE vtiger_inventoryproductrel SET atomorgprice=?, atomglobalpricehike=? WHERE id = ? AND lineitem_id = ?";
                        $adb->pquery($updateQuery, [$atomorgprice,$atomglobalpricehike,$recordid, $lineItemId]);
                        $inventoryIndex++; 
                    }
                } 
            }
        }
    }
}

<?php 
class InventoryPriceHikeCustom{
    function postEnable(){
        $this->addHeaderJs();
        $this->eventhandler();
    }
    function postInstall(){
        $this->addHeaderJs();
        $this->eventhandler();
        $this->createInventoryFields();
    }
    function postDisable(){
        global $adb;
        $this->removeHeaderJs();
        $this->unregisterEventHandler();
    }
    public function addHeaderJs(){
	global $adb;
        $linklabel = "InventoryPriceHikeHeader";
        $linkurl = "layouts/v7/modules/InventoryPriceHike/resources/InventoryPriceHikeHeader.js";
        Vtiger_Link::addLink( 3 , 'HEADERSCRIPT' , $linklabel , $linkurl );
    }
    public function removeHeaderJs(){
        $linklabel = "InventoryPriceHikeHeader";
        $linkurl = "layouts/v7/modules/InventoryPriceHike/resources/InventoryPriceHikeHeader.js";
        Vtiger_Link::deleteLink( 3 , 'HEADERSCRIPT' , $linklabel , $linkurl );
    }
    public function eventhandler(){
        $Vtiger_Utils_Log = true;
        include_once('vtlib/Vtiger/Event.php');
        Vtiger_Event::register('Vtiger', 'vtiger.entity.aftersave', 'InventoryPriceHikeHandler', 'modules/InventoryPriceHike/InventoryPriceHikeHandler.php');
    }
    public function unregisterEventHandler(){
        global $adb;
        $Vtiger_Utils_Log = true;
        include_once('include/events/VTEventsManager.inc');
        $class = 'InventoryPriceHikeHandler';    
        $result  = $adb->pquery('SELECT * FROM vtiger_eventhandlers WHERE handler_class =?',array($class));
        if($adb->num_rows($result) > 0){
            $eventsManager = new VTEventsManager($adb);
            $result = $eventsManager->unregisterHandler($class);
            return "success";
        }else{
            return "handler not found";
        }
    }
    public function createInventoryFields(){
        $modules = ["Invoice","SalesOrder","Quotes","PurchaseOrder"];
        foreach($modules as $module){
            $moduleName = $MODULENAME = $module;
            $moduleInstance = Vtiger_Module::getInstance($moduleName);
            $blockInstance = new Vtiger_Block();
            $blockInstance->label = 'LBL_ITEM_DETAILS';
            $blockInstance = $blockInstance->getInstance($blockInstance->label,$moduleInstance);
            $field5 = Vtiger_Field::getInstance("atomorgprice",$moduleInstance);
            if(!$field5 ){
                $field5 = new Vtiger_Field();
                $field5->name = "atomorgprice";
                $field5->label = "Original Price";
                $field5->column = "atomorgprice";
                $field5->columntype = 'VARCHAR(250)';
                $field5->table  ='vtiger_inventoryproductrel';
                $field5->uitype = 1;
                $blockInstance->addField($field5);
            }
            $field6 = Vtiger_Field::getInstance("atomglobalpricehike",$moduleInstance);
            if(!$field6 ){
                $field6 = new Vtiger_Field();
                $field6->name = "atomglobalpricehike";
                $field6->label = "Global Price Hike";
                $field6->column = "atomglobalpricehike";
                $field6->columntype = 'VARCHAR(250)';
                $field6->table  ='vtiger_inventoryproductrel';
                $field6->uitype = 1;
                $blockInstance->addField($field6);
            }
        }
    }
}


?>

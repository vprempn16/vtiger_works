<?php
class Contacts_SendCustomMail_Action extends Vtiger_Action_Controller {

        function checkPermission(Vtiger_Request $request) {
                return;
        }

	public function process(Vtiger_Request $request) {

		global $adb, $HELPDESK_SUPPORT_EMAIL_ID;
		$subject  = $_POST['mailSubject'];
		$contactId = $_POST['contactIds'];
		$getMailAddress = $adb->pquery("select email from vtiger_contactdetails where contactid in ($contactId)");
		while ( $row = $adb->fetch_array($getMailAddress) ) {
			$mailAddress[] = $row['email'];
		}
		
		$recordId = explode(",",$contactId);
		$mailAddresses = implode(',' ,$mailAddress);	
		
		$module = "Contacts";
		$to_email = $mailAddresses;
		$contents = "Hai, you have a event ";
		for ( $i = 0 ; $i < count($recordId) ; $i ++ ) {
			getMergedDescription($contents, $recordId[$i], 'Users');
		}
		send_mail($module, $to_email, $from_name, $from_email, $subject, $contents, $cc = '', $bcc = '', $attachment = '', $emailid='', $logo = '', $useGivenFromEmailAddress = false);

		echo true;
	}
}

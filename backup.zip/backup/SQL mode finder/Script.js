// Show SQL mode in Settings Page

$(document).find('#Settings_sideBar_LBL_OTHER_SETTINGS div a').each(function(){
        if( $(this).text() == 'Status der SQL Datenbank'){
                var obj = this;
                $.ajax({
                        type: 'GET',
                        datatype: 'JSON',
                        url: 'index.php?module=BALetters&action=getSQLmode',
                        success: function(response){
                                var data = JSON.parse(response);
                                if( data.sql_mode == "NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION" || data.sql_mode == '' ){
                                        var greenDot = '<div style="height: 15px; float: right; width: 15px;background-color: green;border-radius: 51%;">&nbsp;</div>';
                                        $(obj).after(greenDot);
                                }
                        }
                });
        } 
});
~   

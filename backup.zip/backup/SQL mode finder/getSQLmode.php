<?php
class BALetters_getSQLmode_Action extends Vtiger_BasicAjax_Action{
   
	function checkPermission(Vtiger_Request $request) {
		return;
	} 
    
    
    public function process(Vtiger_Request $request) {
		global $adb;
		$getSQLmode = $adb->pquery("select @@sql_mode");	
		$sql_mode['sql_mode'] =$adb->query_result($getSQLmode , 0 , '@@sql_mode');
		echo json_encode($sql_mode);
			
	}
    
}

<html>
     <head>
        <title> Portal </title>
	    <link rel="stylesheet" href="public/css/bootstrap.min.css">
        <link rel="stylesheet" href="public/css/signin.css">
	    <script src="public/js/jquery.min.js"></script>
	    <script src="public/js/popper.min.js"></script>	
	    <script src="public/js/ba_script.js"></script>
     </head> 
     <body class="text-center">
		<form class="form-signin" action='resetPassword' method='POST' id="resetPassword" >

<button class="btn btn-primary" type="button" disabled id = "loading" style = "display:none">
  <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
  Loading...
</button>

            <?php 
            if(isset($data['message'])) {
                $class_name = 'success';
                if(!$data['status']) {
                    $class_name = 'danger';
                }
                echo "<div class='alert alert-{$class_name}'> {$message} </div>";
            }
            ?>
            <input name="resetPortalId" value="<?php echo $_GET['password_reset_id']; ?>" type="hidden">
	      	<img class="mb-4" src="public/images/logo.gif" alt="Logo">
	      	<h1 class="h3 mb-3 font-weight-normal">Crate New Password</h1>
            <small id="password_validation" class="form-text" style="color:red ; display:none;"> Please fill input fields </small>
	      	<label for="new_password" class="sr-only">New Password</label>
      		<input type="password" id="new_password" name="new_password" class="form-control" placeholder="New Password" required autofocus style="margin-bottom: 10px;">
            <label for="confirm_password" class="sr-only">New Password</label>
            <input type="password" id="confirm_password" name="confirm_password" class="form-control" placeholder="Confirm Password" required autofocus style="margin-bottom: 10px;">
            <small id="password_match" class="form-text" style="color:red ; display:none;"> Password does not match. </small>
            <small id="password_valid" class="form-text" style="color:red ; display:none;"> Password should contain caps, small, number and special character. </small>
            <button class="btn btn-lg btn-primary btn-block reset_password" type="button"> Reset Password </button>
         </form>
     </body>
</html>
<script>
    $(document).on('click' , '.reset_password' , function(){

        var newPassword = $('#new_password').val();
        var confirmPassword = $('#confirm_password').val();
        if( confirmPassword != '' && newPassword != '' ) {
            $('#password_validation').hide();
            re = /^(?=\S*[a-z])(?=\S*[A-Z])(?=\S*\d)(?=\S*[^\w\s])\S{6,}$/;
            if( re.test(newPassword) ) {
                $('#password_valid').hide();
                $('#password_validation').hide();
                $('#password_match').hide();
           
                if( newPassword == confirmPassword ){
                    $('#resetPassword').submit();
                } else {
                    $('#password_match').show(); 
                }
           } else {
               $('#password_valid').show();
           }    
        } else {
           $('#password_validation').show(); 
        }   
    });
</script>

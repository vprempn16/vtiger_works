<?php

class BACustomerPortal_GeneratePassword_Action extends Vtiger_Action_Controller {
    public function checkPermission() {
        return true;
    }

    public function process(Vtiger_Request $request) {
        global $adb, $site_URL ;
        $recordId = $_POST['recordId'];
        $password = $_POST['password'];
        $process = $_POST['process'];
        if( $process == 'generate') {
            $adb->pquery("update vtiger_contactdetails set password = ? where contactid = ?" , array( $password , $recordId ) );
        } 

    }

}


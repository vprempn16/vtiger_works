$(document).ready(function(){
    applyButton();
});
$(document).ajaxComplete(function(){
    applyButton();
});
function applyButton() {
    var moduleName = app.getModuleName();
    var view = app.getViewName();
    if (moduleName == "Contacts" && view == "Detail" ) { 
        if( $('#generate_password').length == 0) {
            $('#Contacts_detailView_fieldValue_password').append('<button style="float: right;" class="btn" id="generate_password"> Generate Password </button>');
        }
        if( $('#send_portal_info').length == 0 ) {
            $('#Contacts_detailView_fieldValue_email').append('<button style="float: right;" class="btn" id="send_portal_info"> Send Portal info </button>');
        }
    }
}
$(document).on('click' , '#generate_password' ,function(e) {
    e.preventDefault();	
    var record_id = app.getRecordId();
    var chars = "abcdefghijklmnopqrstuvwxyz!@#$%^&*()-+<>ABCDEFGHIJKLMNOP1234567890";
    var pass = "";
    for (var x = 0; x < 8; x++) {
        var i = Math.floor(Math.random() * chars.length);
        pass += chars.charAt(i);
    }     
    $('#Contacts_detailView_fieldValue_password span').text(pass);
    $.ajax({
        type: 'POST',
        data: {
                'password': pass,
                'recordId': record_id,
                'process': 'generate',
            },

        datatype: 'JSON',
        url: 'index.php?module=BACustomerPortal&action=GeneratePassword',
        success: function(response){
            console.log(response);
        }
    });
});
$(document).on('click' , '#send_portal_info' ,function(e) {
    e.preventDefault();	
    var record_id = app.getRecordId();
    $.ajax({
        type: 'POST',
        data: {
                'recordId': record_id,
                'process': 'sendMail',
            },

        datatype: 'JSON',
        url: 'https://demo.blackant.io/jens/test/test_vtiger/ba_api/welcomeToPortal',
        success: function(response){
            console.log(response);
        }
    });    

});

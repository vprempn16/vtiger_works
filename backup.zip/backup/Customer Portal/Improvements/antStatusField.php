<?php

$Vtiger_Utils_Log = true;
include_once('vtlib/Vtiger/Menu.php');
include_once('vtlib/Vtiger/Module.php');

$module = new Vtiger_Module();
$module = $module->getInstance('BACustomerPortal');

// Create new Block into Lead Module and your drop-down added into new block
$block1 = new Vtiger_Block();
$block1->label = 'LBL_BACUSTOMERPORTAL_INFORMATION';
$block1 = $block1->getInstance($block1->label,$module);

$field0 = new Vtiger_Field();
$field0->name = 'message_status';
$field0->table = $module->basetable;
$field0->label = 'Status';
$field0->column = $field0->name;
$field0->columntype = 'VARCHAR(128)';
$field0->uitype = 15 ;
$field0->setPicklistValues( Array ('Unprocessed' , 'In progress' , 'Waiting for a response' , 'Done'));
$field0->typeofdata = 'V~O~LE~128';
$block1->addField($field0);


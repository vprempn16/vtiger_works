<?php
  
include_once('vtlib/Vtiger/Module.php');
$moduleInstance = Vtiger_Module::getInstance('Contacts');
$accountsModule = Vtiger_Module::getInstance('BACustomerPortal');
$relationLabel = 'Portal';
$moduleInstance->setRelatedList(
$accountsModule, $relationLabel, Array('add')
);
global $adb;
$getRelatedId = $adb->pquery("SELECT relation_id FROM vtiger_relatedlists where label = 'portal' ORDER BY relation_id desc limit 1");
$relatedId = $adb->query_result($getRelatedId , 0 , 'relation_id');
$adb->pquery('UPDATE vtiger_relatedlists SET name = "get_portal_updates" WHERE relation_id ='.$relatedId);

echo 'Relation Added Successfully ';


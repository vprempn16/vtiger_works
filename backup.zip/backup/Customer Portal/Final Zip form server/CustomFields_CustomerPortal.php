<?php
include_once('vtlib/Vtiger/Module.php');

// Module Instance 
$moduleName='Documents';
$moduleInstance = Vtiger_Module::getInstance($moduleName);
// Add new Field 
$blockInstance = Vtiger_Block::getInstance('LBL_NOTE_INFORMATION', $moduleInstance); 
$fieldInstance = new Vtiger_Field();
$fieldInstance->name = 'foldername';
$fieldInstance->table = 'vtiger_notes';
$fieldInstance->column = 'foldername';
$fieldInstance->label = 'Document Folder Name';
$fieldInstance->columntype = 'VARCHAR(100)';
$fieldInstance->uitype = 2;
$fieldInstance->typeofdata = '';
$blockInstance->addField($fieldInstance);
echo"Document field Created.";


// Module Instance 
$moduleName='Contacts';
$moduleInstance = Vtiger_Module::getInstance($moduleName);
// Add New Block
$blockInstance = new Vtiger_Block();
$blockInstance->label = 'Customer Portal';
$moduleInstance->addBlock($blockInstance);
// Add new Field 
$blockInstance = Vtiger_Block::getInstance('Customer Portal', $moduleInstance); 
$fieldInstance = new Vtiger_Field();
$fieldInstance->name = 'username';
$fieldInstance->table = 'vtiger_contactdetails';
$fieldInstance->column = 'username';
$fieldInstance->label = 'User Name';
$fieldInstance->columntype = 'VARCHAR(100)';
$fieldInstance->uitype = 55;
$fieldInstance->typeofdata = '';
$blockInstance->addField($fieldInstance);

$fieldInstance1 = new Vtiger_Field();
$fieldInstance1->name = 'password';
$fieldInstance1->table = 'vtiger_contactdetails';
$fieldInstance1->column = 'password';
$fieldInstance1->label = 'Password';
$fieldInstance1->columntype = 'VARCHAR(100)';
$fieldInstance1->uitype = 55;
$fieldInstance1->typeofdata = '';
$blockInstance->addField($fieldInstance1);
echo"Contact fields are created";

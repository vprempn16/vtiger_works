<?php

	class MailManager_MoveMail_action extends MailManager_Abstract_View{
		
		public function process(Vtiger_Request $request){
			global $adb,$current_user;
			$id =$current_user->id;
			$msg_no = $request->get('msgno');
                        $foldername = $request->get('folder');
                        $moveToFolder = $request->get('moveTo');

			$connector = $this->getConnector($foldername);
           		$response = new Vtiger_Response();
		        $connector->moveMail($msg_no, $moveToFolder);
                        $response->isJson(true);
                        $response->setResult(array('folder' => $foldername,'status'=>true));
			
		}
	}


?>

<?php

class Settings_Vtiger_SaveFolders_Action extends Settings_Vtiger_IndexAjax_View{
		
        public function Process(Vtiger_Request $request) {
		global $adb,$current_user;
		$id = $current_user->id;
		$data = $_REQUEST['folder'];
		$labelValue = $_REQUEST['label'];
		$backColor = $_REQUEST['BG_Color'];
		$font_Color = $_REQUEST['font_Color'];
		foreach(array_keys($labelValue) as $key){
			if(!empty($data[$key])){
				$folderValue[$data[$key]] = $labelValue[$key];
				}
			}
		foreach(array_keys($backColor) as $key){
			if(!empty($data[$key])){
				$bgColor[$data[$key]] = $backColor[$key];
				}
			}
		foreach(array_keys($font_Color) as $key){
                        if(!empty($data[$key])){
                                $fontColor[$data[$key]] = $font_Color[$key];
                                }
                        }
		$serializeData = base64_encode(serialize($folderValue));
		$serializeFontColor = base64_encode(serialize($fontColor));
		$serializeBgColor = base64_encode(serialize($bgColor));
		$getId = $adb->pquery("select user_id from vtiger_ba_selectedMailFolders where user_id = ?",array($id));
		$numOfRecord = $adb->num_rows($getId);
		if($numOfRecord <= 0){	
			$adb->pquery("insert into vtiger_ba_selectedMailFolders values(?,?,?,?)",array($id,$serializeData,$serializeBgColor,$serializeFontColor));
		}
		else{
			$adb->pquery("update vtiger_ba_selectedMailFolders set folders_name = ?,bgcolor= ? , fontcolor=? where user_id = ?",array($serializeData,$serializeBgColor,$serializeFontColor,$id) );
		}
		header("Location:index.php?parent=Settings&module=Vtiger&view=MoveMail&message=success");	
	}
}	

?>

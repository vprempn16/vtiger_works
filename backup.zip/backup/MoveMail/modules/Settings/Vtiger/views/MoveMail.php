<?php
include_once 'modules/MailManager/models/Message.php';
include_once 'modules/MailManager/models/Mailbox.php';
require_once('modules/MailManager/MailManager.php');

class Settings_Vtiger_MoveMail_View extends Settings_Vtiger_Index_View {

        public function process(Vtiger_Request $request) {
              
		global $adb,$current_user;
		$id = $current_user->id;
                $MailManager_Mailbox_Model_obj = MailManager_Mailbox_Model::activeInstance( $currentUserModel );
             	$Connector = MailManager_Connector_Connector::connectorWithModel( $MailManager_Mailbox_Model_obj , $folder );
                $moduleName = "MailManager";
                $folderName = "INBOX";
                $folderList = $Connector->getFolderList();
		$getEncodeData = $adb->pquery("select folders_name,bgcolor,fontcolor from vtiger_ba_selectedMailFolders where user_id = ?",array($id));
                $encoded_Data = $adb->query_result($getEncodeData, 0, 'folders_name');
		$encoded_bgColor = $adb->query_result($getEncodeData, 0, 'bgcolor');
		$encoded_font = $adb->query_result($getEncodeData, 0, 'fontcolor');

                $actualData = unserialize(base64_decode($encoded_Data));
                $actualBg = unserialize(base64_decode($encoded_bgColor));
                $actualFont = unserialize(base64_decode($encoded_font));
		$keys = array_keys($actualData);
		if($actualData !=''){
			$List = $keys;
			$folders = array_unique(array_merge($List,$folderList),SORT_REGULAR);
			$folderList = array_filter($folders);		
		}
		$qualifiedModuleName = $request->getModule(false);
                $viewer = $this->getViewer($request);
                $viewer->assign('BgColor', $actualBg);
                $viewer->assign('FontColor', $actualFont);
                $viewer->assign('FolderKey', $keys);
		$viewer->assign('SelectedFolder', $actualData);
 		$viewer->assign('FOLDERLIST', $folderList);
                $viewer->view("MoveMailFolder.tpl", $qualifiedModuleName);
 
    }

}

<?php
class BAFilterRelation {

    function __construct() {
        $this->db = PearDatabase::getInstance();

    }

    function vtlib_handler($modulename, $event_type) {
        if( $event_type == 'module.postinstall'){
            $this->executeSql();
            $this->moveFiles();
        } 
    }

    //  Workflow action script
    public function executeSql() {
        $nextNum = $this->db->pquery('select id from com_vtiger_workflow_tasktypes_seq');
        $fieldId = $this->db->query_result($nextNum, 0 , 'id');
        $fieldId ++;
        $modules = '{"include":[],"exclude":[]}';

        $this->db->pquery("insert into com_vtiger_workflow_tasktypes VALUES ({$fieldId}, 'BARelateRecord' , 'Relate record' , 'VTBARelateRecords' , 'modules/com_vtiger_workflow/tasks/VTBARelateRecords.inc' , 'modules/Settings/Workflows/Tasks/BARelateRecord.tpl' , '{$modules}' , '' )");

        $fieldId ++;


        $this->db->pquery("insert into com_vtiger_workflow_tasktypes VALUES ({$fieldId}, 'BAUnRelateRecord' , 'Unrelate record' , 'VTBAUnRelateRecords' , 'modules/com_vtiger_workflow/tasks/VTBAUnRelateRecords.inc' , 'modules/Settings/Workflows/Tasks/BAUnRelateRecord.tpl' , '{$modules}' , '' )");

        $this->db->pquery("update com_vtiger_workflow_tasktypes_seq set id = ?",array($fieldId));
    }

    // Copy files to Vtiger workflow
    public function moveFiles(){
        global $root_directory ;

        rename($root_directory."layouts/vlayout/modules/BAFilterRelation/BARelateRecord.tpl", "layouts/v7/modules/Settings/Workflows/Tasks/BARelateRecord.tpl");
        rename($root_directory."layouts/vlayout/modules/BAFilterRelation/BAUnRelateRecord.tpl", "layouts/v7/modules/Settings/Workflows/Tasks/BAUnRelateRecord.tpl");

        rename($root_directory."modules/BAFilterRelation/files/VTBARelateRecords.inc", "modules/com_vtiger_workflow/tasks/VTBARelateRecords.inc");
        rename($root_directory."modules/BAFilterRelation/files/VTBAUnRelateRecords.inc", "modules/com_vtiger_workflow/tasks/VTBAUnRelateRecords.inc");
        rename($root_directory."modules/BAFilterRelation/files/BaGetFilter.php", "modules/Vtiger/views/BaGetFilter.php");
    }
}

<?php
class Vtiger_BaGetFilter_View extends Vtiger_Basic_View {
    public function process( Vtiger_Request $request ){
        global $adb;
        $tab = $_POST['selectedModule'];
        $filterList = [];

        $getFilters = $adb->pquery('select cvid, viewname from vtiger_customview where entitytype = ?' , array($tab));
        while($row = $adb->fetch_array($getFilters)){
           
            $list['id'] = $row['cvid'];
            $list['name'] = $row['viewname'];
            $filterList[] = $list;

        }
        echo json_encode($filterList);
        die;

    }
}

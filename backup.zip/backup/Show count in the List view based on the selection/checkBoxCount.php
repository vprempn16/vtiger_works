<?php
include_once('vtlib/Vtiger/Module.php');
$moduleInstance = Vtiger_Module::getInstance('Home');
$moduleInstance->addLink('HEADERSCRIPT', 'checkboxCount','layouts/vlayout/modules/Vtiger/resources/checkboxcheck.js');
?>

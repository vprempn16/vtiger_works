<?php
require_once('modules/Vtiger/actions/TagCloud.php');	
class BALetters_PrintLetterDocument_Action extends Vtiger_Action_Controller {
	 public function checkPermission() {
        	return true;
	}

	public function process(Vtiger_Request $request) {

		global $current_user, $adb;
		$letterId = $_POST['RecordId'];		
		for($i = 0; $i < count($letterId); $i ++) {
                	$getDocumentId =$adb->pquery("select relcrmid from vtiger_crmentityrel where crmid = ",array($letterId[$i]) );
                	$documentId = $adb->query_result($getDocumentId, 0 , 'relcrmid');
			$getAttachmentId = $adb->pquery("select attachmentsid from vtiger_seattachmentsrel where crmid = ?", array($documentId) );
			$attachmentId =  $adb->query_result( $getAttachmentId, 0, 'attachmentsid');	
			$getAttachment = $adb->pquery("select path, name from vtiger_attachments where attachmentsid = ? ",array($attachmentId) );
			while($row = $adb->fetch_array($getAttachment) ) {
				$attachments[] = $row['path'].$attachmentId.'_'.$row['name'];
			}
                }
//echo "<pre>";print_r($attachments);
		$this->MergePDF($attachments);
	
	}
	public function MergePDF($attachments) {
		global $site_URL;
	//	ob_clean();
		require_once 'modules/BALetters/PDFMerger/PDFMerger.php';
		$pdf = new PDFMerger;
		$pdfFile = 'storage/MergePDFFile_'.time().'.pdf';
		if(count($attachments) > 0 ) {
			for($i = 0; $i < count($attachments); $i ++){
				$pdf->addPDF($attachments[$i], 'all');
			}
			$pdf->merge('file', $pdfFile);
			
		}
//		echo '<iframe src="http://localhost/vtigerone/"+path+"" width="100%" height="100%"></iframe>';

		$PDF['path'] = $site_URL.$pdfFile;
		echo json_encode($PDF);
		
	}
}	

function TagRecords(record) {
        $('#SR_BA_Add_Tag_Model').modal('show');
}

window.tagColor = [];
window.newTagName = [];
function AddTag() {
        var tagName = $('#create_letter_tag').val();
        if(tagName !='') {
                $.ajax({
                        type : "POST",
                        datatype: 'JSON',
                        data : {
                              'option' : 'existCheck',
                              'tagName' : tagName,
                              },
                        url : "index.php?module=BALetters&action=SaveTagNames",
                        success:function(result) {
                                var data = result;
                                if(data == 1){
                                        alert('Tag name already exist');
                                }
                                else {

                                        var selectedColor = $('#letter_tag_color').val();
                                        var select = document.getElementById('current_letter_tag');
                                        var opt = document.createElement('option');
                                            opt.value = tagName;
                                            opt.innerHTML = tagName;
                                            select.appendChild(opt);
                                        var currentTag = $('#current_letter_tag').val();
                                        if(currentTag == null) {
                                                currentTag = [];
                                        }
                                        currentTag.push(tagName);
                                        $('#current_letter_tag').select2().select2('val',currentTag);

                                        $.ajax({
                                                type : "POST",
                                                datatype: 'JSON',
                                                data : {
                                                        'option' : 'add',
                                                        'tagColor' : selectedColor,
                                                        'tagName' : tagName,
                                                        },
                                                url : "index.php?module=BALetters&action=SaveTagNames",
                                                success:function(result) {

                                                        $('#create_letter_tag').val('');
                                                        $('#letter_tag_color').val('');
                                                }
                                        });
                                }
                        }
                });
        }
}
function SaveLetterTag(recordId) {
         var progressIndicatorElement = jQuery.progressIndicator({
                        'message' : 'Loading...',
                        'position' : 'html',
                        'blockInfo' : {
                                'enabled' : true
                        },
                });

        var currentTag = $('#current_letter_tag').val();
        $.ajax({
                type : "POST",
                datatype: 'JSON',
                data : {
                        'option' : 'save',
                        'existTag' : currentTag,
                        'recordId' : recordId,
                        },
                url : "index.php?module=BALetters&action=SaveTagNames",
                success:function(result) {
                        $('#SR_BA_Add_Tag_Model').modal('toggle');
                        window.location.reload();
                }

        });

}
$(document).on('click','.BA-Letter-tag',function(e) {
                var tagElement = jQuery(e.currentTarget);
                var tagId = tagElement.data('tagid');
                var params = {
                'module' : app.getModuleName(),
                'view' : 'TagCloudSearchAjax',
                'tag_id' : tagId,
                'tag_name' : tagElement.text()
                }
                AppConnector.request(params).then(
                                function(data) {
                                var params = {
                                'data' : data,
                                'css'  : {'min-width' : '40%'}
                                }
                                app.showModalWindow(params);
                                }
                                )

                });
$(document).on('click' , '.deleteLetterTag', function(e){
                 var progressIndicatorElement = jQuery.progressIndicator({
                        'message' : 'Loading...',
                        'position' : 'html',
                        'blockInfo' : {
                                'enabled' : true
                        },
                });

                var tag = jQuery(e.currentTarget);
                var tagId = tag.data('tagid');
                var record_id = $('#recordId').val();
                tag.fadeOut('slow', function() {
                                tag.remove();
                                });
                var params = {
                        module : app.getModuleName(),
                        action : 'TagCloud',
                        mode : 'delete',
                        tag_id : tagId,
                        record : record_id
                }
                AppConnector.request(params).then(
                function(data) {
                        location.reload();
                });


});
//      Tag Admin Page
function editTag(tagName ,tagColor, tagId) {
        $('#SR_BA_TagAdmin_Model').modal('show');
        document.getElementById('letter_tag_name').value = tagName;
        document.getElementById('tag_color').value = tagColor;
        document.getElementById('tag_id').value = tagId;
        $('#round_color').css('background-color', tagColor);

        $("#round_color").click(function(event) {
            $("#tag_color").click();
        });
        $("#tag_color").change(function(event) {
                $("#round_color").css('background-color',$(this).val());
        });
}
function saveEditTag(){
        var tagsNewColor = $("#tag_color").val();
        var tagsNewName = $("#letter_tag_name").val();
        var tagId = $("#tag_id").val();
        $.ajax({
                type : "POST",
                data : {
                        'tagAction' : 'editTag',
                        'tagName' : tagsNewName,
                        'tagColor' : tagsNewColor,
                        'existId' : tagId,
                        },
                datatype : 'JSON',
                url : 'index.php?parent=Settings&module=Vtiger&view=TagAdmin',
                success : function(result){
                        location.reload();
                }
        });
}
function deleteTag(id,tagName){
        var result = confirm("Are you want to delete the Tag?");
        if (result) {
                var progressIndicatorElement = jQuery.progressIndicator({
                        'message' : 'Loading...',
                        'position' : 'html',
                        'blockInfo' : {
                                'enabled' : true
                        },
                });
                $.ajax({
                        type : "POST",
                        data : {
                                'tagAction' : 'deleteTag',
                                'tagId' : id,
                                'tagName' : tagName,
                                },
                        datatype : 'JSON',
                        url : 'index.php?parent=Settings&module=Vtiger&view=TagAdmin',
                        success : function(result){
                                location.reload();
                        }
                });
        }
}
window.flag = 0;        // Ascending Order      
function sortTags(){

        var sortImageUp = '<img class="icon-chevron-up icon-Black">';
        var sortImageDown = '<img class="icon-chevron-down icon-Black">';
        if(flag == 0 ){
                var order = 'order by vtiger_freetags.tag asc';
                var icon = sortImageDown;
                window.flag = 1;
        } else {
                var order = 'order by vtiger_freetags.tag desc';
                var icon = sortImageUp;
                window.flag = 0;
        }
        $.ajax({
                type : 'POST',
                data : {'tag_order': order},
                datatype : 'JSON',
                url : 'index.php?parent=Settings&module=Vtiger&view=TagAdmin',
                success : function(data) {
                        $('#settingsTagAdmin').html(data);
                        $('#sort_image_id').html(icon);
                }
        });

}
$('#BALetters_detailView_fieldLabel_head_tag').ready(function(){
        $('#BALetters_detailView_fieldLabel_head_tag').css('display','none');
        $('#BALetters_detailView_fieldValue_head_tag').css('display','none');


});
var moduleName = $('#module').val();
var moduleView = app.getViewName();
if( moduleName == "BALetters" && moduleView == 'Edit' ) {
        document.getElementsByTagName("td")[6].remove();
        document.getElementsByTagName("td")[6].remove();

}



<?php
class BALetters_UpdateExistTagValue_Action extends Vtiger_Action_Controller {
         public function checkPermission() {
                return true;
        }
	public function process(Vtiger_Request $request){
		global $adb;
		$getTag = $adb->pquery('select vtiger_freetags.id , vtiger_freetagged_objects.object_id , vtiger_srba_tag_letter.tag_color from vtiger_freetags right join vtiger_freetagged_objects on vtiger_freetags.id = vtiger_freetagged_objects.tag_id right join vtiger_srba_tag_letter on vtiger_freetags.id = vtiger_srba_tag_letter.id');
		while( $row = $adb->fetch_array($getTag) ){

//		Only once the code want to run		

			$adb->pquery('update vtiger_baletters set head_tag = ? where balettersid = ?', array($row['min( vtiger_freetags.tag)'] , $row['object_id']) );

//	After execute hide or delete the code
			$tagData[$row['object_id']] = $row['tag_color'];
		}
		if($_POST['option'] == 'getTagData') {
			echo json_encode($tagData);
		}
		
	}	
}

<?php
include_once('vtlib/Vtiger/Module.php');
$moduleName='BALetters';
$moduleInstance = Vtiger_Module::getInstance($moduleName);
$blockInstance = Vtiger_Block::getInstance('Basic Information', $moduleInstance); 
$fieldInstance = new Vtiger_Field();
$fieldInstance->name = 'head_tag';
$fieldInstance->table = 'vtiger_baletters';
$fieldInstance->column = 'head_tag';
$fieldInstance->label = 'Head Tag';
$fieldInstance->columntype = 'VARCHAR(100)';
$fieldInstance->uitype = 2;
$fieldInstance->typeofdata = '';
$blockInstance->addField($fieldInstance);
echo"ok";

<?php
include_once 'vtlib/Vtiger/Version.php';
require_once '../mpdf/vendor/autoload.php';
use Mpdf;
class Settings_Vtiger_HeaderTemplate_View extends Settings_Vtiger_Index_View
{
	public function process(Vtiger_Request $request)
	{
		global $adb;
		$mode = $request->get('mode');
	
		$module = $request->getModule(false);
		$viewer = $this->getViewer($request);

		if($mode == null){   //list view of the page
			$getData = $adb->pquery("select name,templates from vtiger_srba_header_template");
			while($row = $adb->fetch_array($getData)){
				$temp[] = $row['name'];
			}
			if($_POST['call'] == 'ajaxcall'){	//Pass the Header  
				echo json_encode($temp);
				die;
			}
			$viewer->assign('FILENAME',$temp);
			$viewer->view('HeaderTemplate.tpl',$module); 
		}else if($mode == 'create'){ // It show the create page 

			//      RichText Editor Function 
                        function getHeaderScripts(Vtiger_Request $request) {
                                $headerScriptInstances = parent::getHeaderScripts($request);

                                $moduleName = $request->getModule();

                                $jsFileNames = array(
                                         "libraries.jquery.ckeditor.ckeditor",
                                         "libraries.jquery.ckeditor.adapters.jquery",
                                          'modules.Vtiger.resources.CkEditor',
                                       );
                               $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
                               $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
                               return $headerScriptInstances;
                        }


			$name = $_GET['id'];
			if($name !=null){
	                        $header = $adb->pquery('select templates from vtiger_srba_header_template where name = ?',array($name));
	                        $temp = $adb->fetch_array($header);
	                        $headerTemp = unserialize(base64_decode($temp['templates']));
				$viewer->assign('NAME',$name);
				$viewer->assign('CONTANT',$headerTemp);		
			}
                        $viewer->view('CreateHeaderTemplate.tpl',$module);
		}else if($mode =='save'){ // save the contants and file name in data base
			$data = $_POST['headerTemplateEditor'];
			$filename = $_POST['filename'];
			$encodeData = base64_encode(serialize($data));
			global $adb;
			$existId = $adb->pquery('select id from vtiger_srba_header_template where name= ?',array($filename));
			$id = $adb->fetch_array($existId); 
			if($id['id']!= null){
				$adb->pquery('update vtiger_srba_header_template set templates = ? where name =?',array($encodeData,$filename));
				header('location:index.php?parent=Settings&module=Vtiger&view=HeaderTemplate&message=success');
			}else{		
				$adb->pquery('insert into vtiger_srba_header_template (name,templates) values(?,?)',array($filename,$encodeData));
				header('location:index.php?parent=Settings&module=Vtiger&view=HeaderTemplate&message=success');
			}		
		}elseif($mode == 'pdf'){
			global $adb,$root_directory;
			$recordId = $_POST['recordId'];
			$content = $_POST['ContantTemplate'];
			$header = $adb->pquery('select templates from vtiger_srba_header_template where name = ?',array($_POST['headername']));
			$temp = $adb->fetch_array($header);
			$headerTemp = unserialize(base64_decode($temp['templates']));
			if($_POST['options']== 'print'){
				echo JSON_encode($headerTemp);
				die;
			}
			$fileName = $_POST['PdffileName'];
			$pdfFileName =$root_directory.'storage/'.$fileName.'.pdf';
			$mpdf = new \Mpdf\Mpdf(['setAutoTopMargin' => 'stretch']);
			$mpdf->SetHTMLHeader($headerTemp);
			$mpdf->WriteHTML($content);
			$mpdf->Output($pdfFileName, 'F');
                        if($_POST['options']== 'download'){
				$mpdf->Output($fileName.'.pdf','d');

				$this->createDoc($recordId,'Documents',$pdfFileName,$content);
			}
//			elseif($_POST['options']== 'print'){
			//	$header[]=$headerTemp;			
//				echo $headerTemp;
//				die;
		//	}
			elseif($_POST['options']== 'sendEmail'){

				$this->createDoc($recordId,'Documents',$pdfFileName,$content);
			}

		}elseif($mode == 'Action'){
			global $adb;
			$adb->pquery('delete from vtiger_srba_header_template where name = ? ',array($_GET['id']));
			header('location:index.php?parent=Settings&module=Vtiger&view=HeaderTemplate');
		}
	}
public function createDoc($rel_id, $rel_module, $attachment_info,$content)
    {
        global $current_user, $upload_badext, $adb, $root_directory;
        $filePath =  $attachment_info;
        $tmp_fileInfo = pathinfo($attachment_info);
        $fileInfo = new stdClass();
        $fileInfo->filename = $tmp_fileInfo['filename'];
        $fileInfo->basename = $tmp_fileInfo['basename'];
        $file_size = filesize($filePath);

        $folderid = 1;
        $response = array();
        require_once('modules/Documents/Documents.php');
        $doc = new Documents();
        $doc->mode = 'create';
        $doc->id = null;
        $doc->column_fields['notes_title'] = sanitizeUploadFileName($fileInfo->filename, $upload_badext);
        $doc->column_fields['filename'] = $fileInfo->basename;
        $doc->column_fields['filetype'] = $attachment_info['type'];
        $doc->column_fields['filesize'] = $file_size;
        $doc->column_fields['filelocationtype'] = 'I';
        $doc->column_fields['filestatus'] = 1;
        $doc->column_fields['folderid'] = $folderid;
        $doc->column_fields['assigned_user_id'] = $current_user->id;
        $doc->save('Documents');
        if($doc->id)    {
            $response = $this->uploadAndSaveFile($doc->id, $rel_module, $doc, $attachment_info, $filePath,$rel_id);
            // relating record to module
   //       $adb->pquery('insert into vtiger_crmentityrel (crmid, notesid) values (?, ?)', array( $doc->id,$rel_id));

            if(vtlib_isModuleActive('ModTracker')) {
                // Track the time the relation was added
                require_once 'modules/ModTracker/ModTracker.php';
                ModTracker::linkRelation($rel_module, $rel_id, 'Documents', $doc->id);
            }
        }
//Record Related to Contacts

/*	$moduleInstance = Vtiger_Module::getInstance('Documents');
	$accountsModule = Vtiger_Module::getInstance('Contacts');
	$relationLabel  = 'Contacts';
	$moduleInstance->setRelatedList(
	      $accountsModule, $relationLabel, Array('ADD','SELECT')
	);


*/
$ss=$adb->pquery('insert into vtiger_crmentityrel values(?, ?, ?, ?)', array($doc->id, 'Documents', $rel_id, 'Contacts'));
//      Create a record in Letter Module

	$getContactName = $adb->pquery("select salutation,firstname,lastname from vtiger_contactdetails where contactid =?",array($rel_id));
	$contactName = $adb->fetch_array($getContactName);
	$name = $contactName['salutation'].'.' .$contactName['firstname'].' '.$contactName['lastname'];
	$recordModel = Vtiger_Record_Model::getCleanInstance("BALetters");
$recordModel = Vtiger_Record_Model::getCleanInstance("BALetters");
$recordModel->set('mode', 'create');
$recordModel->set('assigned_user_id',1);
$recordModel->set('name', $fileInfo->basename); 
$recordModel->set('contact', $name); // ok
$recordModel->set('description', $content); // ok
$recordModel->save();
$RecordId = $recordModel->getId(); 
/*	//Need to run atleast one time.
	
	$letter->mode = 'create';
	$letter->balettersid = $doc->id;
	$letter->column_fields['name']= $filePath;
	$letter->column_fields['contact']=$name;
	$letter->column_fields['description']= $content;
	$letter->save('BALetters');
*/
	$docId[] =$doc->id; 
	echo JSON_encode($docId);
        return $response;
    }

public function uploadAndSaveFile($id, $module, $docObj, $file_details, $filePath) {
        global $adb, $current_user, $upload_badext;

        $date_var = date("Y-m-d H:i:s");

        //to get the owner id
        $ownerid = $docObj->column_fields['assigned_user_id'];
        if (!isset($ownerid) || $ownerid == '')
            $ownerid = $current_user->id;

        $file_name = $docObj->column_fields['filename'];

        // For check
        $save_file = 'true';
        //only images are allowed for Image Attachmenttype
        $mimeType = $docObj->column_fields['filetype'];

        $binFile = sanitizeUploadFileName($file_name, $upload_badext);

        $current_id = $adb->getUniqueID("vtiger_crmentity");

        $filename = ltrim(basename(" " . $binFile)); //allowed filename like UTF-8 characters
        $filetype = $docObj->column_fields['filetype'];
        $filesize = $docObj->column_fields['filesize'];
        $filetmp_name = $file_details['tmp_name'];

        //get the file path inwhich folder we want to upload the file
        $upload_file_path = decideFilePath();

        $upload_status = copy($filePath, $upload_file_path . $current_id . "_" . $binFile);

        //upload the file in server
        $sql1 = "insert into vtiger_crmentity (crmid,smcreatorid,smownerid,setype,description,createdtime,modifiedtime) values(?, ?, ?, ?, ?, ?, ?)";
        $params1 = array($current_id, $current_user->id, $ownerid, "Documents Attachment", $docObj->column_fields['description'], $adb->formatDate($date_var, true), $adb->formatDate($date_var, true));
        $adb->pquery($sql1, $params1);

        $sql2 = "insert into vtiger_attachments(attachmentsid, name, description, type, path) values(?, ?, ?, ?, ?)";
        $params2 = array($current_id, $filename, $docObj->column_fields['description'], $filetype, $upload_file_path);
        $result = $adb->pquery($sql2, $params2);
//     Module table

if ($module == 'Documents') {
            $query = "delete from vtiger_seattachmentsrel where crmid = ?";
            $qparams = array($id);
            $adb->pquery($query, $qparams);
        }

        $sql3 = 'insert into vtiger_seattachmentsrel values(?,?)';
        $adb->pquery($sql3, array($id, $current_id));
        return true;
    }
}
?>


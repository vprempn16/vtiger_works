function openRichTextEditor(recordId){
        var recordNo = recordId;
        $.ajax({
                type:'POST',
                data:{'call':'ajaxcall'},
                datatype:'JSON',
                url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate',
                success:function(data){
                        var data = JSON.parse(data);
                        for(var i=0;i<data.length;i++){
                                var filename = data[i];
                        }

                        $("#model").html('');
                        var headers = ' <input id="recordId" type="hidden" name ="recordId"value='+recordNo+' /><table><tr><td style="font-weight: bold;width: 27%;" >File name</td><td><input id="HeaderTemplateName" type="text" name ="PdffileName" required/></td></tr><tr><td style="font-weight: bold;width: 27%;"> Header Template</td><td><select id="header_template"  name = "headername" required><option value="">Select</option>';
                        var textBox = '';

                        for(var i=0;i<data.length;i++){
                                headers +='<option value='+data[i]+'>'+data[i]+'</option>';
                        }

                        textBox = '</td></tr></table><br><textarea style="width: 70%;"cols="80" id="content_template" name="ContentTemplate" rows="10"></textarea><span style="margin-left: 20%;"><button type="submit" name="options" value="download">Download</button><button type="button" onclick="printPdf('+recordNo+')">Print</button><button type="button"  onclick="sendEmail('+recordNo+')" >Send as Email</button></span>';

                        $('#model').append(headers);
                        $("#model").append(textBox);
                        jQuery("#modelPage").modal('show');
                        var noteContentElement =$('#content_template');
                        noteContentElement.addClass('ckEditorSource');
                        var ckEditorInstance = new Vtiger_CkEditor_Js();
                        ckEditorInstance.loadCkEditor(noteContentElement);
                }
        });
}
function sendEmail(recordNo) {

/*      var progressIndicatorElement = jQuery.progressIndicator({
                'message' : 'Loading...',
                'position' : 'html',
                'blockInfo' : {
                        'enabled' : true
                        },
                });
*/
                var Content = CKEDITOR.instances['content_template'].getData();
                var header = document.getElementById('header_template').value;
                var fileName = document.getElementById('HeaderTemplateName').value;
                $.ajax({
                        type:'POST',
                        datatype: 'JSON',
                        data:{'options':'sendEmail','headername':header,'PdffileName':fileName,'ContentTemplate':Content,'recordId':recordNo},
                        url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate&mode=pdf',
                        success:function(data){
                                var letterID = JSON.parse(data);
                                var currentInstance = Vtiger_Detail_Js.getInstance();
                                var parentRecord = new Array();
                                var params = {};
                                parentRecord.push(currentInstance.getRecordId());
                                params['module'] = "Contacts";
                                params['view'] = "MassActionAjax";
                                params['selected_ids'] = recordNo;
                                params['send_Mail_With_Letter'] =letterID;
                                params['mode'] = "showComposeEmailForm";
                                params['step'] = "step1";
                                params['relatedLoad'] = true;
                                Vtiger_Index_Js.showComposeEmailPopup(params);

                        var ss =  '<div class="MultiFile-label"><a class="removeAttachment cursorPointer" data-id='+letterID.id+' data-file-size='+selectedFileSize+'>x </a><span>'+letterID.id+'</span></div>';
                        $('.MultiFile-label').after(ss);
                        }

                });
}
function printPdf(recordId){

        var Content = CKEDITOR.instances['content_template'].getData();
        var header = document.getElementById('header_template').value;
        var fileName = document.getElementById('HeaderTemplateName').value;
        var content = window.open();

         $.ajax({
                        type:'POST',
                        datatype: 'JSON',
                        data:{'headername':header,'options':'print'},
                        url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate&mode=pdf',
                        success:function(data){
                                var header = JSON.parse(data);
                                content.document.write(header+"<br><br>");
                                content.document.write("<br><br>"+Content+"<br>");
                                content.print();
                                }
                });
}
/*      $('#header_template').ready(function(){
                                var noteContentElement =$('header_template');
                                noteContentElement.addClass('ckEditorSource');
                                var ckEditorInstance = new Vtiger_CkEditor_Js();
                                ckEditorInstance.loadCkEditor(noteContentElement);
        cosole.log(noteContentElement);
      });
*/



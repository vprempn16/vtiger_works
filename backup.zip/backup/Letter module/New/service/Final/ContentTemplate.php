<?php
class Settings_Vtiger_ContentTemplate_View extends Settings_Vtiger_Index_View
{
	public function process(Vtiger_Request $request)
	{
		global $adb;
		$mode = $request->get('mode');

		$module = $request->getModule(false);
		$viewer = $this->getViewer($request);

		if($mode == null)	//list view of the page
		{  
			$getData = $adb->pquery("select name from vtiger_srba_content_template");
			while($row = $adb->fetch_array($getData))
			{
				$temp[] = $row['name'];
			}
						if($_POST['call'] == 'ajaxcall')
			{         
				echo json_encode($temp);
				die;
			}
			$viewer->assign('FILENAME',$temp);
			$viewer->view('ListContentTemplate.tpl',$module);
		}
		else if($mode == 'create')  // It show the create page 
		{ 	
			$getContactFields = $adb->pquery('select columnname,fieldlabel from vtiger_field where tabid =4');
			while($row = $adb->fetch_array($getContactFields))
			{
				$contactFields[$row['columnname']] = $row['fieldlabel'];
			}
			$name = $_GET['id'];
			if($name !=null)
			{
				$content = $adb->pquery('select content from vtiger_srba_content_template where name = ?',array($name));
				$temp = $adb->fetch_array($content);
				$contentTemp = unserialize(base64_decode($temp['content']));
				$viewer->assign('NAME',$name);
				$viewer->assign('CONTANT',$contentTemp);
			}
			$viewer->assign('CONTACTFILEDS',$contactFields);
			$viewer->view('CreateContentTemplate.tpl',$module);
		}
		else if($mode =='save')		// save the contants and file name in data base
		{ 
			$data = $_POST['CotentTemplate'];
			$filename = $_POST['filename'];
			$encodeData = base64_encode(serialize($data));
			global $adb;
			$existId = $adb->pquery('select id from vtiger_srba_content_template where name= ?',array($filename));
			$id = $adb->fetch_array($existId);
			if($id['id']!= null)
			{
				$adb->pquery('update vtiger_srba_content_template set content = ? where name =?',array($encodeData,$filename));
				header('location:index.php?parent=Settings&module=Vtiger&view=ContentTemplate&message=success');
			}
			else
			{
				$adb->pquery('insert into vtiger_srba_content_template (name,content) values(?,?)',array($filename,$encodeData));
				header('location:index.php?parent=Settings&module=Vtiger&view=ContentTemplate&message=success');
			}

		}
	}
}	

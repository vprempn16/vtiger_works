<?php
include_once('vtlib/Vtiger/Module.php');
$moduleName='BALetters';
$moduleInstance = Vtiger_Module::getInstance($moduleName);
$blockInstance = Vtiger_Block::getInstance('Basic Information', $moduleInstance); 
$fieldInstance = new Vtiger_Field();
$fieldInstance->name = 'status';
$fieldInstance->table = 'vtiger_baletters';
$fieldInstance->column = 'status ';
$fieldInstance->label = 'Status';
$fieldInstance->columntype = 'VARCHAR(100)';
$fieldInstance->uitype = 2;
$fieldInstance->typeofdata = 'V~M';
$blockInstance->addField($fieldInstance);
echo"ok";

	public function process(Vtiger_Request $request)
	{
		global $adb;
		$mode = $request->get('mode');

		$module = $request->getModule(false);
		$viewer = $this->getViewer($request);

		if($mode == null){   //list view of the page
			$getHeaderData = $adb->pquery("select name from vtiger_srba_header_template");
			while($row = $adb->fetch_array($getHeaderData)){
				$customHeaders[] = $row['name'];
			}
			$getContentData = $adb->pquery("select name from vtiger_srba_content_template");
			while($row = $adb->fetch_array($getContentData)){
				$customContents[] = $row['name'];
			}
			$getDrafts = $adb->pquery('select balettersid,name from vtiger_baletters where status="Draft"');
			while($row = $adb->fetch_array($getDrafts)) {
				$draftLetters[] = $row;
			}

			if($_POST['call'] == 'getHeaders'){	//Get the Headers to the Ajax  
				$templates['headers'] = $customHeaders;
				$templates['contents'] = $customContents;
				$templates['draft'] = $draftLetters;
				echo json_encode($templates);
				die;
			}
			if($_POST['call'] == 'getContent')
			{
				$contentTemplateName = $_POST['contentTemplateName'];
				$getContentTemplate = $adb->pquery('select content from vtiger_srba_content_template where name = ?',array($contentTemplateName));
				$contentTemp = $adb->fetch_array($getContentTemplate);
				$decodeContent = unserialize(base64_decode($contentTemp['content']));
				echo json_encode($decodeContent);
				die;
			}
			if($_POST['call'] == 'getDraftRecords') {   // Get the BA Letters records 
				$crmId = $_POST['letterId'];
				$getDraftContent = $adb->pquery('select description from vtiger_crmentity where crmid = ?',array($crmId));
				$letterContent = $adb->query_result($getDraftContent,0,'description');
				echo json_encode(htmlspecialchars_decode($letterContent));
				die;
			}

			$viewer->assign('FILENAME',$customHeaders);
			$viewer->view('HeaderTemplate.tpl',$module); 
		}else if($mode == 'create'){ // It show the create page 

			$name = $_GET['id'];
			if($name !=null){
				$header = $adb->pquery('select templates from vtiger_srba_header_template where name = ?',array($name));
				$temp = $adb->fetch_array($header);
				$headerTemp = unserialize(base64_decode($temp['templates']));
				$viewer->assign('NAME',$name);
				$viewer->assign('CONTANT',$headerTemp);		
			}
			$viewer->view('CreateHeaderTemplate.tpl',$module);
		}else if($mode =='save'){ // save the contants and file name in data base
			$data = $_POST['headerTemplateEditor'];
			$filename = $_POST['filename'];
			$encodeData = base64_encode(serialize($data));
			global $adb;
			$existId = $adb->pquery('select id from vtiger_srba_header_template where name= ?',array($filename));
			$id = $adb->fetch_array($existId); 
			if($id['id']!= null){
				$adb->pquery('update vtiger_srba_header_template set templates = ? where name =?',array($encodeData,$filename));
				header('location:index.php?parent=Settings&module=Vtiger&view=HeaderTemplate&message=success');
			}else{		
				$adb->pquery('insert into vtiger_srba_header_template (name,templates) values(?,?)',array($filename,$encodeData));
				header('location:index.php?parent=Settings&module=Vtiger&view=HeaderTemplate&message=success');
			}		
		}elseif($mode == 'pdf'){
			global $root_directory;
			$recordId = $_POST['recordId'];
			if (strpos($recordId, ',') !== false) {
				$recordId = explode(',' , $recordId);
			}
			if(! is_array($recordId)) {
			$recordId = array();
			$recordId[] = $_POST['recordId'];
			}
			$contents = $_POST['ContentTemplate'];
			for($i=0; $i<count($recordId); $i++) {
				$content[$i] = getMergedDescription($contents, $recordId[$i] ,'Contacts');
			}
			$header = $adb->pquery('select templates from vtiger_srba_header_template where name = ?',array($_POST['headername']));
			$temp = $adb->fetch_array($header);
			$headerTemp = unserialize(base64_decode($temp['templates']));
			if($_POST['options']== 'print'){
				$letter['headerTemp'] = $headerTemp;
				for($i=0; $i<count($recordId); $i++) {
					$letterContents[] = $content[$i];
				}
				$letter['contentTemp'] = $letterContents;
				echo JSON_encode($letter);
				die;
			}
			$fileName = $_POST['PdffileName'];
		//	$filePath = 'storage/'.$fileName;
			$pdfFileName =$root_directory.'storage/'.$fileName.'.pdf';

			if($_POST['ViewPage'] == 'ListViewRecords'){
			//	App::import('Vendor', 'mpdf', array('file' => 'mpdf' . DS . 'mpdf.php'));
				$zip = new ZipArchive();
			//	$zip->open($fileName.'.zip', ZipArchive::CREATE);
				if($zip->open($fileName.".zip", ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE))
				{
 					for ($i=0; $i < count($recordId); $i++)

					{
						$mpdf = new \Mpdf\Mpdf(['setAutoTopMargin' => 'stretch']);
		                                $mpdf->SetHTMLHeader($headerTemp);
		                                $mpdf->setFooter('{PAGENO}');
		                                $mpdf->WriteHTML($content[$i]);
		                                $mpdf->Output($fileName.$i.'.pdf','F');
						$zip->addFile($fileName.$i.'.pdf');
					}
				}else {
					echo "cant open!!";exit;
				}
				$zip->close();
				$archfilename = $fileName.'.zip';
				header("Content-type: application/zip"); 
				header("Content-Disposition: attachment; filename = $archfilename"); 
				header("Pragma: no-cache"); 
				header("Expires: 0"); 
				readfile($fileName.".zip");	
				
				
				for($i=0; $i <=count($recordId); $i++) { // Deleted Saved Files
				        unlink($fileName.$i.'.pdf');
					if($i == count($recordId)){
						unlink($fileName.".zip");
					}
				}
			}

		//	$pdfFileName =$root_directory.'storage/'.$fileName.'.pdf';
			for($i=0; $i<count($recordId); $i++ ) {
				$mpdf = new \Mpdf\Mpdf(['setAutoTopMargin' => 'stretch']);
				$mpdf->SetHTMLHeader($headerTemp);
				$mpdf->setFooter('{PAGENO}');
				$mpdf->WriteHTML($content[$i]);
				$mpdf->Output($pdfFileName, 'F');
				if($_POST['options']== 'download'){ 	//  Download the Pdf File
					if($_POST['ViewPage'] != 'ListViewRecords'){
					 	$mpdf->Output($fileName.$i.'.pdf', 'D');
					}
					$this->createDoc($recordId[$i],'Documents',$pdfFileName,$content[$i]);
						
				}elseif($_POST['options']== 'sendEmail'){	// Attach the Pdf to Mail

					$this->createDoc($recordId[$i],'Documents',$pdfFileName,$content[$i]);

				}elseif($_POST['options'] == 'Draft'){		// Save to Draft to BA Letters module

					$return = 0;
					$recordModel = Vtiger_Record_Model::getCleanInstance("BALetters");
					$recordModel->set('mode', 'create');
					$recordModel->set('assigned_user_id',1);
					$recordModel->set('name', $fileName);
					$recordModel->set('contacts', $recordId[$i]);
					$recordModel->set('description', $contents);
					$recordModel->set('status','Draft');
					$recordModel->save();
					$return = "success";
					echo json_encode($return);
				}

			}
		}elseif($mode == 'Action'){
			global $adb;
			$adb->pquery('delete from vtiger_srba_header_template where name = ? ',array($_GET['id']));
			header('location:index.php?parent=Settings&module=Vtiger&view=HeaderTemplate');
		}
	}

<?php
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';

global $adb;
$nextNum = $adb->pquery('select id from vtiger_settings_field_seq');
$fieldId = $adb->fetch_array($nextNum);
$fieldId = $fieldId['id']+1;
$adb->pquery("insert into vtiger_settings_field (fieldid,blockid,name,linkto)values($fieldId,3,'Content Templates','index.php?parent=Settings&module=Vtiger&view=ContentTemplate')");
$adb->pquery("update vtiger_settings_field_seq set id = ?",array($fieldId));
$adb->pquery("create table vtiger_srba_content_template (id int primary key auto_increment,name varchar(100),content long)");
echo"Done";

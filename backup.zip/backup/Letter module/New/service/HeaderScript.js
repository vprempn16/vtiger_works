//************		  Header Template		************

function openRichTextEditor(recordId){

        var recordNo =[recordId];
        $.ajax({
                type:'POST',
                data:{'call':'getHeaders'},
                datatype:'JSON',
                url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate',
                success:function(data){
			var data = JSON.parse(data);
			var headerName = data.headers;
			var contentName = data.contents;
			var draftLetter = data.draft;
                        $("#model").html('');
                        var headers = '<input type = "hidden" value = '+recordNo+' name="recordId" /><div style="float: right;"></div><table><tr><td style="font-weight: bold;width: 27%;" >File name</td><td><input id="HeaderTemplateName" type="text" name ="PdffileName" required/></td></tr><tr><td style="font-weight: bold;width: 27%;"> Header Template</td><td><select id="header_template"  name = "headername" required><option value="">Select</option>';
                        var textBox = '';
			
                        for(var i=0;i<headerName.length;i++){
                                headers +='<option value='+headerName[i]+'>'+headerName[i]+'</option>';
                        }
			var contentTemp = '<table><tr><td style="font-weight: bold;width: 20%;">Content Templates</td><td><select id="select_content_template" name="content_temp"><option value="">select</option> ';
			for(var j=0; j<contentName.length; j++) {
				contentTemp += '<option value='+contentName[j]+'>'+contentName[j]+'</option>';
			}
			var draftTemp = '<div><table> <tr><td style="font-weight: bold;width: 32%;">select draft</td><td> <select id = "drafts_letters" name ="draftLetter"> <option value ="">Select</option></div>';
			for(var k=0; k<draftLetter.length; k++) {
				draftTemp += '<option value = '+draftLetter[k]["balettersid"]+'>' +draftLetter[k]["name"]+'</option>';
			}

                        textBox = '</td></tr></table><br><body><textarea style="width: 70%;"cols="80" id="content_template" name="ContentTemplate" rows="10"></textarea><span style="margin-left: 10%;"><button type="button" onclick="Save_draft_letter(['+recordNo+'])">Save Draft</button><button type="button" onclick="printPdf(0,['+recordNo+'])">Preview</button><button type="submit" name="options" value="download">Download</button><button type="button" onclick="printPdf(1,['+recordNo+'])">Print</button><button type="button"  onclick="sendEmail(['+recordNo+'])" >Send as Email</button></span></body>';


		        $('#model').append(headers);
			$('#model').append(contentTemp);
			$('#model').append(draftTemp);
                        $("#model").append(textBox);
                        jQuery("#modelPage").modal('show');
		$('#content_template').ready(function(){

                        var noteContentElement =$('#content_template');
                        noteContentElement.addClass('ckEditorSource');
                        var ckEditorInstance = new Vtiger_CkEditor_Js();
                        ckEditorInstance.loadCkEditor(noteContentElement);
		});
                }
        });
	$(document).on('change','#select_content_template',function(){
		if(this.value !='') {
			var selectedContentName = this.value;
			$.ajax({
				type:'POST',
				data:{'contentTemplateName':selectedContentName,'call':'getContent'},
				datatype:'JSON',
				url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate',
				success:function(data){
					
					var selectedContent = JSON.parse(data);
					CKEDITOR.instances['content_template'].insertHtml(selectedContent);
				}
			});
		}
	});
		   
	$(document).on('change','#drafts_letters',function(){
		if(this.value !='') {
			var letterId = this.value;
       			$.ajax({
                        	type:'POST',
                       	 	data:{'call':'getDraftRecords','letterId':letterId},
                        	datatype:'JSON',
                        	url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate',
                        	success:function(data){
                        	        letterContent = JSON.parse(data);
					 CKEDITOR.instances['content_template'].insertHtml(letterContent);
                        	}
                	});        
		}
	});

}
function Save_draft_letter(record_no){
      var progressIndicatorElement = jQuery.progressIndicator({
                'message' : 'Loading...',
                'position' : 'html',
                'blockInfo' : {
                        'enabled' : true
                        },
                });

                var fileName = document.getElementById('HeaderTemplateName').value;
                var Content = CKEDITOR.instances['content_template'].getData();
		if(Content !="" && fileName !=""){
        	        var fileName = document.getElementById('HeaderTemplateName').value;
			 $.ajax({
        	                type:'POST',
        	                datatype: 'JSON',
                	        data:{'options':'Draft','PdffileName':fileName,'ContentTemplate':Content,'recordId':record_no},
                  		url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate&mode=pdf',
                        	success:function(data){
	                                progressIndicatorElement.progressIndicator({
                                                'mode' : 'hide'
	                                });
				
					data = JSON.parse(data);
					if(data == "success") {
						alert("Saved to Draft");
					}else {
						 alert("Can not Save Draft");
					}
				}
			});	
		}else {
			alert('please fill the fields');
		}
	
}
function Letter_Download(recordNo){
      var progressIndicatorElement = jQuery.progressIndicator({
                'message' : 'Loading...',
                'position' : 'html',
                'blockInfo' : {
                        'enabled' : true
                        },
                });

	var Content = CKEDITOR.instances['content_template'].getData();
        var header = document.getElementById('header_template').value;
        var fileName = document.getElementById('HeaderTemplateName').value;
        if(Content !="" && fileName !=""){
                $.ajax({
                        type:'POST',
                        datatype: 'JSON',
                        data:{'options':'download','headername':header,'PdffileName':fileName,'ContentTemplate':Content,'recordId':recordNo},
                        url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate&mode=pdf',
                        success:function(data){
                                        progressIndicatorElement.progressIndicator({
                                                'mode' : 'hide'
                                        });

			}
		});
	}else{alert("Please Fill the Fields");}
}

function sendEmail(recordNo) {

      var progressIndicatorElement = jQuery.progressIndicator({
                'message' : 'Loading...',
                'position' : 'html',
                'blockInfo' : {
                        'enabled' : true
                        },
                });

        var Content = CKEDITOR.instances['content_template'].getData();
        var header = document.getElementById('header_template').value;
        var fileName = document.getElementById('HeaderTemplateName').value;
	if(Content !="" && fileName !=""){
                $.ajax({
                        type:'POST',
                        datatype: 'JSON',
                        data:{'options':'sendEmail','headername':header,'PdffileName':fileName,'ContentTemplate':Content,'recordId':recordNo},
                        url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate&mode=pdf',
                        success:function(data){
				progressIndicatorElement.progressIndicator({
                                                'mode' : 'hide'
                                });
                                var letterID = JSON.parse(data);
				
	console.log(data);
                                var currentInstance = Vtiger_Detail_Js.getInstance();
                                var parentRecord = new Array();
                                var params = {};
                                parentRecord.push(currentInstance.getRecordId());
                                params['module'] = "Contacts";
                                params['view'] = "MassActionAjax";
                                params['selected_ids'] = recordNo;
                                params['send_Mail_With_Letter'] =letterID;
                                params['mode'] = "showComposeEmailForm";
                                params['step'] = "step1";
                                params['relatedLoad'] = true;
//console.log(params);
                                Vtiger_Index_Js.showComposeEmailPopup(params);
                        }
       	        });
	} else {
		alert("Please Fill the Fields");
	}	
}
function printPdf(action,recordId){
      var progressIndicatorElement = jQuery.progressIndicator({
                'message' : 'Loading...',
                'position' : 'html',
                'blockInfo' : {
                        'enabled' : true
                        },
                });

        var contents = CKEDITOR.instances['content_template'].getData();
        var header = document.getElementById('header_template').value;
        var fileName = document.getElementById('HeaderTemplateName').value;
	if(contents !="" && fileName !=""){
		 var content = window.open();
        	 $.ajax({
                        type:'POST',
                        datatype: 'JSON',
                        data:{'headername':header,'options':'print','recordId':recordId,'ContentTemplate':contents},
                        url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate&mode=pdf',
                        success:function(data){
                                progressIndicatorElement.progressIndicator({
                                                'mode' : 'hide'
                                });

                                var data = JSON.parse(data);
				var headerData = data.headerTemp;
				var contentData = data.contentTemp;
                                content.document.write(headerData+"<br><br>");
                                content.document.write("<br><br>"+contentData+"<br>");
				if(action == 0) {	
                                	content;
				} else {
					content.print();
				}
                        }
                });
	}else {
		alert("Please fill the Fields");
	}	
}
function count_selected_recordfn(record){
	//  Selected Records 
        var items=document.getElementsByClassName('listViewEntriesCheckBox');
        var selectedItems=new Array;
        for(var i=0; i<items.length; i++){
            if(items[i].type=='checkbox' && items[i].checked==true)
                selectedItems.push(items[i].value);
        }
	return selectedItems;
}

function openTextEditor(){

        var recordNo = count_selected_recordfn();
        if(recordNo != '') {        
//	console.log(recordNo);
	        $.ajax({
	                type:'POST',
	                data:{'call':'getHeaders'},
	                datatype:'JSON',
	                url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate',
	                success:function(data){
	                        var data = JSON.parse(data);
	                        var headerName = data.headers;
	                        var contentName = data.contents;
	                        var draftLetter = data.draft;
	                        $("#model").html('');
	
	                        var headers = '<input type="hidden" name ="ViewPage" value= "ListViewRecords" /> <input id="recordId" type="hidden" name ="recordId" value= '+recordNo+' /><div style="float: right;"></div><table><tr><td style="font-weight: bold;width: 27%;" >File name</td><td><input id="HeaderTemplateName" type="text" name ="PdffileName" required/></td></tr><tr><td style="font-weight: bold;width: 27%;"> Header Template</td><td><select id="header_template"  name = "headername" required><option value="">Select</option>';
	                        var textBox = '';

	                        for(var i=0;i<headerName.length;i++){
	                                headers +='<option value='+headerName[i]+'>'+headerName[i]+'</option>';
	                        }
	                        var contentTemp = '<table><tr><td style="font-weight: bold;width: 20%;">Content Templates</td><td><select id="select_content_template" name="content_temp"><option value="">select</option> ';
	                        for(var j=0; j<contentName.length; j++) {
	                                contentTemp += '<option value='+contentName[j]+'>'+contentName[j]+'</option>';
	                        }
	                        var draftTemp = '<div><table> <tr><td style="font-weight: bold;width: 32%;">select draft</td><td> <select id = "drafts_letters" name ="draftLetter"> <option value ="">Select</option></div>';
	                        for(var k=0; k<draftLetter.length; k++) {
	                                draftTemp += '<option value = '+draftLetter[k]["balettersid"]+'>' +draftLetter[k]["name"]+'</option>';
	                        }
	
	                        textBox = '</td></tr></table><br> <body> <textarea cols="80" id="content_template" name="ContentTemplate"></textarea> </body><span style="margin-left: 10%;"><button type="button" onclick="Save_draft_letter(['+recordNo+'])">Save Draft</button><button type="button" onclick="printPdf(0,['+recordNo+'])">Preview</button><button type="submit" name="options" value="download">Download</button><button type="button" onclick="printPdf(1,['+recordNo+'])">Print</button><button type="button"  onclick="sendEmail(['+recordNo+'])" >Send as Email</button></span>';

	                        $('#model').append(headers);
	                        $('#model').append(contentTemp);
	                        $('#model').append(draftTemp);
	                        $("#model").append(textBox);
	                        jQuery("#modelPage").modal('show');
	
	        	        $('#content_template').ready(function(){
					CKEDITOR.replace('content_template');
		             	 });
	                }
	        });
	
	        $(document).on('change','#select_content_template',function(){
	                if(this.value !='') {
	                        var selectedContentName = this.value;
	                        $.ajax({
	                                type:'POST',
	                                data:{'contentTemplateName':selectedContentName,'call':'getContent'},
	                                datatype:'JSON',
	                                url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate',
	                                success:function(data){
	
	                                        var selectedContent = JSON.parse(data);
	                                        CKEDITOR.instances['content_template'].insertHtml(selectedContent);
	                                }
	                        });
	                }
	        });

	        $(document).on('change','#drafts_letters',function(){
	                if(this.value !='') {
	                        var letterId = this.value;
	                        $.ajax({
	                                type:'POST',
	                                data:{'call':'getDraftRecords','letterId':letterId},
	                                datatype:'JSON',
	                                url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate',
	                                success:function(data){
	                                        letterContent = JSON.parse(data);
	                                         CKEDITOR.instances['content_template'].insertHtml(letterContent);
	                                }
	                        });
	                }
	        });
	} else {
		alert("Please Select a Record");
	}
}	

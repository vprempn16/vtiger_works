<?php
require_once('modules/Vtiger/actions/TagCloud.php');	
class BALetters_SaveTagNames_Action extends Vtiger_Index_View {
	public function process(Vtiger_Request $request) {

		global $current_user, $adb;
		$tagName = $_POST['tagName'];
		$userId = $current_user->id;
		$recordId = $_POST['recordId'];
		$tagColor = $_POST['tagColor'];
		$existTag = $_POST['existTag'];
		$option = $_POST['option'];	

		if($option == 'add') {
                	$getCountOfTagId = $adb->pquery("select id from vtiger_freetags_seq");
                        $CountOfTagId = $adb->query_result($getCountOfTagId,0 , 'id' );
                        $CountOfTagId++;

                        $adb->pquery("insert into vtiger_freetags(id,tag,raw_tag) values(?,?,?)",array($CountOfTagId, $tagName, $tagName) );  
			$adb->pquery("insert into vtiger_srba_tag_letter(tag_name,tag_color) values(?, ?)", array($tagName,$tagColor)); 
                        $adb->pquery(" update vtiger_freetags_seq set id = ?",array($CountOfTagId) );
                }
		

		if($option == 'save') {

				$getBATagName = $adb->pquery("select tag_name from vtiger_srba_tag_letter where record_id = ?",array($recordId));
				$srTagName = $adb->query_result( $getBATagName, 0 , 'tag_name'); 
				if( $srTagName != null ) {
					$adb->pquery("update vtiger_srba_tag_letter set record_id = NULL where record_id =? ", array($recordId) );
						
				}		
			for($i = 0; $i < count($existTag); $i ++ ) {

				$getTagid = $adb->pquery("select id from vtiger_freetags where tag = ?",array(trim($existTag[$i]," ") ) );
				$tagId = $adb->query_result($getTagid,0,'id');
				$getCheckTag = $adb->pquery("select tag_id from vtiger_freetagged_objects where object_id = ? and tag_id = ?", array($recordId, $tagId) );	
				$checkTag =  $adb->query_result( $getCheckTag,0,'tag_id');
				if($checkTag == '') {
					$adb->pquery("insert into vtiger_freetagged_objects(tag_id,tagger_id,object_id,module) values(?,?,?,?)",array($tagId,$userId,$recordId,"BALetters"));
				}
				$adb->pquery("update vtiger_srba_tag_letter set record_id  = ? where tag_name = ? ",array($recordId,$existTag[$i]));
			}
		}		
	}
}	

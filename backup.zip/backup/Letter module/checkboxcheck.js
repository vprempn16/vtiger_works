
// Filter Page 



// ---------

// CheckBox
var ba_count=0;
var message = "Selected records : ";
var checkMainCheckBox = 0;
var checkMailManager =0;
checkMainCheckBox = $('#listViewEntriesMainCheckBox').val();
checkMailManager = $('#parentCheckBox').val();
if(checkMainCheckBox == 'on'){
	CreateTags();
}else if(checkMailManager != 'on'){
	setTimeout(CreateTags, 4000);	
}
	if(checkMainCheckBox == 'on' || checkMailManager == 'on'){
		// When Click a checkbox this function will execute (Count will be update)
		$(document).on('click','input[type="checkbox"]',function(){
	            if($(this).prop("checked") == true){
				var chkbx =$(this).val();
				if(chkbx >=0 ){
					 ba_count = ba_count+1;
					 ba_display(ba_count);
				}
        	    }else if($(this).prop("checked") == false){
				var chkbx = $(this).val();
				if(chkbx >=0 ){
					ba_count = ba_count-1;
					ba_display(ba_count);
			}
            	}
        	});
	}
	//Main checkbox for other modules (execpt MailManager)
 $('#listViewEntriesMainCheckBox').on('click',function(){
	if($(this).prop('checked') == true){
		flag =0;	
	        countRecords(flag);
		
	}else{
		flag =1;
		countRecords(flag);
	}
     });
		// Mail Manager Main checkbox 
 $(document).on('click','#parentCheckBox',function(){
        if($(this).prop("checked") == true){
                flag =0;
                countRecords(flag);

        }else{
                flag =1;
                countRecords(flag);
        }
    });


	// Create Division tags for Print the message and count  
function CreateTags(){
	checkMailManager = $('#parentCheckBox').val();
	if(checkMainCheckBox == 'on'){
			// For Other Modules 
                $("#listViewContents").after("<div id ='ba_count_result'></div>");
                $('.topscroll-div').after("<div id = 'ba_count_results'></div>");
                ba_display(ba_count);

	}else if(checkMailManager == 'on'){ 
		   //For MailManager module
                $(".listViewContentDiv").before("<div id ='ba_count_result'></div>");
                $('.listViewContentDiv').after("<div id = 'ba_count_results'></div>");
                ba_display(ba_count);
        }

 
}
function countRecords(chk){	// Count All CheckBoxes
	var flag = chk;
	var ba_count = $("input:checkbox").length;
	ba_count--;
	if(flag == 0 ){
		ba_display(ba_count);		
	}else{
		ba_count=0;
		ba_display(ba_count);
		}
	window.ba_count=ba_count;
}

function ba_display(n){		//Display the Number of Checkboxes are Checked.
	var ba_count = n;
	if(ba_count>0){
                document.getElementById('ba_count_result').style.display='block';
                document.getElementById('ba_count_results').style.display='block';

		document.getElementById('ba_count_result').innerHTML=message+ba_count;
	        document.getElementById('ba_count_results').innerHTML=message+ba_count;
	}else if(ba_count<=0){
                document.getElementById('ba_count_result').style.display='none';
		document.getElementById('ba_count_results').style.display='none';
	}
	
}
//       Chech Box end




//----------------------	Filter Page in Send Email	-------------------------

$(document).on('change','#customFilter',function(){
	var currentPageLocation = "index.php?view=Popup&module=Documents&src_module=Emails&src_field=composeEmail&triggerEventName=postSelection8037";
	var nextPageId = $(this).val();
	if(nextPageId >=0 ){
		var nextPage = currentPageLocation+'&viewname='+nextPageId;
		
	}else{
		var nextPageId = nextPageId.replace(" ", "+");
		nextPage = currentPageLocation+'&folder_id=folderid&folder_value='+nextPageId;
	}
              window.location.assign(nextPage);       

});

//	----------End in Filter Page----------------------

//	Attach Documents To Mail 

$(document).on('change','#AttachtAllDocument',function(){
	if($('#AttachtAllDocument').prop("checked")==true){
		$('.Show_custom_upload_files').hide();	
	}else{
		$('.Show_custom_upload_files').show();
	}
});

//	**************			*********************
function FilterCustomDocuments(key)
{
	var boxId = '#custom_Filter'+key;
		var checkBoxValue = ($(boxId).prop("checked") == true);
		if(checkBoxValue == true){
			var active = 1;
		}else{
			var active = 0;
		}	
		$.ajax({
			type:'POST',
			data:{'id':key,'fileStatus':active},
			
url:'index.php?parent=Settings&module=Vtiger&view=UpdateCustomDocument&task=filter',
			success:function(data){	}
		});
}
//************		  Header Template		************

function openRichTextEditor(recordId){
	var recordNo = recordId;
	$.ajax({
		type:'POST',
		data:{'call':'getHeaderTemplateNames'},
		datatype:'JSON',
		url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate',
		success:function(data){
			var data = JSON.parse(data);
			var headerName = data;//.headers;
		//	var contentName = data.contents;
			$("#model").html('');
			var headers = ' <input id="recordId" type="hidden" name ="recordId"value='+recordNo+' /><table><tr><td style="font-weight: bold;width: 27%;" >File name</td><td><input id="HeaderTemplateName" type="text" name ="PdffileName" required/></td></tr><tr><td style="font-weight: bold;width: 27%;"> Header Template</td><td><select id="header_template"  name = "headername" required><option value="">Select</option>';				
			for(var i=0;i<headerName.length;i++) {
				headers +='<option value='+headerName[i]+'>'+headerName[i]+'</option>';
			}
		//	var contentTemp = '</td></tr><tr><td style="font-weight: bold;width: 27%;">Content Templates</td><td><select id="select_content_template" name="content_temp"><option value="">select</option> ';
		//	for(var j=0; j<contentName.length; j++) {
		//		contentTemp += '<option value='+contentName[j]+'>'+contentName[j]+'</option>';
		//	}
			textBox = '</select></td></tr></table><br><textarea style="width: 70%;"cols="80" id="content_template" name="ContentTemplate" rows="10"></textarea><span style="margin-left: 20%;"><button type="submit" name="options" value="download">Download</button><button type="button" onclick="printPdf('+recordNo+')">Print</button><button type="button"  onclick="sendEmail('+recordNo+')" >Send as Email</button></span>';

			$('#model').append(headers);
		//	$('#model').append(contentTemp);
			$("#model").append(textBox); 
			jQuery("#modelPage").modal('show');
	//		CKEDITOR.replace('#contant_template');
			var noteContentElement =$('#content_template');
                        noteContentElement.addClass('ckEditorSource');
                        var ckEditorInstance = new Vtiger_CkEditor_Js();
                        ckEditorInstance.loadCkEditor(noteContentElement);
		}
	});

// Add content templates 
/*
	$(document).on('change','#select_content_template',function(){
		if(this.value !='') {
			var selectedContentName = this.value;
			$.ajax({
				type:'POST',
				data:{'contentTemplateName':selectedContentName,'call':'getContent'},
				datatype:'JSON',
				url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate',
				success:function(data){
					
					var selectedContent = JSON.parse(data);
					CKEDITOR.instances['content_template'].insertHtml(selectedContent);
				}
			});
		}
	});
*/
	
}
function sendEmail(recordNo) {

/*	var progressIndicatorElement = jQuery.progressIndicator({
		'message' : 'Loading...',
		'position' : 'html',
		'blockInfo' : {
			'enabled' : true
			},
		});
*/
		var Content = CKEDITOR.instances['content_template'].getData();
		var header = document.getElementById('header_template').value;
		var fileName = document.getElementById('HeaderTemplateName').value;
		$.ajax({
			type:'POST',
			datatype: 'JSON',
			data:{'options':'sendEmail','headername':header,'PdffileName':fileName,'ContantTemplate':Content,'recordId':recordNo},
			url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate&mode=pdf',
			success:function(data){
				var letterID = JSON.parse(data);
		                var currentInstance = Vtiger_Detail_Js.getInstance();
		                var parentRecord = new Array();
		                var params = {};
		                parentRecord.push(currentInstance.getRecordId());
		                params['module'] = "Contacts";
		                params['view'] = "MassActionAjax";
		                params['selected_ids'] = recordNo;
				params['send_Mail_With_Letter'] =letterID;
		                params['mode'] = "showComposeEmailForm";
		                params['step'] = "step1";
		                params['relatedLoad'] = true;
		                Vtiger_Index_Js.showComposeEmailPopup(params);
				
			var ss =  '<div class="MultiFile-label"><a class="removeAttachment cursorPointer" data-id='+letterID.id+' data-file-size='+selectedFileSize+'>x </a><span>'+letterID.id+'</span></div>';
			$('.MultiFile-label').after(ss);
			}
				
		});
}

function printPdf(recordId){

        var Content = CKEDITOR.instances['content_template'].getData();
        var header = document.getElementById('header_template').value;
        var fileName = document.getElementById('HeaderTemplateName').value;
	var content = window.open();

	 $.ajax({
                        type:'POST',
                        datatype: 'JSON',
                        data:{'headername':header,'options':'print'},
                        url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate&mode=pdf',
                        success:function(data){		
				var header = JSON.parse(data);
				content.document.write("<br>"+header+"<br><br>");
				content.document.write(Content+"<br>");
				content.print();
				}
		});
}
/*	$('#header_template').ready(function(){
                                var noteContentElement =$('header_template');
                                noteContentElement.addClass('ckEditorSource');
                                var ckEditorInstance = new Vtiger_CkEditor_Js();
                                ckEditorInstance.loadCkEditor(noteContentElement);
        cosole.log(noteContentElement);
      });
*/
function openTextEditor(id){
	 $.ajax({
                type:'POST',
                data:{'call':'ajaxcall'},
                datatype:'JSON',
                url:'index.php?parent=Settings&module=Vtiger&view=HeaderTemplate',
                success:function(data){
                        var data = JSON.parse(data);
                        for(var i=0;i<data.length;i++){
                                var filename = data[i];
                        }

                        $("#model").html('');

//			var headSection = '<head><script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script><link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css" rel="stylesheet"><script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script><script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js" defer></script></head>';
                        var headers = '<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.2/summernote.js"></script> <input id="recordId" type="hidden" name ="recordId"value="" /><table><tr><td style="font-weight: bold;width: 27%;" >File name</td><td><input id="HeaderTemplateName" type="text" name ="PdffileName" required/></td></tr><tr><td style="font-weight: bold;width: 27%;"> Header Template</td><td><select id="header_template"  name = "headername" required><option value="">Select</option>';
                        var textBox = '';

                        for(var i=0;i<data.length;i++){
                                headers +='<option value='+data[i]+'>'+data[i]+'</option>';
                        }

                        textBox = '</td></tr></table><br><div id="summernote"></div><span style="margin-left: 20%;"><button type="submit" name="options" value="download">Download</button><button type="button" onclick="printPdf()">Print</button><button type="button"  onclick="sendEmail()" >Send as Email</button></span>';
	
		//	$('#model').append(headSection);
                        $('#model').append(headers);
                        $("#model").append(textBox);
                        jQuery("#modelPage").modal('show');
	

			$('#summernote').summernote('code');
                }
        });

}

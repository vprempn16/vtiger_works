<?php

//ini_set('display_errors','on'); error_reporting(E_ALL);
//use Sabre\DAV;
//use Sabre\DAV\Client;

//require 'vendor/autoload.php';

class Synology_List_View extends Vtiger_Index_View
{
    public function process(Vtiger_Request $request)
    {
        session_start();
        global $site_URL, $adb;

        if ($_GET['operation'] == 'getFiles') {
            $getFiles = $this->getCurrentPathFiles($_GET['path']);
            echo $getFiles;
            die;
        }

        if($_GET['operation'] == 'deleteFile'){
            $filePath = $_GET['filePath'];          
            if( file_exists($filePath) ){
                $path = substr($filePath , 0, strripos( $filePath , '/'));
                unlink($filePath);
                $getFiles = $this->getCurrentPathFiles($path);
                echo $getFiles;
                die;

//            echo "<pre>"; print_R($path); die;
            } 
        }

        if($_GET['operation'] == 'downloadFile'){
            $filePath = $_GET['filePath'];

            if( file_exists($filePath) ){
                $file_path = $filePath;
                $filename = basename($filePath);
                $ext = pathinfo($filePath, PATHINFO_EXTENSION);
                $type = mime_content_type($filePath);

                if($ext == 'pdf'){
                    $type = 'application/pdf';
                }

                header("Content-Type: application/force-download");
                header("Content-type: ".$type);
                header('Content-Disposition: attachment; filename=' . $filename);
                header('Content-Transfer-Encoding: binary');
                header('Expires: 0');
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Pragma: public');
                header('Content-length: ' . filesize($file_path));
                ob_clean();
                flush();
                readfile($file_path);
                die;
            }
   
        }

        if($_GET['operation'] == 'UploadFile'){


            $fileTmpPath = $_FILES['file']['tmp_name'];    
              $file_name = $_FILES['file']['name'];
              $file_size =$_FILES['file']['size'];
              $file_tmp =$_FILES['file']['tmp_name'];
              $file_type=$_FILES['file']['type'];
              $file_ext=strtolower(end(explode('.',$_FILES['file']['name'])));
              
              $targetFilePath = $_POST['file_path'].'/'.$file_name;

              if( move_uploaded_file($fileTmpPath , $targetFilePath) ){
                header('Location:index.php?module=Synology&view=List');die;
              }
         }

        $getFolderPath = $adb->pquery('select * from vtiger_ba_folder_mapping');
        $getConfigData = $adb->query_result($getFolderPath, 0, 'config_data');
        $getUsername = $adb->pquery('select user_name from vtiger_users where id = ?', array($_SESSION['AUTHUSERID']));
        $current_username = $adb->query_result($getUsername, 0, 'user_name');

        if ($getConfigData) {
            $configData = unserialize(base64_decode($getConfigData));
            $folderPath = $configData['root_path'] . $configData['path_' . $current_username];
        }
        
        if( isset($configData['write_permission_'.$current_username])){
            $_SESSION["permissions"]['write'] = true;
        } else {
            unset( $_SESSION["permissions"]['write'] );
        }
        if( isset($configData['read_permission_'.$current_username])){
            $_SESSION["permissions"]['read'] = true;
        }else {
            unset( $_SESSION["permissions"]['read'] );
        }
        if( isset($configData['delete_permission_'.$current_username])){
            $_SESSION["permissions"]['delete'] = true;
       }else {
            unset( $_SESSION["permissions"]['delete'] );     
        }

        if (!is_dir($folderPath)) {
            mkdir($folderPath, 0777, true);
        }

        if ($_GET['operation'] == 'createNode') {
                $parent = $_GET['parent'];
                $newNode = $_GET['newNode'];
                $newFolderPath = $parent .'/'. $newNode;

                if (!is_dir($newFolderPath)) {
                    mkdir($newFolderPath, 0777, true);
                }

                $getAllItems = $this->getFilesAndDirectories($folderPath);
                echo $getAllItems; die;
                
        }

        $getAllItems = $this->getFilesAndDirectories($folderPath);
        $getFiles = $this->getCurrentPathFiles($folderPath);

        $viewer = $this->getViewer($request);
        $viewer->assign('SERVER_URL', $site_URL . '/WebDAVServer.php');
        $viewer->assign('FILES_FOLDERS', $getAllItems);
        $viewer->assign('FILES', $getFiles);
        $viewer->assign('PERMISSION', $_SESSION["permissions"] );

        $qualifiedName = $request->getModule(false);
        $viewer->view('List.tpl', $qualifiedName);
    }

    /**
     * Return files only
     * 
     * @path string
     */
    public function getCurrentPathFiles($path)
    {
        $isEmptyFolder = 1;
        $files = scandir($path);
        unset($files[0]);
        unset($files[1]);

        $lastCharator = substr($path , -1);
        if( $lastCharator != '/'){
            $path = $path.'/';
        }

        $html = '<h3> Files </h3> <hr> <div class="row-fluid"> <input type="hidden" value="' . $path . '" id="current_target_file_path">';
        foreach ($files as $file) {
            if (!is_dir($path . $file)) {
                $isEmptyFolder = 0;

                $ext = pathinfo($path.$file, PATHINFO_EXTENSION);
                if($ext == 'pdf'){
                    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="40" fill="currentColor" class="bi bi-file-earmark-pdf" viewBox="0 0 16 16">
  <path d="M14 14V4.5L9.5 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2zM9.5 3A1.5 1.5 0 0 0 11 4.5h2V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h5.5v2z"/>
  <path d="M4.603 14.087a.81.81 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.68 7.68 0 0 1 1.482-.645 19.697 19.697 0 0 0 1.062-2.227 7.269 7.269 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.188-.012.396-.047.614-.084.51-.27 1.134-.52 1.794a10.954 10.954 0 0 0 .98 1.686 5.753 5.753 0 0 1 1.334.05c.364.066.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.856.856 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.712 5.712 0 0 1-.911-.95 11.651 11.651 0 0 0-1.997.406 11.307 11.307 0 0 1-1.02 1.51c-.292.35-.609.656-.927.787a.793.793 0 0 1-.58.029zm1.379-1.901c-.166.076-.32.156-.459.238-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361.01.022.02.036.026.044a.266.266 0 0 0 .035-.012c.137-.056.355-.235.635-.572a8.18 8.18 0 0 0 .45-.606zm1.64-1.33a12.71 12.71 0 0 1 1.01-.193 11.744 11.744 0 0 1-.51-.858 20.801 20.801 0 0 1-.5 1.05zm2.446.45c.15.163.296.3.435.41.24.19.407.253.498.256a.107.107 0 0 0 .07-.015.307.307 0 0 0 .094-.125.436.436 0 0 0 .059-.2.095.095 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a3.876 3.876 0 0 0-.612-.053zM8.078 7.8a6.7 6.7 0 0 0 .2-.828c.031-.188.043-.343.038-.465a.613.613 0 0 0-.032-.198.517.517 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822.024.111.054.227.09.346z"/>
</svg>';
                } elseif( $ext == 'png' || $ext == 'jpg' || $ext == 'jpeg' || $ext == 'psd' ){
                    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="40" fill="currentColor" class="bi bi-file-earmark-image" viewBox="0 0 16 16">
  <path d="M6.502 7a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/>
  <path d="M14 14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5V14zM4 1a1 1 0 0 0-1 1v10l2.224-2.224a.5.5 0 0 1 .61-.075L8 11l2.157-3.02a.5.5 0 0 1 .76-.063L13 10V4.5h-2A1.5 1.5 0 0 1 9.5 3V1H4z"/>
</svg>';
                } elseif($ext == 'mp3'){
                    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="40" fill="currentColor" class="bi bi-file-earmark-music" viewBox="0 0 16 16">
  <path d="M11 6.64a1 1 0 0 0-1.243-.97l-1 .25A1 1 0 0 0 8 6.89v4.306A2.572 2.572 0 0 0 7 11c-.5 0-.974.134-1.338.377-.36.24-.662.628-.662 1.123s.301.883.662 1.123c.364.243.839.377 1.338.377.5 0 .974-.134 1.338-.377.36-.24.662-.628.662-1.123V8.89l2-.5V6.64z"/>
  <path d="M14 14V4.5L9.5 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2zM9.5 3A1.5 1.5 0 0 0 11 4.5h2V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h5.5v2z"/>
</svg>';
                } elseif($ext == 'zip'){
                    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="40" fill="currentColor" class="bi bi-file-earmark-zip" viewBox="0 0 16 16">
  <path d="M5 7.5a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v.938l.4 1.599a1 1 0 0 1-.416 1.074l-.93.62a1 1 0 0 1-1.11 0l-.929-.62a1 1 0 0 1-.415-1.074L5 8.438V7.5zm2 0H6v.938a1 1 0 0 1-.03.243l-.4 1.598.93.62.929-.62-.4-1.598A1 1 0 0 1 7 8.438V7.5z"/>
  <path d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5zm-3 0A1.5 1.5 0 0 1 9.5 3V1h-2v1h-1v1h1v1h-1v1h1v1H6V5H5V4h1V3H5V2h1V1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V4.5h-2z"/>
</svg>';
                } else {
                    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="40" fill="currentColor" class="bi bi-file-earmark" viewBox="0 0 16 16">
  <path d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5zm-3 0A1.5 1.5 0 0 1 9.5 3V1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V4.5h-2z"/>
</svg>';
                }
                
                $deleteIcon = '';
                if(array_key_exists('delete', $_SESSION['permissions']) ){
                $deleteIcon = '<span style="padding: 1px; cursor: pointer;" class="delete_file" data-path="'.$path.$file.'"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
</svg> </span>';
                }
                

                $infoIcon = '<span style="padding: 1px; cursor: pointer;" class="file_info" data-name="'.$file.'" data-type="'.$ext.'" data-size="'.filesize($path.$file).'"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-square" viewBox="0 0 16 16">
  <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
  <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg> </span>';
                
                $downloadIcon = '';
                if(array_key_exists('read', $_SESSION['permissions']) ){
                $downloadIcon = '<span style="padding: 1px; cursor: pointer;">  <a href="#" class="download_file" data-path="index.php?module=Synology&view=List&operation=downloadFile&filePath='.$path . $file.'" > <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
  <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/>
  <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/>
</svg> </a> </span>';
                }

                $html .= '<div class="span3" style="margin-bottom: 5px;" > <div class="thumbnail" style="text-align: center;"> '.$svg.' <div class="caption"> ' . $file . '</div> <div style="padding: 5px;">  '. $infoIcon . $downloadIcon . $deleteIcon .' </div> </div> </div>';
            }
        }

        if ($isEmptyFolder == 1) {
            $html .= ' <div class="alert">   <button type="button" class="close" data-dismiss="alert">&times;</button> <strong> File not yet uploaded. </strong> </div>  ';
        }
        $html .= '</div>';
        return $html;
    }

    /**
     * Return all files and folders
     * 
     * @path string
     */
    public function getFilesAndDirectories($path)
    {
        $html_fol = '';
        $html_file = '';
        $files = scandir($path);
        unset($files[0]);
        unset($files[1]);
        
        $lastCharator = substr($path , -1);
        if( $lastCharator != '/'){
            $path = $path.'/';
        }
        
        foreach ($files as $file) {

            if (is_dir($path . $file)) {
                $html_fol .= '<li data-path="' . $path . $file . '"> ' . $file;
                $html_fol .= $this->getFilesAndDirectories($path . $file);
                $html_fol .= '</li>';
            } else {
                $icon = "{'icon':'modules/Synology/public/img/file_png.png'}";
                $html_file .= '<li data-jstree="'.$icon.'">' . $file . '  </li>';
            }
        }
        $html = '<ul> ' . $html_fol . $html_file . '</ul> ';
        return $html;
    }
}

<?php
  
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';
//ini_set('display_errors','on'); error_reporting(E_ALL);
global $adb;

$nextNum = $adb->pquery('select id from vtiger_settings_field_seq');
$fieldId = $adb->query_result($nextNum, 0 , 'id');
$fieldId ++;
$adb->pquery("insert into vtiger_settings_field (fieldid,blockid,name,linkto)values($fieldId ,4 ,'Mapping Page Configration' ,'index.php?parent=Settings&module=Vtiger&view=MappingPageConfigure')");
$adb->pquery("update vtiger_settings_field_seq set id = ?",array($fieldId));

$adb->pquery("CREATE TABLE `vtiger_ba_folder_mapping` (`id` int(11) NOT NULL AUTO_INCREMENT, `config_data` longtext, PRIMARY KEY (`id`))");

 echo "Done";


<?php

class Settings_Vtiger_MappingPageConfigure_View extends Settings_Vtiger_Index_View {
    
    public function process(Vtiger_Request $request) {
    	global $adb;
				
    	$checkExist = $adb->pquery('select * from  vtiger_ba_folder_mapping' );
    	$recordExist = $adb->query_result($checkExist, 0 , 'id');
    	if(isset($_GET['mode']) && $_GET['mode'] == 'save'){
    		
    		if($recordExist){
    			$ss = $adb->pquery('update vtiger_ba_folder_mapping set config_data = ? where id = ?' , array(base64_encode( serialize($_POST)) ,$recordExist) );
			}else{
    			$ss = $adb->pquery('insert into vtiger_ba_folder_mapping (config_data) values (?) ' , array( base64_encode(serialize($_POST))));
			}
    		header('Location:index.php?parent=Settings&module=Vtiger&view=MappingPageConfigure');
    	} else {
    	$configData = [];
    	if($recordExist){
    		$getConfigData = $adb->query_result($checkExist, 0 , 'config_data');
    		$configData = unserialize(base64_decode($getConfigData));
    	}	
        $viewer = $this->getViewer($request);
        $qualifiedName = $request->getModule(false);
 
        $listViewModel = Vtiger_ListView_Model::getInstance('Users');
        $pagingModel = new Vtiger_Paging_Model();
        $getUserList = $listViewModel->getListViewEntries($pagingModel);
        

        $viewer->assign('USERS' , $getUserList );
		$viewer->assign('QUALIFIED_MODULE', $qualifiedName);
		$viewer->assign('CONFIG_DATA' , $configData);
        $viewer->view('MappingPageConfigure.tpl',$qualifiedName);
    	}
    }
}

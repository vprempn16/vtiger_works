<?php
//ini_set('display_errors','on'); error_reporting(E_ALL);
//die('d');

class Synology_UploadFile_Action extends Vtiger_Save_Action {
    public function checkPermission(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $record = $request->get('record');

        if(!Users_Privileges_Model::isPermitted($moduleName, 'Save', $record)) {
            throw new AppException('LBL_PERMISSION_DENIED');
        }
    }

	public function process(Vtiger_Request $request) {
        
            echo " <pre>"; print_r($_FILES); die;
/*
		$result = Vtiger_Util_Helper::transformUploadedFiles($_FILES, true);
		$_FILES = $result['imagename'];

		//To stop saveing the value of salutation as '--None--'
		$salutationType = $request->get('salutationtype');
		if ($salutationType === '--None--') {
			$request->set('salutationtype', '');
		}
		parent::process($request);
*/
}
}

<?php

//ini_set('display_errors','on'); error_reporting(E_ALL);
use Sabre\DAV;
use Sabre\DAV\Client;

require 'vendor/autoload.php';

class Synology_List_View extends Vtiger_Index_View
{

    public function process(Vtiger_Request $request)
    {

        global $site_URL, $adb;

        if ($_GET['operation'] == 'getFiles') {
            $getFiles = $this->getCurrentPathFiles($_GET['path']);
            echo $getFiles;
            die;
        }

        if($_GET['operation'] == 'downloadFile'){
            $filePath = $_GET['filePath'];
            if( file_exists($filePath) ){

                $data = file_get_contents($filePath);
                //header('Content-Description: File Transfer');
                header('Content-Type: '.mime_content_type($filePath));
                header('Content-Disposition: attachment; filename="'.basename($filePath).'"');
                header('Expires: 0');
               // header('Cache-Control: must-revalidate');
                header('Pragma: no-cache');
                header("Content-Transfer-Encoding: binary");
                header("Content-Length: ".strlen($data));
                flush(); // Flush system output buffer
                readfile($filePath);
                die();

            }
   
            //echo json_encode($data); die; 

        }

        if($_GET['operation'] == 'UploadFile'){

            $fileTmpPath = $_FILES['file']['tmp_name'];    
              $file_name = $_FILES['file']['name'];
              $file_size =$_FILES['file']['size'];
              $file_tmp =$_FILES['file']['tmp_name'];
              $file_type=$_FILES['file']['type'];
              $file_ext=strtolower(end(explode('.',$_FILES['file']['name'])));
              
              $targetFilePath = $_POST['file_path'].'/'.$file_name;

              if( move_uploaded_file($fileTmpPath , $targetFilePath) ){
                header('Location:index.php?module=Synology&view=List');die;
              }
         }

        $getFolderPath = $adb->pquery('select * from vtiger_ba_folder_mapping');
        $getConfigData = $adb->query_result($getFolderPath, 0, 'config_data');
        $getUsername = $adb->pquery('select user_name from vtiger_users where id = ?', array($_SESSION['AUTHUSERID']));
        $current_username = $adb->query_result($getUsername, 0, 'user_name');

        if ($getConfigData) {
            $configData = unserialize(base64_decode($getConfigData));
            $folderPath = $configData['root_path'] . $configData['path_' . $current_username];
        }
        if (!is_dir($folderPath)) {
            mkdir($folderPath, 0777, true);
        }

        if ($_GET['operation'] == 'createNode') {
                $parent = $_GET['parent'];
                $newNode = $_GET['newNode'];
                $newFolderPath = $parent .'/'. $newNode;

                if (!is_dir($newFolderPath)) {
                    mkdir($newFolderPath, 0777, true);
                }
            //echo "<pre>"; print_r($newFolderPath);die;

                $getAllItems = $this->getFilesAndDirectories($folderPath);
                echo $getAllItems; die;
                
        }

        $getAllItems = $this->getFilesAndDirectories($folderPath);
        $getFiles = $this->getCurrentPathFiles($folderPath);

        $viewer = $this->getViewer($request);
        $viewer->assign('SERVER_URL', $site_URL . '/WebDAVServer.php');
        $viewer->assign('FILES_FOLDERS', $getAllItems);
        $viewer->assign('FILES', $getFiles);
        //$viewer->assign('PATH', $folderPath);

        $qualifiedName = $request->getModule(false);
        $viewer->view('List.tpl', $qualifiedName);
    }

    /**
     * Return files only
     * 
     * @path string
     */
    public function getCurrentPathFiles($path)
    {
        $isEmptyFolder = 1;
        $files = scandir($path);
        unset($files[0]);
        unset($files[1]);
        $html = '<h3> Files </h3> <hr> <div class="row-fluid"> <input type="hidden" value="' . $path . '" id="current_target_file_path">';
        foreach ($files as $file) {
            if (!is_dir($path . $file)) {
                $isEmptyFolder = 0;
                $html .= '<div class="span3" style="margin-bottom: 5px;" > <div class="thumbnail" style="text-align: center;"> <svg xmlns="http://www.w3.org/2000/svg" width="30" height="40" fill="currentColor" class="bi bi-file-earmark" viewBox="0 0 16 16">
  <path d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5zm-3 0A1.5 1.5 0 0 1 9.5 3V1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V4.5h-2z"/>
</svg> <div class="caption"> <a href="#" class="download_file" data-path="'.$path . $file.'">' . $file . ' </a></div> </div> </div>';
            }
        }
        if ($isEmptyFolder == 1) {
            $html .= ' <div class="alert">   <button type="button" class="close" data-dismiss="alert">&times;</button> <strong> File not yet uploaded. </strong> </div>  ';
        }
        $html .= '</div>';
        return $html;
    }

    /**
     * Return all files and folders
     * 
     * @path string
     */
    public function getFilesAndDirectories($path)
    {
        $html_fol = '';
        $html_file = '';
        $files = scandir($path);
        unset($files[0]);
        unset($files[1]);

        foreach ($files as $file) {

            if (is_dir($path . $file)) {
                $html_fol .= '<li data-path="' . $path . $file . '"> ' . $file;
                $html_fol .= $this->getFilesAndDirectories($path . $file);
                $html_fol .= '</li>';
            } else {
                $icon = "{'icon':'modules/Synology/public/img/file_png.png'}";
                $html_file .= '<li data-jstree="'.$icon.'">' . $file . '  </li>';
            }
        }
        $html = '<ul> ' . $html_fol . $html_file . '</ul> ';
        return $html;
    }
}

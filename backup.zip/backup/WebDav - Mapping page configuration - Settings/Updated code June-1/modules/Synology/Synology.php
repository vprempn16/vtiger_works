<?php
class Synology {}

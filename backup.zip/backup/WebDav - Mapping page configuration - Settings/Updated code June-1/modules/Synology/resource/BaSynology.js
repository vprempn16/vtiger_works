   $(function () { 
    $('#target_file_path').val($('#current_target_file_path').val());

    applyFileTree();

	   $(document).on("click", ".jstree-node", function (e) {
		   var filePath = $(this).closest('li').data('path');
		   if (filePath) {
			   $.ajax({
				   type: 'GET',
				   dataType: 'HTML',
				   data: { 'path': filePath },
				   url: 'index.php?module=Synology&view=List&operation=getFiles',
				   success: function (response) {
					   $(document).find('#files_list').html(response);
                       $('#target_path').val($('#current_target_file_path').val());
				   }
			   });
		   }
         console.log(filePath);
      });
       $('#target_path').val($('#current_target_file_path').val());
    });

function applyFileTree(){
          $('#jstree').on('click', '.jstree-anchor', function (e) {
            $(this).jstree(true).toggle_node(e.target);
        }).jstree({
              "core" : {
                "animation" : 0,
                "check_callback" : true,
                   
              },
              "plugins" : [
                "contextmenu", "dnd", "search", "state", "types", "wholerow", "changed"
            ],

        }).on('create_node.jstree', function(e, data) {
            console.log('saved');
        }).on('rename_node.jstree', function(e, data) {
            createNode(data);
    });
}
/*
function createNode(data){
    var name = data.node.text;
    var parentId = data.node.parents[0];
    var parentPath = $('#'+parentId).data('path');
    var newNodeId = data.node.id;
    var newNodePath = parentPath+'/'+name;
    if(name && parentPath){
        $.ajax({
                   type: 'GET',
                   data: { 
                        'parent': parentPath,
                        'newNode': name,
                    },
                   url: 'index.php?module=Synology&view=List&operation=createNode',
                   success: function (response) {
                    console.log(response);
                      //if(response == 'created'){
                       // $('#jstree').jstree(true).refresh();
                       console.log('d')
                        $('#'+newNodeId).attr('data-path', newNodePath );
                      //}
                   }
               });
    }
    console.log(name , parentPath , data.node);
}
*/

$(document).on('click', '#create_folder' , function(){
    var parent = $('#current_target_file_path').val();
    var newNode = $('#new_folder_name').val();
    console.log(parent , newNode);
    if(newNode && parent ){
            $.ajax({
                   type: 'GET',
                   dataType: 'HTML',
                   data: { 
                        'parent': parent,
                        'newNode': newNode,
                    },
                   url: 'index.php?module=Synology&view=List&operation=createNode',
                   success: function (response) {
                    //console.log(response);
                    $('#ba_create_folder').modal("toggle");
                    $('#file_tree_directories ').html('<div id="jstree">'+response+ '</div>');
                    applyFileTree();
                      //if(response == 'created'){
                       // $('#jstree').jstree(true).refresh();
                       //console.log('d')
                      //  $('#'+newNodeId).attr('data-path', newNodePath );
                      //}
                   }
               });
        }
});

$(document).on('click' , '.download_file' , function() {
    var path = $(this).data('path');
    if(path){
        var url = 'index.php?module=Synology&view=List&operation=downloadFile&filePath='+path;
        window.open( url , "_blank");
        /*
        $.ajax({
                   type: 'POST',
                //   dataType: 'JSON',
                   data: { 
                        'filePath': path,
                    },
                   url: 'index.php?module=Synology&view=List&operation=downloadFile',
                   success: function (response) {
                        console.log(response);
                        
                          var element = document.createElement('a');
                          element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(response));
                          element.setAttribute('download', 'test');

                          element.style.display = 'none';
                          document.body.appendChild(element);

                          element.click();

                          document.body.removeChild(element);
                        
                   }
               });
*/
    }
//console.log(path);

})
<?php
class DragNDrop_GetSelectedModule_View extends Vtiger_Index_View
{
	public function process (Vtiger_Request $request) {
		global $adb;
		$GetModules = $adb->pquery("select config_value from vtiger_ddd_settings where config_name = 'serialised_data' ");
		$serializeModules = $adb->query_result($GetModules, 0 , "config_value");
		$selectedModules = unserialize(base64_decode($serializeModules));
		echo json_encode($selectedModules);
	}
}

$(document).ready(function(){

	var JSFiles ='<div><script type="text/javascript" src="layouts/v7/modules/DragNDrop/resources/Custom.js"></script>              <script type="text/javascript" src="modules/DragNDrop/libs/jQueryFileUploader/js/vendor/jquery-ui-widget.js"></script>                  <script type="text/javascript" src="modules/DragNDrop/libs/jQueryFileUploader/js/jquery-iframe-transport.js"></script>                  <script type="text/javascript" src="modules/DragNDrop/libs/jQueryFileUploader/js/jquery-fileupload.js"></script>                                        <script type="text/javascript" src="modules/DragNDrop/libs/jQueryFileUploader/js/jquery-fileupload-process.js"></script>                        <script type="text/javascript" src="modules/DragNDrop/libs/jQueryFileUploader/js/jquery-fileupload-validate.js"></script>                       <script type="text/javascript" src="modules/DragNDrop/libs/jQueryFileUploader/js/main.js"></script></div>';

	$('.recordBasicInfo').before(JSFiles);

        $.ajax({
                type:"POST",
                datatype:JSON,
                data:{"GetInFo":"FetchDetails"},
                url:"index.php?module=DragNDrop&view=Widget",
                success:function(data) { 
               
                        $('.recordBasicInfo').after(data);
                }
        });
});



$(document).ready(function(){

var url = document.URL;
var sliceUrl = url.split('module=').pop();
var moduleName = sliceUrl.substring(0,sliceUrl.indexOf('&'));
	$.ajax({
		type: "POST",
		data: {"data":"Data"},
		datatpye : JSON,
		url:"index.php?module=DragNDrop&view=GetSelectedModule",
		success:function (data) {
			var data = JSON.parse(data);
			var activeStatus = data[moduleName];
			
			if(activeStatus == 'on') {	
	
				var JSFiles ='<div><script type="text/javascript" src="layouts/v7/modules/DragNDrop/resources/Custom.js"></script>              <script type="text/javascript" src="modules/DragNDrop/libs/jQueryFileUploader/js/vendor/jquery-ui-widget.js"></script>                  <script type="text/javascript" src="modules/DragNDrop/libs/jQueryFileUploader/js/jquery-iframe-transport.js"></script>                  <script type="text/javascript" src="modules/DragNDrop/libs/jQueryFileUploader/js/jquery-fileupload.js"></script>                                        <script type="text/javascript" src="modules/DragNDrop/libs/jQueryFileUploader/js/jquery-fileupload-process.js"></script>                        <script type="text/javascript" src="modules/DragNDrop/libs/jQueryFileUploader/js/jquery-fileupload-validate.js"></script>                       <script type="text/javascript" src="modules/DragNDrop/libs/jQueryFileUploader/js/main.js"></script></div>';

				$('.recordBasicInfo').before(JSFiles);

				        $.ajax({
        				        type:"POST",
        				        datatype:JSON,
        				        data:{"GetInFo":"FetchDetails"},
        				        url:"index.php?module=DragNDrop&view=Widget",
        				        success:function(data) { 
               	
                				        $('.recordBasicInfo').after(data);
               					 }
        				});	
	
			}
		}

	});

});


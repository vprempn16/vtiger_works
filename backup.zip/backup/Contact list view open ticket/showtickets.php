<?php

class Contacts_showtickets_Action extends Vtiger_Action_Controller{
        function checkPermission(Vtiger_Request $request) {
                return;
        }

	public function process(Vtiger_Request $request) {
		global $adb;
		$recordsIdArr = $_REQUEST['recordsId'];

		foreach($recordsIdArr as $recordId ) {
                	$getOpenTickets = $adb->pquery("select count(ticketid) from vtiger_troubletickets left join vtiger_crmentity on vtiger_troubletickets.ticketid = vtiger_crmentity.crmid where vtiger_troubletickets.status in ('Open') and vtiger_crmentity.deleted =0 and vtiger_troubletickets.contact_id =?", array($recordId));			 
			$openTickets[$recordId] = $adb->query_result($getOpenTickets , 0 , 'count(ticketid)');
		}
		echo json_encode($openTickets);
	}
}

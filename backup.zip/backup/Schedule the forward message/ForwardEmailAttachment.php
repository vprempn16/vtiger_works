<?php
include_once 'include/Webservices/Relation.php';
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';
include_once 'modules/Vtiger/models/Module.php';
require_once 'include/utils/utils.php';
//error_reporting(E_ALL);
	
		global $adb,$current_user;
		$current_user = Users::getActiveAdminUser();		

		$getPendingEmails = $adb->pquery("select *from vtiger_srba_mail_attachments where record_model !='' ");
		while($row = $adb->fetch_array($getPendingEmails)) {
			$pendingEmails[]= $row;
		}
		for($i = 0 ; $i < count($pendingEmails) ; $i ++ ) {
			$emailAttachments = unserialize(base64_decode($pendingEmails[$i]['attachments']));
			$recordModel = unserialize(base64_decode($pendingEmails[$i]['record_model']));
			$type = "Forward_Email";
			$recordModel->send($type,$pendingEmails[$i]['mail_id']);
			$adb->pquery("update vtiger_srba_mail_attachments set status = 'Complete' where mail_id = ?",array($pendingEmails[$i]['mail_id']));
		}
		
echo"done";

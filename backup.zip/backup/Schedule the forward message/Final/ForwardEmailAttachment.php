<?php	
class Emails_ForwardEmailAttachment_Action Extends Vtiger_Index_View {
	public function process(Vtiger_Request $request) {
		
		global $adb,$current_user;
		$mode = $_POST['getList'];	// Ajax call for List the Pending Mails 
			
		$getPendingEmails = $adb->pquery("select *from vtiger_srba_mail_attachments where status = 'Pending' and user_id = ?  limit 5",array($current_user->id));
		while($row = $adb->fetch_array($getPendingEmails)) {
			$pendingEmails[]= $row;
			$mailSubject[] = $row['file_name'];
		}

		if ( $mode == "MailQueueList" ) {
			echo json_encode($mailSubject);
			die;
		}

		for($i = 0 ; $i < count($pendingEmails) ; $i ++ ) {
			$recordModel = unserialize(base64_decode($pendingEmails[$i]['record_model']));
			$recordModel->send($pendingEmails[$i]['forward_list_id']);
			$adb->pquery("update vtiger_srba_mail_attachments set status = 'Complete' where forward_list_id = ?",array($pendingEmails[$i]['forward_list_id']));
		}

		echo"done";
	}
}	

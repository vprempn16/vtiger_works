<?php
class BaWhatsApp_MessageBox_View extends Vtiger_Index_View{
    public function process( Vtiger_Request $request ){
        $viewer = $this->getViewer ($request);
        $moduleName = $request->getModule();
        
        $targetNumberList = [];
//        $numberField = ['Office Phone' => 'phone' , 'Mobile Phone' => 'mobile' , 'Home Phone' => 'homephone', 'Secondary Phone' => 'otherphone' ];
        $recordId = $_GET['record_id'];
        $sourceModuleName = 'Contacts';
        $recordModel = Vtiger_Record_Model::getInstanceById($recordId, $sourceModuleName);
        //foreach($numberField as $label => $field){
            $number = $recordModel->get('mobile');
        //    $targetNumberList[$number] = $label . ' (' . $number . ')';
        //}

        $viewer->assign('TARGET_NUMBER' , $number);
        $html = $viewer->view('MessageBox.tpl', $moduleName , true);
        echo json_encode([ 'html' => $html , 'number' => $number ]); die;
    }
}

<?php
class BaWhatsApp_MessageBox_View extends Vtiger_Index_View{
    public function process( Vtiger_Request $request ){
        $viewer = $this->getViewer ($request);
        $moduleName = $request->getModule();

        $html = $viewer->view('MessageBox.tpl', $moduleName , true);
        echo $html; die;
    }
}

<?php

class BaWhatsApp_SendMessage_Action extends Vtiger_BasicAjax_Action {

    public function process(Vtiger_Request $request) {
        $laravelPath = 'https://demo.blackant.io/gio/gio-whatsapp/public/api/vtSendMessage';
        $recordId = $_POST['record_id'];
        $moduleName = 'Contacts';
        $recordModel = Vtiger_Record_Model::getInstanceById($recordId, $moduleName);
        
        $postData['destination'] = $recordModel->get('mobile');
        $postData['content'] = $_POST['content'];

        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => $laravelPath,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $postData,
          CURLOPT_HTTPHEADER => array(
            'Cookie: laravel_session=eyJpdiI6InJJQjhPRE9sak1CRjhvd0EyRHdmcXc9PSIsInZhbHVlIjoidHdoRjBjWkdlTHZhc0Z5Q1BVKzBWbTAvS1FTTzdETDk1anFqUEtqanFWcGpOekl3NTRaUmJWOHpwYk84T1VYc1puS1NGc1BNODR6V2g0ME9Xei9yZldQZk5HQ0JpT3UwekFlRkpuZVhTSEIrcGZraEVNbWxBYUZCVzk4SVk4YXoiLCJtYWMiOiI1YTNiNDMyODZmZDYyZGE3YmMxYmI3OGE0MjgxMDllOTMxYTYxYTk3YTZlZmMwMmE5ZTkyODNiYjcwZDNhZjg5IiwidGFnIjoiIn0%3D'
          ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        echo json_encode($response); 
        die;
    }    
}

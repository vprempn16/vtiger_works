<?php

class MailManager_AssignEmailRecord_Action extends Vtiger_BasicAjax_Action {

	public function process(Vtiger_Request $request){
	
		if( $_POST['operation'] == 'getRecords' ){
			$records = $this->fetchRecords();
			echo json_encode($records);
		} else if( $_POST['operation'] == 'relate' ){
			$result = $this->assignRecord();
			echo $result ;
		}
	}
	public function fetchRecords($data) {
		global $adb;
		$module = $_POST['moduleName'];
		$getKey = $_POST['recordName'];
		$listPart = $_POST['page'];
		if($_POST['page']){
			$limit = $_POST['page'] * 10 . ', 10'; 
		} else {
			$listPart = 0;
			$limit = '0 , 10';
		}
		if($getKey != '') {
			$key = "%".$getKey."%";
			$getRecordsData = $adb->pquery('SELECT label, crmid from vtiger_crmentity where label like ? and deleted = 0 and setype= ? limit '.$limit , array( $key , $module ) );
			$getCount = $adb->pquery('select count(crmid) from vtiger_crmentity where label like ? and deleted = 0 and setype= ? ', array( $key , $module ) );
                        $totalRecord = $adb->fetch_array( $getCount , 0 , 'count(crmid)' );
		} else {
			$getRecordsData = $adb->pquery('SELECT label, crmid from vtiger_crmentity where deleted = 0 and setype = ? limit '.$limit , array($module) );	
                        $getCount = $adb->pquery('select count(crmid) from vtiger_crmentity where deleted = 0 and setype= ? ', array( $module ) );
                        $totalRecord = $adb->fetch_array( $getCount , 0 , 'count(crmid)' );
		}
		while( $row = $adb->fetch_array($getRecordsData)) {
			$name[] = $row['label'];
			$id[] = $row['crmid'];
		}
		 $disableNxt = '';
		if ( $totalRecord['count(crmid)'] <  (($listPart+1) * 10 )){
			$disableNxt = 'disabled';
		}
		
		$records['name']= $name;
		$records['id']= $id;
		$records['pagePart'] = $_POST['page'];
		$records['disableNxt'] =  $disableNxt ;

		return $records;

	}
	
	public function assignRecord(){
		include_once 'include/Webservices/Query.php';
		include_once 'modules/MailManager/MailManager.php';
                $db = PearDatabase::getInstance();
                $currentUserModel = Users_Record_Model::getCurrentUserModel();
                if(!MailManager::checkModuleWriteAccessForCurrentUser('Emails')) {
                        return false;
                }
                $email = CRMEntity::getInstance('Emails');

                $to_string = rtrim($_POST['to'], ',');
                $cc_string = rtrim($_POST['cc'], ',');
                $bcc_string= rtrim($_POST['bcc'], ',');

                $parentIds = $_POST['selectedRecord'];

                $emailId = $_POST['emailid'];
                $subject = $_POST['subject'];
                $email = CRMEntity::getInstance('Emails');
                $email->column_fields['assigned_user_id'] = $currentUserModel->getId();
                $email->column_fields['date_start'] = date('Y-m-d');
                $email->column_fields['time_start'] = date('H:i');
                $email->column_fields['parent_id'] = $parentIds;
                $email->column_fields['subject'] =  (!empty($subject)) ? $subject : "No Subject";
                $email->column_fields['description'] = $_POST['body'];
                $email->column_fields['activitytype'] = 'Emails';
                $email->column_fields['from_email'] = $_POST['from'];
                $email->column_fields['saved_toid'] = $to_string;
                $email->column_fields['ccmail'] = $cc_string;
                $email->column_fields['bccmail'] = $bcc_string;
                $email->column_fields['email_flag'] = 'SAVED';

                $email->save('Emails');
                //save parent and email relation, to show up in Emails section of the parent
                $this->saveEmailParentRel($email->id, $parentIds);

		return true;
		 	
	}
        public function saveEmailParentRel($emailId, $parentIds) {
                $db = PearDatabase::getInstance();

                $myids = explode("|", $parentIds);  //2@71|
                if(!empty($emailId)) {
                        $db->pquery("delete from vtiger_seactivityrel where activityid=?",array($emailId)); //remove all previous relation
                }
                for ($i=0; $i<(count($myids)); $i++) {
                        $realid = explode("@",$myids[$i]);
                        if(!empty($realid[0]) && !empty($emailId)) {
                                // this is needed as we might save the mail in draft mode earlier
                                $result = $db->pquery("SELECT * FROM vtiger_seactivityrel WHERE crmid=? AND activityid=?",array($realid[0], $emailId));
                                if(!$db->num_rows($result)) {
                                        $db->pquery('INSERT INTO vtiger_seactivityrel(crmid, activityid) VALUES(?,?)',array($realid[0], $emailId));
                                }
                        }
                }
        }
}  

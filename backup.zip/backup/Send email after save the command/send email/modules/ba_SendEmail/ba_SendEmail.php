<?php

include_once('vtlib/Vtiger/Event.php');
class ba_SendEmail {

	public function process(){		
		Vtiger_Event::register('ModComments', 'vtiger.entity.aftersave', 'SendEmailHandler', 'modules/ba_SendEmail/SendEmailHandler.php');
	}

}

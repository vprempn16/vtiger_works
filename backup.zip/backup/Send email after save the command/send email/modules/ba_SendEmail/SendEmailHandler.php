<?php
class SendEmailHandler extends VTEventHandler {
    function handleEvent($eventName, $data) {
        if($eventName == 'vtiger.entity.beforesave') {
            // Entity is about to be saved, take required action
            echo "<script> alert('ssd'); </script>"; die('sss');
        }
        if($eventName == 'vtiger.entity.aftersave') {
            // Entity has been saved, take next action
            echo "<script> alert('ssd'); </script>"; die('sss');
        }
    }
}
?>

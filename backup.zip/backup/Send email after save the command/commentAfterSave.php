<?php
include_once('vtlib/Vtiger/Event.php');
Vtiger_Event::register('ModComments', 'vtiger.entity.aftersave', 'SendEmailHandler', 'modules/ba_SendEmail/SendEmailHandler.php');
echo "done";

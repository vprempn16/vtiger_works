<?php
include_once('vtlib/Vtiger/Module.php');
include_once 'includes/main/WebUI.php';
global $adb;
// Module Instance 
$moduleName='Events';
$moduleInstance = Vtiger_Module::getInstance($moduleName);
$blockInstance = Vtiger_Block::getInstance('LBL_EVENT_INFORMATION', $moduleInstance); 
if($blockInstance) {
	$fieldInstance = new Vtiger_Field();
	$fieldInstance->name = 'ba_all_day';
	$fieldInstance->table = 'vtiger_activity';
	$fieldInstance->column = 'ba_all_day';
	$fieldInstance->label = 'All day';
	$fieldInstance->uitype = '56';
	$fieldInstance->columntype = 'INT(5)';
	$fieldInstance->typeofdata = 'V~O';	
	$blockInstance->addField($fieldInstance);

	//add field with Quick create
	$adb->pquery('update vtiger_field set quickcreate = 2 where columnname ="ba_all_day"');

	echo"Done!";
} else {
	echo "Block Name is not Found";
}	

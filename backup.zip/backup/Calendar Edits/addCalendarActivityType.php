<?php
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';

global $adb;

$nextNum = $adb->pquery('select id from vtiger_calendar_default_activitytypes_seq');
$fieldId = $adb->query_result($nextNum, 0 , 'id');
$activityId = $fieldId + 1;

// Add field to Calendar activity type
$adb->pquery("insert into vtiger_calendar_default_activitytypes ( id , module , fieldname , defaultcolor ) values ($activityId , 'Contacts' , 'support_start_date' , '#b007b0' )");

$adb->pquery("update vtiger_calendar_default_activitytypes_seq set id = ?",array($activityId));

$nextNum = $adb->pquery('select id from vtiger_calendar_user_activitytypes_seq');
$fieldId = $adb->query_result($nextNum, 0 , 'id');
$fieldId ++;

$adb->pquery("insert into vtiger_calendar_user_activitytypes ( id , defaultid , userid , color , visible ) values ($fieldId , $activityId , 1 , '#b007b0', 0 )");

$adb->pquery("update vtiger_calendar_user_activitytypes_seq set id = ?",array($fieldId));

echo "Done!";

<?php
class Contacts_MergeDuplicateTicktes_action extends Vtiger_Action_Controller{
    function checkPermission(Vtiger_Request $request) {
        return;
    }

     public function process(Vtiger_Request $request) {
        global $adb;
        
        if( isset($_REQUEST['operation']) && $_REQUEST['operation'] == 'getParentRecords' ){
        
            $recordsId = $_REQUEST['totalRecords'];
            $recordsId = implode($recordsId , ",");

            $parentRecords = [];
            $getParentRecords = $adb->pquery('select ticketid, ticket_parent_id from vtiger_ticketcf where ticket_parent_id is not null and ticketid in ('.$recordsId.')');
            while( $row = $adb->fetch_array($getParentRecords)){
                $parentRecords[] = $row['ticket_parent_id'];
                $childRecords[] = $row['ticketid'];
            }
            $records['parent'] = array_unique($parentRecords);
            $records['child'] = $childRecords;
            echo json_encode($records);die;

        } else if( isset($_REQUEST['operation']) && $_REQUEST['operation'] == 'mergeRecords' ) {
            $selectedRecordsId = json_decode( $_POST['selectedRecords'] );
            $ticketParentId = max($selectedRecordsId); 
            $childRecords = array_diff( $selectedRecordsId , array($ticketParentId) );
            foreach( $childRecords as $recordId ){
                $adb->pquery('update vtiger_ticketcf set ticket_parent_id = ? where ticketid = ?' , array( $ticketParentId , $recordId ) );
            }
            echo true;die('Done');
        } else if( isset($_REQUEST['operation']) && $_REQUEST['operation'] == 'getParentDetail' ){

            $recordModel = [];
            $DocTickets = [];
            $getChildRecords = $adb->pquery('select ticketid from vtiger_ticketcf where ticket_parent_id = ? ', array($_REQUEST['record']));
            while( $row = $adb->fetch_array($getChildRecords)){
                $recordId[] = $row['ticketid'];
                
                // Check tickets contains Documents
                $checkRecordDocuemnt = $adb->pquery("select vtiger_senotesrel.notesid from vtiger_senotesrel left join vtiger_crmentity on vtiger_senotesrel.notesid= vtiger_crmentity.crmid where vtiger_crmentity.deleted = 0 and vtiger_senotesrel.crmid = ?" , array( $row['ticketid'] ) );

                $documentId = $adb->query_result($checkRecordDocuemnt , 0 , 'notesid');
                if($documentId){
                    $DocTickets[] = $row['ticketid'];
                }
            }
            $recordId = implode($recordId , "','");

            $html = '<table class="table table-bordered listViewEntriesTable" > <thead> <tr> <th> Title </th> <th>Status </th> <th> Assign user </th> </tr> </thead> <tbody> ';
            $recordData = '';


            $getChildRecordDetails = $adb->pquery(" select vtiger_troubletickets.title , ticketid , vtiger_troubletickets.status, first_name, last_name from vtiger_troubletickets left join vtiger_crmentity on vtiger_crmentity.crmid = vtiger_troubletickets.ticketid left join vtiger_users on vtiger_users.id = vtiger_crmentity.smownerid where ticketid in ('".$recordId."')" );

            while( $row = $adb->fetch_array($getChildRecordDetails)) {
                if($row['status'] == 'Closed') {
                    $bgColor = '#0eff066b';
                } else {
                    $bgColor = '#ff000078';
                }
                $title = (strlen(  $row["title"] ) > 15 ) ? substr(  $row["title"] , 0, 15 ) . '...' :  $row["title"];
                
                //Tickets Documents checking
                $setDocIcon = '';
                if(in_array($row['ticketid'] , $DocTickets)){
                    $setDocIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paperclip" viewBox="0 0 16 16">
                      <path d="M4.5 3a2.5 2.5 0 0 1 5 0v9a1.5 1.5 0 0 1-3 0V5a.5.5 0 0 1 1 0v7a.5.5 0 0 0 1 0V3a1.5 1.5 0 1 0-3 0v9a2.5 2.5 0 0 0 5 0V5a.5.5 0 0 1 1 0v7a3.5 3.5 0 1 1-7 0V3z"/>
                      </svg>';
                }
                
                $recordData .= '<tr class="ba_merged_records"> <td> <a href="index.php?module=HelpDesk&view=Detail&record='.$row['ticketid'].'"> '.$title.' </a> </td> <td style="background-color: '.$bgColor.'">'.$row['status'].' </td> <td> <span> <a href="index.php?module=Contacts&view=Detail&record='.$row['contactid'].'"> '. $row['first_name']. ' '.$row['last_name'] .'</a></span> <span> '.$setDocIcon.' </span> </td> </tr>';
            }
            if($recordData){
                $html = $html. $recordData . '</tbody> </table>';
            } else {
                $html = $html. '<tr> <td colspan=2> No records merged. </td></tr> </tbody> </table>';
            }
            echo $html; die;

        }
     }
}

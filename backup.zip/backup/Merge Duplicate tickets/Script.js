$(function(){

    var moduleName = app.getModuleName();
    var moduleView = app.getViewName();
    var relatedModule = $('.relatedModuleName').val();

    // Apply merge components checkbox and merge button
    if(moduleName == 'Contacts' && moduleView == 'Detail' && relatedModule == 'HelpDesk' ){
        if( $('#ba-merge-tickets').length == 0 ) {
            applyMergeComponents();
        }
    }

    if( moduleName == 'HelpDesk' && moduleView == 'Detail'){
       var record = $('#recordId').val();
       $.ajax({
            type: 'POST',
            data: {
                'record': record,
                'operation': 'getParentDetail',
            },
            dataType: 'HTML',
            url: 'index.php?module=Contacts&action=MergeDuplicateTicktes',
            success: function(response){
                $('#relatedActivities').append('<div class="summaryWidgetContainer">  <div class="widget_header row-fluid"><input type="hidden" name="relatedModule" value=""><span class="span9 margin0px"><h4 class="textOverflowEllipsis"> Zugeordnete Tickets </h4></span><span class="span3"><span class="pull-right"></span></span></div> <div class="widget_contents">  <input type="hidden" name="page" value="1"><input type="hidden" name="pageLimit" value="5"></div> '+response+'</div>');
                if($('.ba_merged_records').length != 0 ){
                    $('.recordDetails .fieldValue')[0].prepend('∑');
                }
            }
        });
    }
});

$( document ).ajaxComplete(function( event,request, settings ) {
    var moduleName = app.getModuleName();
    var moduleView = app.getViewName();
    var relatedModule = $('.relatedModuleName').val();

    // Apply merge components checkbox and merge button
    if(moduleName == 'Contacts' && moduleView == 'Detail' && relatedModule == 'HelpDesk' ){
        if( $('#ba-merge-tickets').length == 0 ) {
            applyMergeComponents();
        }
    }
});

// Apply merge components checkbox and merge button
function applyMergeComponents(){

    var moduleName = app.getModuleName();
    var moduleView = app.getViewName();
    var relatedModule = $('.relatedModuleName').val();

    if(moduleName == 'Contacts' && moduleView == 'Detail' && relatedModule == 'HelpDesk' ){
        $(document).find('.relatedHeader .btn-group .addButton').after('<button type="button" id="ba-merge-tickets" class="btn" style="margin-left: 5px;" > Tickets zusammenlegen </button> <input type="hidden" id="ba-selected-checkbox">')
        $('.listViewEntriesTable').find('thead tr').prepend('<td> <input type="checkbox" class="ba-all-related-record-checkbox" > </td> <td></td>');

        var totalRecords = [];
        $('.listViewEntriesTable').find('tbody tr').each(function(){
            var recordId = $(this).data('id');
            $(this).prepend('<td> <input type="checkbox" class="ba-related-record-checkbox" data-id="'+recordId+'" > </td><td class="ba_merge_parent"></td>');
            totalRecords.push(recordId);
        });

        $.ajax({
            type: 'POST',
            data: {
                'totalRecords': totalRecords,
                'operation': 'getParentRecords',
            },
            dataType: 'JSON',
            url: 'index.php?module=Contacts&action=MergeDuplicateTicktes',
            success: function(response){
                $('.listViewEntriesTable').find('tbody tr').each(function(){
                    var recordId = $(this).data('id');
                    if( response.includes(recordId.toString()) ){
                        $(this).find('.ba_merge_parent').html(' ∑');
                    }
                 });
            }
        });
    }
}

//Add record when the checkbox selected
$(document).on ('click' , '.ba-related-record-checkbox' , function(){
    var selectedRecords = $('#ba-selected-checkbox').val();
    if(selectedRecords){
        var selectedRecordsArr = JSON.parse(selectedRecords);
    } else{
        var selectedRecordsArr= [];
    }
    if( $(this).is(':checked')) {
        selectedRecordsArr.push($(this).data('id'));
    } else {
        selectedRecordsArr.pop($(this).data('id'));
    }
    $('#ba-selected-checkbox').val(JSON.stringify(selectedRecordsArr));
});

// Select all(header) check box event
$(document).on('click', '.ba-all-related-record-checkbox', function(){
    if( $(this).is(":checked")) {
        $('.listViewEntriesTable .ba-related-record-checkbox').each(function(){
            $(this).prop("checked", true);
        });
    } else {
        $('.listViewEntriesTable .ba-related-record-checkbox').each(function(){
            $(this).prop("checked", false);
        });
    }
});

// Merge duplicate tickets
$(document).on( 'click' , '#ba-merge-tickets', function(){
    var selectedRecords = $('#ba-selected-checkbox').val();
    if( !selectedRecords && JSON.parse(selectedRecords.length) == 0 ){
        alert('Please select some records.');
        return false;
    } else {
        $.ajax({
            type: 'POST',
            data: {
                    'selectedRecords': selectedRecords,
                    'operation': 'mergeRecords',
                },
            url: 'index.php?module=Contacts&action=MergeDuplicateTicktes',
            success: function(response){
                 window.location.reload();
            }
        });
    }
});


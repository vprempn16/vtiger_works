<?php 

include_once('vtlib/Vtiger/Module.php');

$custom = Vtiger_Module::getInstance('CTWhatsApp');
$block = Vtiger_Block::getInstance('Whatsapp Msg Detail', $custom);

// add field
$field = new Vtiger_Field();
$field->name = 'contacts';
$field->label = 'Contact Name'; 
$field->table = 'vtiger_ctwhatsapp';
$field->column = 'contacts';
$field->columntype = 'varchar(255)';
$field->uitype = 10;
$field->typeofdata = 'v~o';
$block->addfield($field);
$field->setrelatedmodules(array('Contacts'));

echo "Field created successfully";
?>


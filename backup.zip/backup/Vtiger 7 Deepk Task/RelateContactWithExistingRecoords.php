<?php
ini_set('display_errors','on'); error_reporting(E_ALL);
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';
include_once 'Vtiger_Action_Controller';
global $adb;

$moduleName = 'CTWhatsApp';
$getContactIds = $adb->pquery('select contactid , ctwhatsappid , whatsapp_withoccode from vtiger_ctwhatsapp left join vtiger_contactdetails on vtiger_contactdetails.mobile = vtiger_ctwhatsapp.whatsapp_withoccode where whatsapp_withoccode != ""');
while( $row = $adb->fetch_array($getContactIds) ){
    $adb->pquery('update vtiger_ctwhatsapp set contacts = ? where leadid = ?' , array( $row['contactid'], $row['ctwhatsappid'] ));
}
echo "Related records success fully";

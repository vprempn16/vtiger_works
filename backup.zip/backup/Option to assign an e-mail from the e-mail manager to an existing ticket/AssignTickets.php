<?php 
        include_once 'include/Webservices/Create.php';
        include_once 'vtlib/Vtiger/Mailer.php';
        include_once 'vtlib/Vtiger/Version.php';
	include_once 'vtlib/Vtiger/Module.php';
$vtiger_utils_log = true; 
class MailManager_AssignTickets_View extends MailManager_Abstract_View {
	public function process(Vtiger_Request $request){
		global $adb;
		$helpdesk_ids = $request->get('id');
		$email_id = $request->get('msgid');
          	$folderName = $request->get('folderName');
		$connector = $this->getConnector($folderName);
         	$mail = $connector->openMail($email_id);
	  	$mail->attachments(); // Initialize attachments
	  	foreach($helpdesk_ids as $helpdesk_id) {
			MailManager_Relate_Action::associate($mail, $helpdesk_id);
			$getEmailId = $adb->pquery('select emailid from vtiger_mailmanager_mailrel where mailuid = ?', array($mail->uniqueid()));
      	 		$email_id_for_relation = $adb->query_result($getEmailId, 0, 'emailid');
			if($email_id_for_relation) {
				$adb->pquery('insert into vtiger_crmentityrel values (?, ?, ?, ?)', array($helpdesk_id, 'HelpDesk', $email_id_for_relation, 'Emails'));
				$this->relateComments($helpdesk_id);
			}
		}
	}


	public function relateComments($ticket_id){


                        $recordModel = Vtiger_Record_Model::getCleanInstance('ModComments');
                        $modelData = $recordModel->getData();
                        $recordModel->set('commentcontent', 'Es wurde eine E-Mail mit dem Betreff:');
			$recordModel->set('related_to',$ticket_id);
			$recordModel->save();
	}

}
?>

<?php
class MailManager_SearchTickets_Action  extends MailManager_Abstract_View{

                public function process(Vtiger_Request $request){
                        global $adb,$current_user;
		
		// Get related contacts of a keyword
			$module = $request->get('module_name');
			if($module == 'contact'){
			        $getKey = $request->get('keyword');
				$key = "%".$getKey."%";
				$getContacts =$adb->pquery("select firstname,lastname,contactid from vtiger_contactdetails inner join vtiger_crmentity on vtiger_contactdetails.contactid = vtiger_crmentity.crmid where vtiger_crmentity.deleted =0 and (concat(vtiger_contactdetails.firstname , vtiger_contactdetails.lastname) like ?)",array($key)); 
                	        while($row = $adb->fetch_array($getContacts)){
                	                $name[]= $row['firstname'].' '.$row['lastname'];
					$id[] = $row['contactid'];
                	        }
				$contact['name']=$name;
				$contact['id']=$id;
                        echo json_encode($contact);
			}
			//  Get realted tickets of selected contact 
			else if($module == 'ticket'){
                                $ticketId = $request->get('id');
				$tickets=$adb->pquery("select ticketid,title from vtiger_troubletickets left join vtiger_crmentity on vtiger_troubletickets.ticketid = vtiger_crmentity.crmid where vtiger_crmentity.deleted =0 and vtiger_troubletickets.contact_id = ? ",array($ticketId));
				while($row = $adb->fetch_array($tickets)){
					$title[]= $row['title'];
					$id[] = $row['ticketid'];
				}

				$ticket['name'] = $title;
				$ticket['id'] = $id;
				echo json_encode($ticket);
				
				}
			}	
		}
	
?>

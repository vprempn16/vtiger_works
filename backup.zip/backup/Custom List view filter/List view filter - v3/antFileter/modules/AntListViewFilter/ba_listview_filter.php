<?php 

class AntListViewQuery {

    public function baQueryGenerator($moduleName) {
        if($moduleName == 'Events') {
            $moduleName = 'Calendar';
        }
        include_once "modules/$moduleName/$moduleName.php";
        global $adb,$current_user;
		$filterQuery = $adb->query("select * from vtiger_ant_listview_filter where module_name= '$moduleName'");

        $relatedFields = unserialize($filterQuery->fields['related_field']);
        $listQuery = '';
        $moduleObj = new $moduleName();
        $module_tabname = $moduleObj->tab_name;
        $module_tab_index = $moduleObj->tab_name_index;

        $flag = 0;
            $role_id = $current_user->roleid;
            $sql = $adb->query("select * from vtiger_role where roleid ='$role_id'");
            $role_name = $sql->fields['rolename'];

        while($row = $adb->fetch_array($filterQuery)){
            $queryResult = $row['conditions'];
            $decodedFilterQuery = base64_decode($queryResult);
//            $Roles = ($row['roles']);
            $Roles = unserialize( base64_decode ($row['roles']) );

            $is_admin = $current_user->is_admin;
            if($decodedFilterQuery && $is_admin != 'on'){
//               if( strpos($Roles , $role_name)){
                if(in_array($role_name, $Roles)) {
                    if( $flag != 0 ){
                        $listQuery .= " OR "; 
                    } elseif ($flag == 0) {
                        $listQuery .= $joinQuery;
                    }
                    $flag = 1;
                    $listQuery .= $decodedFilterQuery;
                }
            }
        }
//        echo "<pre>" ; print_r($listQuery);die;
        return $listQuery;        
    }
    /**
    *
    *Link custom query to listview query
    */
    public function baLinkListQuery($moduleName,$ba_Query,$listQuery){
            
          include_once "modules/$moduleName/$moduleName.php";
           $moduleObj = new $moduleName();
            $module_tabname = $moduleObj->tab_name;
            $module_tab_index = $moduleObj->tab_name_index;

            $baJoinQuery = '';

            foreach($module_tabname as $key=>$table){
                if(strpos($listQuery , $table) !== false){
                    $baJoinQuery .= "";
                }else{

                    $column = $module_tab_index[$table];
                    $baJoinQuery .= " LEFT JOIN $table on $table.$column = vtiger_crmentity.crmid";
                }
            }
            $baQueryJoinArr = explode( 'WHERE' , $listQuery);
            $responseArr['baJoinQuery'] = $baJoinQuery;
            $responseArr['baQueryJoinArr'] = $baQueryJoinArr;
           return $responseArr;

    }
    /**
    * 
    *Redirect to listview if record id isn't 
    */
   public function baDetailQueryGenerator($moduleName,$ba_query){

	   global $adb;
	   include_once "modules/$moduleName/$moduleName.php";
           $moduleObj = new $moduleName();
           $module_tabname = $moduleObj->tab_name;
	   $module_tab_index = $moduleObj->tab_name_index;
	   $baJoinDetailQuery = '';
	   foreach($module_tabname as $key=>$table){
	   	if($key != 'vtiger_crmentity'){
			$column = $module_tab_index[$table];
                        $baJoinDetailQuery .= " LEFT JOIN $table on $table.$column = vtiger_crmentity.crmid";
		}
	   }
	 
	   $ba_QueryJoin = $adb->query("SELECT * FROM vtiger_crmentity".$baJoinDetailQuery.' WHERE '.$ba_query);
	   $row_count = $adb->num_rows($ba_QueryJoin);
	   if($row_count != 0){
	   while($row = $adb->fetch_array($ba_QueryJoin)){

		   $module_record_ids[] = $row['crmid'];
	   } 
	   
	   return $module_record_ids;
	   }
   }
}
?>


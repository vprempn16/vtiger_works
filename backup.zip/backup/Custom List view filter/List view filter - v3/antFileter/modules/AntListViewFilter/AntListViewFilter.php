<?php
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';

class AntListViewFilter {
    public function vtlib_handler($moduleName, $eventType) {
        if ($eventType == 'module.postinstall') {
                $this->_registerLinks($moduleName);
        } else if ($eventType == 'module.enabled') {
                $this->_registerLinks($moduleName);
        } else if ($eventType == 'module.disabled') {
                $this->_deregisterLinks($moduleName);
        }
}

protected function _registerLinks($moduleName) {

        global $adb;
        $thisModuleInstance = Vtiger_Module::getInstance($moduleName);
      
        //create a custom tab in settings page
        if ($thisModuleInstance) {
            //create table for list view filter
            $sql =  "CREATE TABLE `vtiger_ant_listview_filter` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `module_name` varchar(255) NOT NULL,  `roles` varchar(255) DEFAULT NULL,  `conditions` longtext,  `fields` longtext,  `related_field` longtext,  PRIMARY KEY (`id`) ) ";

         $adb->pquery($sql);    
        //create field in settings page
        $nextNum = $adb->pquery('select id from vtiger_settings_field_seq');
        $fieldId = $adb->query_result($nextNum, 0 , 'id');
        $fieldId ++;
        
        // Setting page script 
        $adb->pquery("insert into vtiger_settings_field (fieldid,blockid,name,linkto)values($fieldId ,4 ,'AntListViewFilter' ,'index.php?parent=Settings&module=Vtiger&view=AntListViewFilterList')");
        $adb->pquery("update vtiger_settings_field_seq set id = ?",array($fieldId));
        
        }
}

protected function _deregisterLinks($moduleName) {

        global $adb;
        $thisModuleInstance = Vtiger_Module::getInstance($moduleName);
        if ($thisModuleInstance) {
         //delete settings field if  module is disabled
         $adb->pquery("delete from vtiger_settings_field where name='AntListViewFilter'");   

        }
}
}

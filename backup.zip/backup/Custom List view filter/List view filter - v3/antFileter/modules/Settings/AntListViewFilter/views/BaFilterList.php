<?php 

class Settings_AntListViewFilter_BaFilterList_View extends Settings_Vtiger_Index_View {

    public function process(Vtiger_Request $request){
        
        global $adb;
        
        $mode = $request->get('mode');
         
        if(isset($mode) && $mode == 'delete'){


            $record_id = $request->get('record_id');
            
            $adb->query("delete from vtiger_ant_listview_filter where id='$record_id'");
            echo true;
            die;
         }

        $viewer = $this->getViewer($request);
        $module = $request->getModule(false);
        $filter_list_array = $adb->query("select * from vtiger_ant_listview_filter");
        $filter_list_row = $adb->num_rows($filter_list_array);
        
        if($filter_list_row >0){
           
           foreach($filter_list_array as $key=>$value){
               
               $filter_list_Data['id'][] = $value['id'];
               $filter_list_Data['roles'][] = unserialize( base64_decode ($value['roles']));
               $filter_list_Data['module_names'][] = $value['module_name'];
                
           }
        } 
           $viewer->assign("COUNT",$filter_list_row);
           $viewer->assign("MODULE_NAMES",$filter_list_Data['module_names']);
           $viewer->assign('RECORD_ID',$filter_list_Data['id']);
           $viewer->assign("ROLES",$filter_list_Data['roles']); 
           $viewer->view('AntListViewFilterList.tpl',$module);

    }


        public function getHeaderScripts(Vtiger_Request $request) {

        $headerScriptInstances = parent::getHeaderScripts($request);
        $moduleName = $request->getModule();
    
        $jsFileNames = array(

          "modules.Settings.$moduleName.resources.AntListViewFilter",
          '~libraries/jquery/ckeditor/ckeditor.js',
          "modules.Vtiger.resources.CkEditor",
                '~/libraries/jquery/bootstrapswitch/js/bootstrap-switch.min.js',
          '~libraries/jquery/jquery.datepick.package-4.1.0/jquery.datepick.js',
        );
        
        $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
        $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
        return $headerScriptInstances;
      }
}

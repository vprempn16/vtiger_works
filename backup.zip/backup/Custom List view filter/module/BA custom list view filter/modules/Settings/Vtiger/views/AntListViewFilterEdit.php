<?php

class Settings_Vtiger_AntListViewFilterEdit_View extends Settings_Vtiger_Index_View {

    public function process(Vtiger_Request $request){

            global $adb;
            
            $viewer = $this->getViewer($request);
          
            $record_id = $request->get('id');
            $module = $request->getModule(false);
            
            $selected_roles = $request->get('roles');

            $selected_roles_list = $adb->query("select * from vtiger_ant_listview_filter where id='$record_id'");
            $selectedModuleName = $selected_roles_list->fields['module_name'];
            $decodedRoles = unserialize($selected_roles_list->fields['roles']);
            $decodedFields = unserialize($selected_roles_list->fields['fields']);
            $selectedModule = Vtiger_Module_Model::getInstance($selectedModuleName);
            $qualifiedModuleName = $request->getModule(false);
            //get picklist values
           
                foreach($decodedFields['sectionContainer'] as $decode_key=>$decode_value){
                    
                    if(in_array('select', $decode_value['type'])){

                        $index = array_search('select',$decode_value['type']);
                        $fieldname = $decode_value['columnList'][$index];
                        $tableName = "vtiger_$fieldname";
                        $sql = $adb->query("select * from $tableName ");
                        while($row = $adb->fetch_array($sql)){
            
                             $picklistVal[] = $row["$fieldname"];
                        }
                    $decodedFields['sectionContainer'][$decode_key]['picklistvalues'] = $picklistVal;
                    }
            }
            
            $moduleNames =  $adb->query("SELECT * FROM `vtiger_tab` WHERE tabsequence !='-1'");
            $num_row = $adb->num_rows($moduleNames);
              if($num_row > 0){

              foreach($moduleNames as $key => $value){
                if($value['name'] != 'Dashboard' && $value['name'] != 'Home'){
                $modules[$key] = $value['name'];
                }
              }
            }

            $roles = $adb->query("SELECT * FROM `vtiger_role`");
            $count = $adb->num_rows($roles);

            if($count > 0){
              foreach($roles as $role_key => $role_value){
                
                $roles_list['id'][] = $role_value['roleid'];
                $roles_list['rolename'][] = $role_value['rolename'];

              }
            }
         
            $workflowModel = Settings_Workflows_Record_Model::getCleanInstance($selectedModuleName);
            
            $recordStrucure = Vtiger_RecordStructure_Model::getInstanceFromRecordModel($workflowModel,
             Vtiger_RecordStructure_Model::RECORD_STRUCTURE_MODE_DETAIL);
              $structuredValues = $recordStrucure->getStructure();

              foreach($structuredValues as $key=>$value){

                  foreach($value as $lbkey=>$lbvalue){
                    
                      $fieldNames['key'][] = $lbkey;
                      $fieldNames['label'][] = $lbvalue->label;
                      $fieldNames['table'][] = $lbvalue->table;
                      $fieldNames['uitype'][] = $lbvalue->uitype;
                    }
             }
            // echo "<pre>";print_r($fieldNames);die;
             $ADVANCED_FILTER_OPTIONS_BY_TYPE = Settings_Workflows_Field_Model::getAdvancedFilterOpsByFieldType();
             $ADVANCED_FILTER_OPTIONS_BY_TYPE_OPTIONS = Settings_Workflows_Field_Model::getAdvancedFilterOptions();
             $qualifiedModuleName = $request->getModule(false);
             $sections = ["AND","OR"];
             
             $viewer->assign("RECORD_ID" , $record_id);
             $viewer->assign('RECORD_STRUCTURE', $fieldNames);
             $viewer->assign('ADVANCED_FILTER_OPTIONS', $ADVANCED_FILTER_OPTIONS_BY_TYPE_OPTIONS);
             $viewer->assign('ADVANCED_FILTER_OPTIONS_BY_TYPE',$ADVANCED_FILTER_OPTIONS_BY_TYPE );
               
             $viewer->assign('MODULE',$selectedModuleName);
             $viewer->assign('SELECTED_MODULE_NAME', $selectedModuleName);
             $viewer->assign('QUALIFIED_MODULE',$qualifiedModuleName);
             $viewer->assign('SECTIONS',$sections);
             
            $viewer->assign("roles_list",$roles_list);
            $viewer->assign("modules",$modules);
            $viewer->assign("MODULE_NAME","Vtiger");

            $viewer->assign('SECTIONS',$sections);
           
            $viewer->assign("fields",$decodedFields['sectionContainer']);
            $viewer->assign('selected_roles',$decodedRoles);
            $viewer->assign("MODULE_NAME","Vtiger");
            $viewer->view('AntListViewFilter.tpl',$module);
            
    }
    
    public function getHeaderScripts(Vtiger_Request $request) {

      $headerScriptInstances = parent::getHeaderScripts($request);
      $moduleName = $request->getModule();
  
      $jsFileNames = array(
        'modules.Settings.Vtiger.resources.Edit',
        "modules.Settings.Workflows.resources.Edit",
        "modules.Vtiger.resources.AdvanceFilter",
        "modules.Settings.$moduleName.resources.AntListViewFilter",
        '~libraries/jquery/ckeditor/ckeditor.js',
        "modules.Vtiger.resources.CkEditor",
              '~/libraries/jquery/bootstrapswitch/js/bootstrap-switch.min.js',
        '~libraries/jquery/jquery.datepick.package-4.1.0/jquery.datepick.js',
      );
      
      $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
      $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
      return $headerScriptInstances;
    }
}
?>

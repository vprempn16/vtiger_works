<?php 

class AntListViewQuery {

    public function baQueryGenerator($moduleName){

        include_once "modules/$moduleName/$moduleName.php";
        global $adb,$current_user;
		$filterQuery = $adb->query("select * from vtiger_ant_listview_filter where module_name= '$moduleName'");
        
        $Roles = unserialize($filterQuery->fields['roles']);
        $relatedFields = unserialize($filterQuery->fields['related_field']);
        $listQuery = '';
        $moduleObj = new $moduleName();
        $module_tabname = $moduleObj->tab_name;
        $module_tab_index = $moduleObj->tab_name_index;

/*
        if($moduleName == 'Contacts'){
          $joinQuery = "left join vtiger_contactaddress on  contactaddressid = vtiger_contactdetails.contactid left join vtiger_contactsubdetails on contactsubscriptionid = vtiger_contactdetails.contactid WHERE ";
        } else {
             $joinQuery =" AND ";
        }
  */

        $flag = 0;
        while($row = $adb->fetch_array($filterQuery)){
            $queryResult = $row['conditions'];
            $decodedFilterQuery = base64_decode($queryResult);
            $role_id = $current_user->roleid;
            $sql = $adb->query("select * from vtiger_role where roleid ='$role_id'");
            $role_name = $sql->fields['rolename'];


            $is_admin = $current_user->is_admin;
            if($decodedFilterQuery && $is_admin != 'on'){
               if( in_array($role_name,$Roles)){
                    if( $flag != 0 ){
                        $listQuery .= " OR "; 
                    } elseif ($flag == 0) {
                        $listQuery .= $joinQuery;
                    }
                    $flag = 1;
                    $listQuery .= $decodedFilterQuery;
                }
            }
        }
//        echo "<pre>"; print_R($listQuery); die;
        return $listQuery;        
    }
}
?>

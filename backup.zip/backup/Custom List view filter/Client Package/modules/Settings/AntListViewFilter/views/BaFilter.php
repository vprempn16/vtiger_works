<?php

class Settings_AntListViewFilter_BaFilter_View extends Settings_Vtiger_Index_View {

    public function process(Vtiger_Request $request){

            global $adb;
            
            $viewer = $this->getViewer($request);
            $selectedModuleName = $request->get('selected_module');
            
            //check if module name is exist or not 
            $mode = $request->get('mode');
            $module = $request->getModule(false);
          
            if( isset($mode) && $mode == 'generate_condition'){

                $record_id = $request->get('record_id');
                
                $resultQuery = $this->generateCondition($request);
                $moduleName = $resultQuery['moduleName'];
                $related_fields = $resultQuery['related_fields'];
                $query_encode = base64_encode($resultQuery['query']);
                $roles = $resultQuery['roles'];
               // $roles_encode = serialize($roles);
                $roles_encode = base64_encode( serialize($roles) );
                $fieldsEncode = serialize($resultQuery['fields']);
                $related_fieldsEncode = serialize($related_fields);
                $sql = $adb->query("select * from vtiger_ant_listview_filter where id='$record_id'");
                $rows = $adb->num_rows($sql);
                if($rows == 0){
                    
                    $adb->query("insert into vtiger_ant_listview_filter(roles,module_name,conditions,fields,related_field) values('$roles_encode','$moduleName','$query_encode','$fieldsEncode','$related_fieldsEncode')");
                    $getRecordId = $adb->pquery('select id from vtiger_ant_listview_filter order by id desc  limit 1');
                    $result = $adb->query_result($getRecordId , 0, 'id');
                    echo $result;die;
                }else{
                    $result =  $adb->query("update vtiger_ant_listview_filter set roles = '$roles_encode',conditions='$query_encode',fields='$fieldsEncode',related_field='$related_fieldsEncode' where id='$record_id'");
                }
               
              }elseif($mode == 'getModuleFields'){

                $moduleName = $request->get('module_name');
               
                $moduleFields = $this->getModuleFields($moduleName);

               echo json_encode($moduleFields);

              }elseif($mode == 'getuitype'){

                  $uitype = $request->get('uitype');
                  $uivalues = $this->getuiType($request);
                  echo json_encode($uivalues);
              }
              else{
                
                $moduleNames =  $adb->query("SELECT * FROM `vtiger_tab` WHERE isentitytype = '1' AND customized !='1'");
                $remove_modules = ['Dashboard','Home','Emails','Faq','Webmails','ModComments','SMSNotifier', 'Events'];
                $num_row = $adb->num_rows($moduleNames);
                  if($num_row > 0){
                    
                  foreach($moduleNames as $key => $value){
                    if(!in_array($value['name'],$remove_modules)){
                    //if($value['name'] != 'Dashboard' && $value['name'] != 'Home'){
                    $modules[$key] = $value['name'];
                    }
                  }
                }
                
                $roles = $adb->query("SELECT * FROM `vtiger_role`");
                $count = $adb->num_rows($roles);
   
                if($count > 0){
                  foreach($roles as $role_key => $role_value){
                    
                    $roles_list['id'][] = $role_value['roleid'];
                    $roles_list['rolename'][] = $role_value['rolename'];
   
                  }
                }
             
               if($selectedModuleName){
                $workflowModel = Settings_Workflows_Record_Model::getCleanInstance($selectedModuleName);
                
                $recordStrucure = Vtiger_RecordStructure_Model::getInstanceFromRecordModel($workflowModel,
                 Vtiger_RecordStructure_Model::RECORD_STRUCTURE_MODE_DETAIL);
                  $structuredValues = $recordStrucure->getStructure();
  
                  foreach($structuredValues as $key=>$value){
  
                      foreach($value as $lbkey=>$lbvalue){
                        
                          $fieldNames['key'][] = $lbkey;
                          $fieldNames['label'][] = $lbvalue->label;
                          $fieldNames['table'][] = $lbvalue->table;
                          $fieldNames['uitype'][] = $lbvalue->uitype;
                        }
                 }
               } 
                 $ADVANCED_FILTER_OPTIONS_BY_TYPE = Settings_Workflows_Field_Model::getAdvancedFilterOpsByFieldType();
                 $ADVANCED_FILTER_OPTIONS_BY_TYPE_OPTIONS = Settings_Workflows_Field_Model::getAdvancedFilterOptions();
	             $qualifiedModuleName = $request->getModule(false);
                 $ADVANCED_FILTER_OPTIONS_BY_TYPE_Arr =  $this->removeOptions($ADVANCED_FILTER_OPTIONS_BY_TYPE['string'],'');
                    
                 $field_options_Arr['string'] = array_values($ADVANCED_FILTER_OPTIONS_BY_TYPE_Arr);
                 $sections = ["AND","OR"];
                 $viewer->assign("RECORD_ID",$record_id); 
                 $viewer->assign('RECORD_STRUCTURE', $fieldNames);
                 $viewer->assign('ADVANCED_FILTER_OPTIONS', $ADVANCED_FILTER_OPTIONS_BY_TYPE_OPTIONS);
                 $viewer->assign('ADVANCED_FILTER_OPTIONS_BY_TYPE',$field_options_Arr );
                   
                 $viewer->assign('MODULE',$selectedModuleName);
                 $viewer->assign('SELECTED_MODULE_NAME', $selectedModuleName);
                 $viewer->assign('QUALIFIED_MODULE',$qualifiedModuleName);
                 $viewer->assign('SECTIONS',$sections);
                 
                $viewer->assign("roles_list",$roles_list);
                $viewer->assign("modules",$modules);
                $viewer->assign("MODULE_NAME","Vtiger");
                $viewer->view('AntListViewFilter.tpl',$module);


            }
    }
    /**
     * 
     * Return module Fields
     */
    public function getModuleFields($selectedModuleName){
       
      
      $selectedModule = Vtiger_Module_Model::getInstance($selectedModuleName);

      $workflowModel = Settings_Workflows_Record_Model::getCleanInstance($selectedModuleName);
        
        $recordStrucure = Vtiger_RecordStructure_Model::getInstanceFromRecordModel($workflowModel,
        Vtiger_RecordStructure_Model::RECORD_STRUCTURE_MODE_DETAIL);
        $structuredValues = $recordStrucure->getStructure();
        $ADVANCED_FILTER_OPTIONS_BY_TYPE = Settings_Workflows_Field_Model::getAdvancedFilterOpsByFieldType();
        $ADVANCED_FILTER_OPTIONS_BY_TYPE_OPTIONS = Settings_Workflows_Field_Model::getAdvancedFilterOptions();

    foreach($structuredValues as $key=>$value){
            foreach($value as $lbkey=>$lbvalue){
              
                $fieldNames['key'][] = $lbkey;
                $fieldNames['label'][] = $lbvalue->label;
                $fieldNames['table'][] = $lbvalue->table;
                $fieldNames['uitype'][] = $lbvalue->uitype;
              }
       }

       $fieldsArr['fieldname'] = $fieldNames;
       $fieldsArr['filter_options'] = array_keys($ADVANCED_FILTER_OPTIONS_BY_TYPE_OPTIONS);
       $fieldsArr['filter_options_type'] =  $ADVANCED_FILTER_OPTIONS_BY_TYPE ;
       return $fieldsArr;
    }
    /**
     * 
     * Return uitype laues
     */
    public function getuiType($request){

        global $adb;
       
        $ADVANCED_FILTER_OPTIONS_BY_TYPE = Settings_Workflows_Field_Model::getAdvancedFilterOpsByFieldType();
        $ADVANCED_FILTER_OPTIONS_BY_TYPE_OPTIONS = Settings_Workflows_Field_Model::getAdvancedFilterOptions();
       
        $uitype = $request->get("uitype");
        $fieldname = $request->get('columnName');
        $sql = $adb->query("SELECT * FROM `vtiger_ws_fieldtype` WHERE uitype = '$uitype'");
        $value = $sql->fields['fieldtype'];
        
        $ba_datefield = ['createdtime','modifiedtime','support_start_date','date_start','starttime','endtime','sales_start_date','sales_end_date','start_date','expiry_date','due_date'];
      
        if($value == 'picklist'){
            
            $tableName = "vtiger_$fieldname";
            $sql = $adb->query("select * from $tableName ");
            while($row = $adb->fetch_array($sql)){

                 $picklistVal[] = $row["$fieldname"];
            }
          
            $fieldtype = 'select';
            $option_type = 'text';
            $fieldValuesArr['picklistvalues'] = $picklistVal;
        }

        if(!$value ){
          $option_type = 'text';
          $fieldtype = 'text';
        }else{

          $option_type = $value;
          $fieldtype = 'text';
        }

        if(in_array($fieldname,$ba_datefield)){
            $option_type = "datetime";
        }

        $field_options = $ADVANCED_FILTER_OPTIONS_BY_TYPE[$option_type];
        $field_options_Arr = $this->removeOptions($field_options,$option_type);
        $fieldValuesArr['type'] = $fieldtype;
        $fieldValuesArr['field_options'] =  $field_options_Arr;
        return $fieldValuesArr;
        
    }
    /**
     * 
     * Generate Query condition
     */
    public function generateCondition($request){
      
      global $adb;

        $moduleName = $request->get('moduleName');
        
        include_once "modules/$moduleName/$moduleName.php";
        $moduleObj = new $moduleName();
        $module_tabname = $moduleObj->tab_name;
      $roles = $request->get('roles');

      $fieldsgrp = $request->get('sectionContainer');
      $conditionOperator = $request->get('conditionOperator');
      
      $fieldsArr = [];
      $related_fields = [];
      $fieldsArr['sectionContainer'] = $fieldsgrp;

      // Get column name 
      /*
      $workflowModel = Settings_Workflows_Record_Model::getCleanInstance($moduleName);
      $recordStrucure = Vtiger_RecordStructure_Model::getInstanceFromRecordModel($workflowModel,
              Vtiger_RecordStructure_Model::RECORD_STRUCTURE_MODE_DETAIL);
      $structuredValues = $recordStrucure->getStructure();
      $ADVANCED_FILTER_OPTIONS_BY_TYPE = Settings_Workflows_Field_Model::getAdvancedFilterOpsByFieldType();
      $ADVANCED_FILTER_OPTIONS_BY_TYPE_OPTIONS = Settings_Workflows_Field_Model::getAdvancedFilterOptions();

      foreach($structuredValues as $key=>$value){
          foreach($value as $lbkey=>$lbvalue){

              $fieldNames['key'][] = $lbkey;
              $fieldNames['label'][] = $lbvalue->label;
              $fieldNames['table'][] = $lbvalue->table;
              $fieldNames['uitype'][] = $lbvalue->uitype;
          }
      }
      */
            
      foreach($fieldsgrp as $operator => $condition){
          foreach($condition['columnList'] as $key=>$value){

              $columnList = $condition['columnList'][$key];
              $tableName = $condition['tableName'][$key];
              $columnName = $condition['tableName'][$key].'.'.$condition['columnList'][$key];
              $inputElement = $condition["inputElement"][$key];
              $related_fields[$tableName] = " left join $tableName on $tableName.$columnList = vtiger_crmentity.crmid";   
              if($condition['conditionComparator'][$key] == 'is'){
                  $query .= $columnName.' = '."'$inputElement'";
              } elseif($condition['conditionComparator'][$key] == 'is not'){
                  $query .= $columnName.' != '."'$inputElement'";
              } elseif($condition['conditionComparator'][$key] == 'contains'){
                  $query .=$columnName. ' like ' ."'%$inputElement%'";
              } elseif($condition['conditionComparator'][$key] == 'does not contain'){
                  $query .=$columnName.' NOT like '."'%$inputElement%'";
              } elseif($condition['conditionComparator'][$key] == 'starts with'){
                  $query .=$columnName.' like '."'%$inputElement'";
              }elseif($condition['conditionComparator'][$key] == 'ends with'){
                  $query .=$columnName.' like '."'$inputElement%'";
              } elseif($condition['conditionComparator'][$key] == 'is empty'){
                  $query .= $columnName. ' = ' ."''";
              }elseif($condition['conditionComparator'][$key] == 'is not empty'){
                  $query .= $columnName. ' != ' ."''";
              }elseif($condition['conditionComparator'][$key] == 'equals'){
                  $query .= $columnName. ' = ' ."'$inputElement'";
              }elseif($condition['conditionComparator'][$key] == 'greater than'){
                  $query .= $columnName. ' >= ' ."'$inputElement'";
              }elseif($condition['conditionComparator'][$key] == 'less than'){
                  $query .= $columnName. ' <= ' ."'$inputElement'";
              }
              $count = $key + 1;
              $columnLisCount = count($condition['conditionComparator']);
              if($count != $columnLisCount){
                  $query .= " $operator ";
              }else{
                  $query .= " OR ";
              }

          }
      }
      $query = trim($query , ' ');
      $query = substr($query, 0, -3);
      $resultData['moduleName'] = $moduleName;
      $resultData['roles'] = $roles;
      $resultData['query'] = $query; 
      $resultData['fields'] = $fieldsArr;
      $resultData['related_fields'] = $related_fields;
      return $resultData;

    }
    public function getHeaderScripts(Vtiger_Request $request) {

      $headerScriptInstances = parent::getHeaderScripts($request);
      $moduleName = $request->getModule();
  
      $jsFileNames = array(
        'modules.Settings.Vtiger.resources.Edit',
        "modules.Settings.Workflows.resources.Edit",
        "modules.Vtiger.resources.AdvanceFilter",
        "modules.Settings.$moduleName.resources.AntListViewFilter",
        '~libraries/jquery/ckeditor/ckeditor.js',
        "modules.Vtiger.resources.CkEditor",
              '~/libraries/jquery/bootstrapswitch/js/bootstrap-switch.min.js',
        '~libraries/jquery/jquery.datepick.package-4.1.0/jquery.datepick.js',
      );
      
      $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
      $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
      return $headerScriptInstances;
    }
      /**
    *
    *Remove options type
    */
    public function removeOptions($field_options,$option_type = 'text'){

         $remove_options_type =  ['has changed','has changed to','has changed from'];
         if($option_type == 'datetime'){
            
            $field_options_arr = ['equals','greater than','less than'];
         }else{
        foreach($field_options as $option_key => $option_value){

            if(in_array($option_value,$remove_options_type)){
                unset($field_options[$option_key]);
            }
        }

            $field_options_arr = array_values($field_options);
            }
            return $field_options_arr;
    }

}
?>

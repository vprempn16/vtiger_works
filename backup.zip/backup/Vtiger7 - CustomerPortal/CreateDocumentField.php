<?php
include_once('vtlib/Vtiger/Module.php');

// Module Instance 
$moduleName='Documents';
$moduleInstance = Vtiger_Module::getInstance($moduleName);
// Add new Field 
$blockInstance = Vtiger_Block::getInstance('LBL_NOTE_INFORMATION', $moduleInstance); 
$fieldInstance = new Vtiger_Field();
$fieldInstance->name = 'show_in_portal';
$fieldInstance->table = 'vtiger_notes';
$fieldInstance->column = 'show_in_portal';
$fieldInstance->label = 'Show document in portal?';
$fieldInstance->columntype = '';
$fieldInstance->uitype = 56;
$fieldInstance->typeofdata = '';
$blockInstance->addField($fieldInstance);
echo"ok";

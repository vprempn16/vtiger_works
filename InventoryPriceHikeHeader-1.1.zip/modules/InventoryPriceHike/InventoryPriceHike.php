<?php
class InventoryPriceHike{
    function vtlib_handler($moduleName, $eventType) {
        if ($moduleName == 'InventoryPriceHike') {
            $db = PearDatabase::getInstance();
            include_once 'modules/InventoryPriceHike/InventoryPriceHikeCustom.php';
            $InventoryPriceHikeCustom = new InventoryPriceHikeCustom();
            if ($eventType == 'module.disabled') {
                $InventoryPriceHikeCustom->postDisable();
            } else if ($eventType == 'module.enabled') {
                    $InventoryPriceHikeCustom->postEnable();
            } else if( $eventType == 'module.preuninstall' ) {
                $InventoryPriceHikeCustom->postDisable();
            } else if( $eventType == 'module.postinstall' ) {
                $InventoryPriceHikeCustom->postInstall();
            } else if( $eventType == 'module.postupdate' ) {
               $InventoryPriceHikeCustom->postUpdate();
            }
        }
    }
}

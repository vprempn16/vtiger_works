<?php 
class Settings_AtomPipeline_LicenseManager_Model extends Vtiger_Base_Model{

    public function getLicenseViewUrl() {
        global $site_URL;
        return $site_URL.'index.php?module=AtomPipeline&parent=Settings&view=LicenseManagerEdit';
    }

    public function apiCall($license_key,$action) {
        if($license_key != '' && $action != ''){
            global $site_URL;
            $url = 'https://demo.gamma.atomlines.com/wp/wpstore/wp-json/atomlicense-manageraddon/v1/' .$action. '?license_key=' . urlencode($license_key).'&site_Url='.urlencode($site_URL);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    'Content-Type: application/json',
            ]);
            $response = curl_exec($ch);
            if (curl_errno($ch)) {
                return [
                    'status' => false,
                    'error' => curl_error($ch),
                ];
            }
            curl_close($ch);
            return json_decode($response, true);
        }else{
            return ["License key or Action empty"];
        }
    }
    public function getRecordDetails($id=""){
        global $adb;
        $columns = Array("pipeline_license_key");
        $return = Array();

        $result = $adb->pquery("SELECT * FROM atom_license_manager",array());
        $num_rows = $adb->num_rows($result);
        if($num_rows > 0){
            for($i=0;$i<$num_rows; $i++){
                $meta_key = $adb->query_result($result,$i,'meta_key');
                $meta_value = $adb->query_result($result,$i,'meta_value');
                $return[$meta_key] =  $meta_value;
            }
        }
        return $return;

    }
    public function ActivateSettings(){
        $this->SettingsLink();
        $this->addHeaderJs();
    }
    public function SettingsLink(){
         global $adb;
        $nextNum = $adb->pquery('select id from vtiger_settings_field_seq');
        $fieldId = $adb->query_result($nextNum, 0 , 'id');
        $fieldId ++;

        $link = 'index.php?module=AtomPipeline&parent=Settings&view=AtomPipeline';
        $block_res = $adb->pquery("SELECT blockid FROM vtiger_settings_blocks WHERE label = ?",array( 'LBL_CONFIGURATION' ));
        if( $adb->num_rows( $block_res ) > 0 ) {
            $blockid = $adb->query_result( $block_res , 0 , 'blockid' );
        }
        $tableValue = $adb->pquery("select name,linkto from vtiger_settings_field WHERE name=? and linkto=?",array('Atom Pipeline Settings',$link));
        $num_rows = $adb->num_rows($tableValue);
        if( $num_rows === 0 ) {
            $fieldseq_res = $adb->pquery("SELECT MAX( sequence ) as sequence FROM vtiger_settings_field WHERE blockid = ?" , array( $blockid ) );
            if( $adb->num_rows( $fieldseq_res ) > 0 )
            {
                $seq = (int)$adb->query_result( $fieldseq_res , 0 , 'sequence' );
                $seq++;
            }
            else {
                $seq = 1;
            }
            $adb->pquery("INSERT into vtiger_settings_field(fieldid,blockid,name,linkto , sequence ) VALUES (?,?,?,?, ? )",array($fieldId, $blockid ,'Atom Pipeline Settings',$link , $seq ));
            $adb->pquery("update vtiger_settings_field_seq set id=?",array($fieldId));
        }

    }
    public function addHeaderJs(){
        $linklabel = "Atom Pipeline JS";
        $linkurl = "layouts/v7/modules/AtomPipeline/resources/AtomPipeline.js";
        Vtiger_Link::addLink( 0 , 'HEADERSCRIPT' , $linklabel , $linkurl );
    }
    public function DeactivateSettings(){
        $this->removeSettingsLink();
        $this->removeHeaderJs();
    }
    public function removeSettingsLink(){
        global $adb;
        $name = "Atom Pipeline Settings";
        $linkto = "index.php?module=AtomPipeline&parent=Settings&view=AtomPipeline";
        $result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
        $num_rows = $adb->num_rows($result);
        if($num_rows == 1) {
            $adb->pquery("DELETE FROM vtiger_settings_field WHERE name = ?", array($name));
        } 
    }
    public function removeHeaderJs(){
        $linklabel = "Atom Pipeline JS";
        $linkurl = "layouts/v7/modules/AtomPipeline/resources/AtomPipeline.js";
        Vtiger_Link::deleteLink( 0 , 'HEADERSCRIPT' , $linklabel , $linkurl );
    }

}

?>












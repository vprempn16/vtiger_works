<?php
class Settings_AtomPipeline_SaveModuleStatus_Action extends Settings_Vtiger_Index_Action{
	function process(Vtiger_Request $request) {
		global $adb;
		$response = new Vtiger_Response();
		$moduleName = $request->getModule(false);
		$relModule = $request->get('modulename');
		$ischecked = $request->get('is_checked');
		$fieldname = $request->get('fieldname');
		$result = $adb->pquery('SELECT * FROM atom_pipeline_settings WHERE module_name = ?',array($relModule));
		$num_rows = $adb->num_rows($result);
		if($num_rows){
			$adb->pquery('UPDATE atom_pipeline_settings SET status=? WHERE module_name = ?',array($ischecked,$relModule));
		}else{
			$adb->pquery('INSERT INTO atom_pipeline_settings(module_name, field_name, status) VALUES (?,?,?)',array($relModule,$fieldname,$ischecked));
		}
		$response->emit();
	}
}

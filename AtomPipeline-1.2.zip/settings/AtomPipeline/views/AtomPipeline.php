<?php
require_once 'include/database/PearDatabase.php';
class Settings_AtomPipeline_AtomPipeline_View extends Settings_Vtiger_Index_View {

	 public function preProcess(Vtiger_Request $request, $display=true){
        $validator = new Settings_AtomPipeline_LicenseManager_Model();

        $licensekey_records = $validator->getRecordDetails();
        $license_key = $licensekey_records['pipeline_license_key'];
        $license_key = Vtiger_Functions::fromProtectedText($license_key);

        $is_validate = $validator->apiCall($license_key,'validate');
        $is_active = $validator->apiCall($license_key,'is_active');
        $licenseview_url = $validator->getLicenseViewUrl();
        if(!$is_validate['iskeyvalid']){
            header("Location:".$licenseview_url);
            exit();
        }
        if(!$is_active['iskeyactive']){
            header("Location:".$licenseview_url."&keyactive=false");
            exit();
        }

        parent::preProcess($request, false);
        $this->preProcessSettings($request,$display);
    }
    function process(Vtiger_Request $request) {
		$viewer = $this->getViewer($request);
		$moduleName = $request->getModule(false);

		// Get active modules from vtiger_tab
		$activeModules = $this->getActiveModules();

		$viewer->assign('MODULES',$activeModules);
		$viewer->view('AtomPipeline.tpl',$moduleName);
	}

	function getActiveModules() {
		global $adb;

		$activeModules = array();

		// Query to fetch active modules from vtiger_tab
		$query = "SELECT * FROM vtiger_tab WHERE isentitytype = '1'";
		$result = $adb->query($query);

		while ($row = $adb->fetchByAssoc($result)) {
			$moduleName = $row['name'];
			$moduleLabel = getTranslatedString($row['tablabel'], $moduleName);
			$moduleIcon = $row['icon'];
			$moduleIcon = $this->getCompleteIconPath($moduleIcon);
			$picklistFields = $this->getPicklistFieldsForModule($moduleName);
			$moduleDet = $adb->pquery('SELECT status , field_name  FROM atom_pipeline_settings WHERE module_name = ?',array($moduleName));

			$activeModules[$moduleName] = array(
				'label' => $moduleLabel,
				'icon' => $moduleIcon,
				'fieldname' => $adb->query_result_rowdata($moduleDet,0)['field_name'],
				'status' => $adb->query_result_rowdata($moduleDet,0)['status'],
				'picklistFields' => $picklistFields
			);
		}
		return $activeModules;
	}

	function getPicklistFieldsForModule($moduleName) {
		global $adb;

		$picklistFields = array();

		// Query to fetch picklist fields for the given module
		$query = "SELECT columnname,fieldlabel FROM vtiger_field WHERE tabid = (SELECT tabid FROM vtiger_tab WHERE name = '$moduleName') AND uitype = 15";
		$result = $adb->query($query);

		while ($row = $adb->fetchByAssoc($result)) {
			$picklistFields[$row['columnname']] = $row['fieldlabel'];
		}

		return $picklistFields;
	}

	function getCompleteIconPath($iconName) {
		// Check if the icon name contains the file extension
		if (pathinfo($iconName, PATHINFO_EXTENSION) == '') {
			// If not, assume it needs a file extension (e.g., .png)
			$iconName .= '.png';
		}

		// You might need to adjust this based on the actual path or URL structure
		$iconPath = 'layouts/vlayout/modules/' . $iconName;

		return $iconPath;
	}
	public function getHeaderScripts(Vtiger_Request $request) {
		$headerScriptInstances = parent::getHeaderScripts($request);
		$moduleName = $request->getModule();

		$jsFileNames = array(
			"modules.$moduleName.resources.AtomPipeline",
			'~/libraries/jquery/bootstrapswitch/js/bootstrap-switch.min.js',
			"~layouts/v7/lib/jquery/Lightweight-jQuery-In-page-Filtering-Plugin-instaFilta/instafilta.js",
			"~layouts/v7/lib/jquery/floatThead/jquery.floatThead.js",
			"~layouts/v7/lib/jquery/perfect-scrollbar/js/perfect-scrollbar.jquery.js",
		);

		$jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
		$headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
		return $headerScriptInstances;
	}
	public function getHeaderCss(Vtiger_Request $request) {
                $headerCssInstances = parent::getHeaderCss($request);
                $cssFileNames = array(
                        '~/libraries/jquery/bootstrapswitch/css/bootstrap3/bootstrap-switch.min.css',
                        "~layouts/v7/lib/jquery/perfect-scrollbar/css/perfect-scrollbar.css",
                );
                $cssInstances = $this->checkAndConvertCssStyles($cssFileNames);
                $headerCssInstances = array_merge($headerCssInstances, $cssInstances);
                return $headerCssInstances;
        }
}
?>


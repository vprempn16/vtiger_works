<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
include_once( "modules/AtomPipeline/Helper.php" );
class AtomPipeline_CheckPipelineEnabledForModule_Action extends Vtiger_Action_Controller {
    public function process(Vtiger_Request $request) {
        global $adb , $current_user;
        $response = new Vtiger_Response();
        try {
            $Helper = new AtomPipelineHelper();
            $relModule = $request->get('relModule');
            $validator = new Settings_AtomPipeline_LicenseManager_Model();

            $licensekey_records = $validator->getRecordDetails();
            $license_key = $licensekey_records['pipeline_license_key'];
            $license_key = Vtiger_Functions::fromProtectedText($license_key);

            $is_validate = $validator->apiCall($license_key,'validate');
            $is_active = $validator->apiCall($license_key,'is_active');
            if(!$is_validate['iskeyvalid'] || !$is_active['iskeyactive']){
                if(!$is_validate['iskeyvalid']){
                    $response->setError(vtranslate("License Key is not valid"));
                }else if(!$is_validate['iskeyvalid']){
                    $response->setError(vtranslate("License Key is not Active.Please Activate your License key"));
                }
            }else{
                if( $Helper->checkModuleEnabled( $relModule ) ) {
                    // removed decode_html to eliminate XSS vulnerability
                    $response->setEmitType(Vtiger_Response::$EMIT_JSON);
                    $response->setResult(true);
                }
                else {
                    $response->setError(vtranslate("Pipeline not enabled for {$relModule} module"));
                }
            }
        } catch (DuplicateException $e) {
            $response->setError($e->getMessage(), $e->getDuplicationMessage(), $e->getMessage());
        } catch (Exception $e) {
            $response->setError($e->getMessage());
        }
        $response->emit();
    }
}

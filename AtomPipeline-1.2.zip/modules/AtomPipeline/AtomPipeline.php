<?php
class AtomPipeline{
	function vtlib_handler($moduleName, $eventType) {
		if ($moduleName == 'AtomPipeline') {
			$db = PearDatabase::getInstance();
			if ($eventType == 'module.disabled') {
				$db->pquery('UPDATE vtiger_settings_field SET active=1 WHERE name=?', array('Atom Pipeline Settings'));
				$this->deleteHeaderLink();
			} else if ($eventType == 'module.enabled') {
				$db->pquery('UPDATE vtiger_settings_field SET active=0 WHERE name=?', array('Atom Pipeline Settings'));
				$this->createSettingPage();
				//$this->insertHeaderLink();
                $this->createCustomTables();
			} else if( $eventType == 'module.preuninstall' ) {
				$db->pquery('UPDATE vtiger_settings_field SET active=1 WHERE name=?', array('Atom Pipeline Settings'));	
				$this->deleteHeaderLink();
			} else if( $eventType == 'module.postinstall' ) {
				$db->pquery('UPDATE vtiger_settings_field SET active=0 WHERE name=?', array('Atom Pipeline Settings'));
				$this->createSettingPage();
				//$this->insertHeaderLink();
                $this->createCustomTables();
			} else if( $eventType == 'module.postupdate' ) {
				$db->pquery('UPDATE vtiger_settings_field SET active=0 WHERE name=?', array('Atom Pipeline Settings'));
				$this->createSettingPage();
				//$this->insertHeaderLink();
                $this->createCustomTables();
			}
		}
	}

	function createSettingPage(){
        global $adb;
        $name = "Atom Pipeline License Manager";
        $description = "Configure License Manager";
        $linkto = "index.php?parent=Settings&module=AtomPipeline&view=LicenseManagerEdit";
        $result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
        $num_rows = $adb->num_rows($result);
        if($num_rows == 0) {
            $otherSettingsBlock = $adb->pquery('SELECT * FROM vtiger_settings_blocks WHERE label=?', array('LBL_CONFIGURATION'));
            $otherSettingsBlockCount = $adb->num_rows($otherSettingsBlock);

            if ($otherSettingsBlockCount > 0) {
                $blockid = $adb->query_result($otherSettingsBlock, 0, 'blockid');
                $sequenceResult = $adb->pquery("SELECT max(sequence) as sequence FROM vtiger_settings_blocks WHERE blockid=?", array($blockid));
                if ($adb->num_rows($sequenceResult)) {
                    $sequence = $adb->query_result($sequenceResult, 0, 'sequence');
                }
            }

            $fieldid = $adb->getUniqueID('vtiger_settings_field');

            $adb->pquery("INSERT INTO vtiger_settings_field(fieldid, blockid, name, iconpath, description, linkto, sequence, active , pinned) VALUES(?,?,?,?,?,?,?,?,?)", array($fieldid, $blockid, $name, '',$description, $linkto, $sequence++, 0 , 1));

            $adb->pquery("UPDATE vtiger_settings_field_seq SET id = ?",array($fieldid));
        }
	}
     function createCustomTables(){
        global $adb;

        $table_sql['atom_license_manager'] = "CREATE TABLE `atom_license_manager` (
            `id` int NOT NULL AUTO_INCREMENT,
            `meta_key` varchar(255) NOT NULL,
            `meta_value` longtext NOT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3";

        foreach($table_sql as $table_name => $sql){
            $table_exist_result = $adb->pquery("SHOW TABLES LIKE '$table_name'",array());
            $num_rows = $adb->num_rows($table_exist_result);

            if($num_rows == 0){
                $adb->pquery($sql,array());
            }

        }
        $adb->pquery("UPDATE vtiger_tab SET customized = 0 WHERE name = 'AtomPipeline'",array());
    }

	function deleteHeaderLink() {
		$linklabel = "Atom Pipeline JS";
		$linkurl = "layouts/v7/modules/AtomPipeline/resources/AtomPipeline.js";
		Vtiger_Link::deleteLink( 0 , 'HEADERSCRIPT' , $linklabel , $linkurl );
	}
}

<?php
class AtomPipelineHelper {
	function checkModuleEnabled( $modulname ) {
		global $adb;
		$res = $adb->pquery( "SELECT * FROM atom_pipeline_settings WHERE module_name = ? AND status = ?" , array( $modulname , 1 ) );
		if( $adb->num_rows( $res ) > 0 ) {
			return true;
		}
		return false;
	}
	
	function getPipeFieldName( $moduleName ) {
		global $adb;
		$result = $adb->pquery('SELECT field_name FROM atom_pipeline_settings WHERE module_name = ?', array($moduleName));
		if ($adb->num_rows($result) > 0) {
			$fieldName = $adb->query_result($result, 0, 'field_name');
		}
		return $fieldName;
	}

	function getPicklists( $fieldName , $moduleName ) {
		global $adb;
		$picklistValues = array();
		$fieldModel = Vtiger_Field_Model::getInstance($fieldName, Vtiger_Module_Model::getInstance($moduleName));
		if ($fieldModel->getFieldDataType() == 'picklist') {
			$picklistValues_wo_na = $fieldModel->getPicklistValues();
			$picklistValues_colors = $fieldModel->getPicklistColors();
		}
		$picklistValues['N/A'] =  array( 'label' => 'N/A' , 'bgcolor' => '#f7f8f9' , 'color' => '#000000' );
		foreach( $picklistValues_wo_na as $picklistValue => $picklistLabel )
		{
			$picklistValues[$picklistValue] = array( 'label' => $picklistLabel , 'bgcolor' => $picklistValues_colors[$picklistValue] , 'color' => $this->getContrastColor( $picklistValues_colors[$picklistValue] ) );
		}

		return $picklistValues;
	}

	function getListViewEntries( $moduleName , $fieldName , $LVHeaders , $LVEntries , $picklistValues ) {
		global $adb;
		include_once 'vtlib/Vtiger/Module.php';
		$ModuleInstance = Vtiger_Module::getInstance( $moduleName );
		if( $moduleName != 'Calendar' && $moduleName != 'Events' ) {
			include_once( "modules/{$moduleName}/{$moduleName}.php" );
			$ModuleObj = new $moduleName();
		}
		$FieldInstance = Vtiger_Field::getInstance( $fieldName , $ModuleInstance );
		$TabIndex = $ModuleObj->tab_name_index[$FieldInstance->table];
		foreach( $LVEntries as $recordid => $listViewEntry ){
			$listViewEntry->recordlabel = Vtiger_Functions::getCRMRecordLabel($recordid);
			if( array_key_exists( $fieldName , $LVHeaders ) ) {
				//$ListViewEntries[$listViewEntry['rawData'][$fieldName]][$recordid] = $listViewEntry;
                		$ListViewEntries[$listViewEntry->rawData[$fieldName]][$recordid] = $listViewEntry;
			} else {
				$pickres = $adb->pquery( "SELECT * FROM {$FieldInstance->table} WHERE {$TabIndex} = ?" , array( $recordid ) );
				$pickresvalue = $adb->query_result($pickres,0,$fieldName);
				if( $pickresvalue == "" ) {
					$ListViewEntries['N/A'][$recordid] = $listViewEntry;
				} else {
					$ListViewEntries[$pickresvalue][$recordid] = $listViewEntry;
				}
			}
		}
		
		foreach ($picklistValues as $picklistValue => $picklistValueDetails) {
                        if (is_scalar($picklistValue) && isset($ListViewEntries[$picklistValue])) {
                                // Only assign if picklistValue is a valid string/int and exists in ListViewEntries
                                $ListViewEntriesOrdered[$picklistValue] = $ListViewEntries[$picklistValue];
                        }
                }

		if( $ListViewEntries['N/A'] == '' ) {
			unset($ListViewEntries['N/A']);
			unset($picklistValues['N/A']);
		}
		return $ListViewEntries;
	}

	function getDisplayableRecordValue( $recordid , $recordModel , $listViewHeaders ) {
		$DisplayableFieldValue = array();
		$moduleModel = $recordModel->getModule();
		foreach( $listViewHeaders as $listViewHeader ) {
			$fieldname = $listViewHeader->get('name');
			$FieldModel = Vtiger_Field_Model::getInstance( $fieldname , $moduleModel );
			$DisplayableFieldValue[$fieldname] = $FieldModel->getDisplayValue( $recordModel->get( $fieldname , $recordid , $recordModel ) );
		}
		return $DisplayableFieldValue;
	}

	function getContrastColor($backgroundColor) {
		// Convert hex color to RGB
		list($r, $g, $b) = sscanf($backgroundColor, "#%02x%02x%02x");

		// Calculate luminance using relative luminance formula
		$luminance = 0.299 * $r + 0.587 * $g + 0.114 * $b;

		// Determine whether to use dark or light text color based on luminance
		$textColor = ($luminance > 128) ? "#000000" : "#ffffff";

		return $textColor;
	}
}

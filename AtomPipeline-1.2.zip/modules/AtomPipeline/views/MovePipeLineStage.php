<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
include_once( "modules/AtomPipeline/Helper.php" );
class AtomPipeline_MovePipeLineStage_View extends Vtiger_Basic_View {
	public $PipeFieldName = "";
	public function process(Vtiger_Request $request) {
		global $adb , $current_user;
		$response = new Vtiger_Response();
		$viewer = $this->getViewer ($request);
		try {
			$Helper = new AtomPipelineHelper();
			$relModule = $request->get('relModule');
			if( $Helper->checkModuleEnabled( $relModule ) ) {
				$recordid = $request->get('recordid');
				$tostage = $request->get('tostage');
				$cvid = $request->get('cvid');

				$listViewModel = Vtiger_ListView_Model::getInstance($relModule, $cvid);
				$listViewHeaders = $listViewModel->getListViewHeaders();
				$this->PipeFieldName = $Helper->getPipeFieldName( $relModule );
				$Obj = Vtiger_Record_Model::getInstanceById($recordid,$relModule);
				$Obj->set('mode','edit');
				$Obj->set($this->PipeFieldName,$tostage);
				$Obj->save();
				$moduleModel = Vtiger_Module_Model::getInstance($relModule);
				$viewer->assign('MODULE_MODEL', $moduleModel);
				$viewer->assign('LISTVIEW_HEADERS', $listViewHeaders);		
				$viewer->assign('RECORDDETAILS',$Obj);
				$viewer->assign('DISPLAYABLERECORDVALUE' , $Helper->getDisplayableRecordValue( $recordid , $Obj , $listViewHeaders ) );

				//$recordStrucure = Vtiger_RecordStructure_Model::getInstanceFromRecordModel($Obj, Vtiger_RecordStructure_Model::RECORD_STRUCTURE_MODE_DETAIL);
				//$viewer->assign('RECORD_STRUCTURE',$recordStrucure);
				
				$viewer->assign('recordlabel', Vtiger_Functions::getCRMRecordLabel($recordid) );
				$viewer->assign('MODULE',$relModule);
				$viewer->assign('RECORDID',$recordid);
				$viewer->assign('CURRENT_USER_MODEL', Users_Record_Model::getCurrentUserModel());
				$viewer->view('MovePipeLineStage.tpl', 'AtomPipeline' );
			}
			else {
			}
		} catch (Exception $e) {
		}

	}
}

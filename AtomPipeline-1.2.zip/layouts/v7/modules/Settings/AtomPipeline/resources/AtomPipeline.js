Vtiger.Class('Settings_AtomPipeline_AtomPipeline_Js', {},{
	validateForm : function( container = false ){
		var thisInstance = this;
		var vflag = true;
		if( container == false ) {
			jQuery(document).find('.inputElement').each(function(){
				var ele = jQuery(this);
				var isman = ele.attr('data-rule-required');
				if(isman == "true"){
					if(ele.val() == ''){
						thisInstance.showValidationMessage(ele,"Required Field");
						vflag = false;
					}else{
						thisInstance.hideValidationMessage(ele);
					}
				}
			});
		}
		else {
			container.find('.inputElement').each(function(){
				var ele = jQuery(this);
				var isman = ele.attr('data-rule-required');
				if(isman == "true"){
					if(ele.val() == ''){
						thisInstance.showValidationMessage(ele,"Required Field");
						vflag = false;
					}else{
						thisInstance.hideValidationMessage(ele);
					}
				}
			});
		}
		return vflag;
	},
	showValidationMessage : function(element,message) {
		if(element.hasClass('select2')) {
			element = app.helper.getSelect2FromSelect(element);
		}

		params = {};

		var validationTooltipParams = {
			position: {
				my: 'bottom left',
				at: 'top left'
			},
			style: {
				classes: 'qtip-red qtip-shadow'
			}
		};

		jQuery.extend(validationTooltipParams,params);
		this.showQtip(element,message,validationTooltipParams);
		element.addClass('input-error');
	},

	showQtip : function(element,message,customParams) {
		if(typeof customParams === 'undefined') {
			customParams = {};
		}
		var qtipParams =  {
			content: {
				text: message
			},
			show: {
				event: 'Vtiger.Qtip.ShowMesssage'
			},
			hide: {
				event: 'Vtiger.Qtip.HideMesssage'
			}
		};
		jQuery.extend(qtipParams,customParams);

		element.qtip(qtipParams);
		element.trigger('Vtiger.Qtip.ShowMesssage');
	},

	hideValidationMessage : function(element) {
		if(element.hasClass('select2')) {
			element = app.helper.getSelect2FromSelect(element);
		}
		element.trigger('Vtiger.Validation.Hide.Messsage');
		this.hideQtip(element);
		element.removeClass('input-error');
	},
	hideQtip : function(element) {
		element.trigger('Vtiger.Qtip.HideMesssage');
	},
	SaveModuleStatus: function(){
		var thisInsatnce  = this;
		$('body').on('change','#toggleSwitch,select.fieldName',function(e){
			e.preventDefault();
			var valid = thisInsatnce.validateForm($(this).closest('.listentry'));
			if(valid){
				var params = {};
				params['parent'] = 'Settings';
				params['module'] = 'AtomPipeline';
				params['action'] = 'SaveModuleStatus';
				params['is_checked'] = Number($(this).prop('checked'));
				params['modulename'] = $(this).closest('.listentry').find('#details').val();
				params['fieldname'] = $(this).closest('.listentry').find('select.fieldName').val();
				app.helper.showProgress();
				app.request.get({data:params}).then(function(err,data){
					app.helper.hideProgress();

				});
			}else{
				$(this).prop('checked',false);
			}
		});	
	},
	registerEvents : function() {
		this.SaveModuleStatus();
		console.log(33);
	},
});

<?php
// Turn on debugging level
$Vtiger_Utils_Log = true;

require_once 'include/utils/utils.php';
include_once('vtlib/Vtiger/Module.php');
require 'modules/com_vtiger_workflow/VTEntityMethodManager.inc';
global $adb;

$emm = new VTEntityMethodManager($adb);
$emm->addEntityMethod("Contacts", "Link / Unlink ", "modules/Contacts/LinkOrUnlinkRecords.php", "linkOrUnlinkRecords");

echo 'add Workflow Custom Function complete!';
?>


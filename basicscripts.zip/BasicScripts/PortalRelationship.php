<?php

include_once('vtlib/Vtiger/Module.php');
$moduleInstance = Vtiger_Module::getInstance('Contacts');
$accountsModule = Vtiger_Module::getInstance('BACustomerPortal');
$relationLabel = 'Portal';
$moduleInstance->setRelatedList(
$accountsModule, $relationLabel, Array('add')
);
echo 'Relation Added SAuccessfully ';

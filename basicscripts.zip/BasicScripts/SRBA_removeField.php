<?php

$Vtiger_Utils_Log = true;

include_once ('vtlib/Vtiger/Module.php');
$moduleInstance = new Vtiger_Module ();

$moduleInstance = Vtiger_Module::getInstance ( 'Contacts' );
	//parametters	Column name and Module name			
$fieldInstance = Vtiger_Field::getInstance ( 'group_diff', $moduleInstance );

if ($fieldInstance) {

$fieldInstance->delete (); echo "Deleted field.";

} else {

echo "Field Not found.";

}

<?php
include_once('vtlib/Vtiger/Module.php');
include_once 'includes/main/WebUI.php';

// Get pick list values (Tag  names)
global $adb;	
$getTagsName = $adb->pquery('select tag_name from vtiger_srba_tag_letter');
while( $row = $adb->fetch_array($getTagsName) ) {
	$tagsName[] = $row['tag_name'];
}


// Module Instance 
$moduleName='Contacts';
$moduleInstance = Vtiger_Module::getInstance($moduleName);
$blockInstance = Vtiger_Block::getInstance('LBL_CONTACT_INFORMATION', $moduleInstance); 
if($blockInstance) {

$fieldInstance = new Vtiger_Field();
$fieldInstance->name = 'group_diff';			              //Usually matches column name
$fieldInstance->table = 'vtiger_contactdetails';
$fieldInstance->column = 'group_diff';		                     //Must be lower case
$fieldInstance->label = 'Group Diff';		            //Upper case preceeded by LBL_
$fieldInstance->columntype = 'VARCHAR(128)';	    //
$fieldInstance->uitype = 33;			                   //Multi-Combo picklist
$fieldInstance->typeofdata = 'V~M~LE~128';	  //V=Varchar?, M=Mandatory, O=Optional
$fieldInstance->setPicklistValues( Array ('Fulham', 'Chelsea') );
$block->addField($fieldInstance);
/*
	$fieldInstance = new Vtiger_Field();
	$fieldInstance->name = 'group_diff';
	$fieldInstance->table = 'vtiger_contactdetails';
	$fieldInstance->column = 'group_diff';
	$fieldInstance->label = 'Group Diff';
	$fieldInstance->uitype = '15';
	$fieldInstance->typeofdata = '';	
	$blockInstance->addField($fieldInstance);
*/
echo"ok";
} else {
	echo "Block Name is not Found";
}

<?php
include_once('vtlib/Vtiger/Module.php');

// Module Instance 
$moduleName='Documents';
$moduleInstance = Vtiger_Module::getInstance($moduleName);
// Add new Field 
$blockInstance = Vtiger_Block::getInstance('LBL_NOTE_INFORMATION', $moduleInstance); 
$fieldInstance = new Vtiger_Field();
$fieldInstance->name = 'foldername';
$fieldInstance->table = 'vtiger_notes';
$fieldInstance->column = 'foldername';
$fieldInstance->label = 'Document Folder Name';
$fieldInstance->columntype = 'VARCHAR(100)';
$fieldInstance->uitype = 2;
$fieldInstance->typeofdata = '';
$blockInstance->addField($fieldInstance);
echo"ok";

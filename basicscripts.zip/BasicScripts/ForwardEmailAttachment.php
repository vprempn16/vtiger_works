<?php
include_once 'include/Webservices/Relation.php';
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';
include_once 'modules/Vtiger/models/Module.php';
require_once 'include/utils/utils.php';
//error_reporting(E_ALL);
	
		global $adb,$current_user;
		$current_user = Users::getActiveAdminUser();		
		$getPendingEmails = $adb->pquery("select *from vtiger_srba_mail_attachments where status = 'Pending' and user_id = ?  limit 5",array($current_user->id));
		while($row = $adb->fetch_array($getPendingEmails)) {
			$pendingEmails[]= $row;
		}
		for($i = 0 ; $i < count($pendingEmails) ; $i ++ ) {

			$recordModel = unserialize(base64_decode($pendingEmails[$i]['record_model']));
			$recordModel->send($pendingEmails[$i]['forward_list_id']);
			$adb->pquery("update vtiger_srba_mail_attachments set status = 'Complete' where forward_list_id = ?",array($pendingEmails[$i]['forward_list_id']));
		}
		
echo"done";

<?php
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';
require("config.php");
require("modules/Emails/mail.php");
require_once("modules/Emails/class.phpmailer.php");

class SendEmailHandler extends VTEventHandler {
    function handleEvent($eventName, $data) {
        if($eventName == 'vtiger.entity.aftersave') {
            global $adb;
            $parentRecord = $data->get('related_to');
            $getParentModule = $adb->pquery( 'select setype from vtiger_crmentity where crmid = ?' , array($parentRecord) );
            $parentModule = $adb->query_result($getParentModule , 0 , 'setype');
            $subject = $data->get('commentcontent');  // set subject in Commant content 

            $recordModel = Vtiger_Record_Model::getInstanceById($parentRecord, $parentModule);
            $parentEmail = $recordModel->get('email');

            if($parentEmail){

                /* 
                 * Use email template.   

                 $getEmailTemplate = $adb->pquery("select *from vtiger_emailtemplates where templatename= ? or templateid = ?" , array( 'send mail for comment added.' , 17));
                 $subject = $adb->query_result($getEmailTemplate , 0, 'subject');
                 $body = $adb->query_result($getEmailTemplate , 0, 'body');
                 $body = getMergedDescription($body, $parentRecord, $parentModule);

                 */


                $mail = new PHPMailer();
                $mail->Subject = $subject;
                $mail->Body = $body;
                $mail->addAddress($parentEmail);
                $mail->IsHTML(true);

                $mail_status = MailSend($mail);

                if($mail_status != 1)
                {
                    $mail_error = getMailError($mail,$mail_status,$mailto);
                }
                else
                {
                    $mail_error = $mail_status;
                }

                echo "Mail send successfully.";
            }

        }
    }

}
?>

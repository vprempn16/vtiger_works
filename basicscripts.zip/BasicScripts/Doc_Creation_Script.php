<?php
include_once 'include/Webservices/Relation.php';
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';


ini_set('display_errors' , 'on');
error_reporting(E_ALL);

        $attachment_info = '/var/www/html/jasan/SRBA_Scripts/SR_ModuleDownload.php' ;
	createDoc( 3280 , 'BACustomerPortal' , $attachment_info );

function createDoc($rel_id, $rel_module, $attachment_info)
    {
        global $current_user, $upload_badext, $adb, $root_directory;
	$current_user = Users::getActiveAdminUser();

        $filePath = $attachment_info;
        $tmp_fileInfo = pathinfo($attachment_info);
        $fileInfo = new stdClass();
        $fileInfo->filename = $tmp_fileInfo['filename'];
        $fileInfo->basename = $tmp_fileInfo['basename'];
        $file_size = filesize($filePath);

        $folderid = 1;
        $response = array();
        require_once('modules/Documents/Documents.php');
        $doc = new Documents();
        $doc->mode = 'create';
        $doc->id = null;
        $doc->column_fields['notes_title'] = $fileInfo->basename;//;sanitizeUploadFileName($fileInfo->filename, $upload_badext);
        $doc->column_fields['filename'] = $fileInfo->basename;
        $doc->column_fields['filetype'] = $attachment_info['type'];
        $doc->column_fields['filesize'] = $file_size;
        $doc->column_fields['filelocationtype'] = 'I';
        $doc->column_fields['filestatus'] = 1;
        $doc->column_fields['folderid'] = $folderid;
        $doc->column_fields['assigned_user_id'] = $current_user->id;
        $doc->save('Documents');
        if($doc->id)    {
            $response = uploadAndSaveFile($doc->id, $rel_module, $doc, $attachment_info, $filePath);
            // relating record to module
            $adb->pquery('insert into vtiger_senotesrel (crmid, notesid) values (?, ?)', array($rel_id, $doc->id));

            if(vtlib_isModuleActive('ModTracker')) {
                // Track the time the relation was added
                require_once 'modules/ModTracker/ModTracker.php';
                ModTracker::linkRelation($rel_module, $rel_id, 'Documents', $doc->id);
            }
        }
        return $response;
    }
function uploadAndSaveFile($id, $module, $docObj, $file_details, $filePath) {
        global $adb, $current_user, $upload_badext;

        $date_var = date("Y-m-d H:i:s");

        //to get the owner id
        $ownerid = $docObj->column_fields['assigned_user_id'];
        if (!isset($ownerid) || $ownerid == '')
            $ownerid = $current_user->id;

        $file_name = $docObj->column_fields['filename'];

        // For check
        $save_file = 'true';
        //only images are allowed for Image Attachmenttype
        $mimeType = $docObj->column_fields['filetype'];

        $binFile = sanitizeUploadFileName($file_name, $upload_badext);

        $current_id = $adb->getUniqueID("vtiger_crmentity");

        $filename = ltrim(basename(" " . $binFile)); //allowed filename like UTF-8 characters
        $filetype = $docObj->column_fields['filetype'];
        $filesize = $docObj->column_fields['filesize'];
        $filetmp_name = $file_details['tmp_name'];

        //get the file path inwhich folder we want to upload the file
        $upload_file_path = decideFilePath();

        $upload_status = copy($filePath, $upload_file_path . $current_id . "_" . $binFile);

        //upload the file in server
        $sql1 = "insert into vtiger_crmentity (crmid,smcreatorid,smownerid,setype,description,createdtime,modifiedtime) values(?, ?, ?, ?, ?, ?, ?)";
        $params1 = array($current_id, $current_user->id, $ownerid, "Documents Attachment", $docObj->column_fields['description'], $adb->formatDate($date_var, true), $adb->formatDate($date_var, true));
        $adb->pquery($sql1, $params1);

        $sql2 = "insert into vtiger_attachments(attachmentsid, name, description, type, path) values(?, ?, ?, ?, ?)";
        $params2 = array($current_id, $filename, $docObj->column_fields['description'], $filetype, $upload_file_path);
        $result = $adb->pquery($sql2, $params2);

if ($module == 'Documents') {
            $query = "delete from vtiger_seattachmentsrel where crmid = ?";
            $qparams = array($id);
            $adb->pquery($query, $qparams);
        }

        $sql3 = 'insert into vtiger_seattachmentsrel values(?,?)';
        $adb->pquery($sql3, array($id, $current_id));
        return true;
    }


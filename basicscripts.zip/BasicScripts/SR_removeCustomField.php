<?php

$Vtiger_Utils_Log = true;

include_once ('vtlib/Vtiger/Module.php');
$moduleInstance = new Vtiger_Module();

$moduleInstance = Vtiger_Module::getInstance ( 'BALetters' );
$fieldInstance = Vtiger_Field::getInstance ( 'status', $moduleInstance );

if ($fieldInstance) {

$fieldInstance->delete (); echo "Deleted field.";

} else {

echo "Field Not found.";

}

?>

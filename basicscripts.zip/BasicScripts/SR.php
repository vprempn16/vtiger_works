<?php
	
include_once 'vtlib/Vtiger/Link.php';
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';
include_once 'vtlib/Vtiger/Field.php';
     $recordModel = Vtiger_Record_Model::getCleanInstance("Contacts");
	   $recordid =   $recordModel->get_RecordModel('firstname');
     print_r($recordid);
?>   

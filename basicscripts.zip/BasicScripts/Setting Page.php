<?php
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';

global $adb;
$nextNum = $adb->pquery('select id from vtiger_settings_field_seq');
$fieldId = $adb->query_result($nextNum, 0 , 'id');
$fieldId ++;

// Setting page script 
$adb->pquery("insert into vtiger_settings_field (fieldid,blockid,name,linkto)values($fieldId ,4 ,'Customer Portal Settings' ,'index.php?parent=Settings&module=Vtiger&view=CustomerPortalSetting')");
$adb->pquery("update vtiger_settings_field_seq set id = ?",array($fieldId));


// Customer Portal Settings Page 
$adb->pquery('CREATE TABLE `vtiger_srba_customer_portal` ( `id` int(11) NOT NULL AUTO_INCREMENT, `group_name` varchar(100) NOT NULL, `portal_view` varchar(100) NOT NULL,  `panel_name` longtext NOT NULL,  `fields` longtext NOT NULL,  PRIMARY KEY (`id`))');


// Conversation Table
$adb->pquery("CREATE TABLE `vtiger_ba_conversation` (`id` int(11) NOT NULL AUTO_INCREMENT, `contact_id` int(11) NOT NULL, `record_id` int(11) NOT NULL,  `from_id` int(11) NOT NULL,  `message` longtext NOT NULL,  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  PRIMARY KEY (`id`))");


// Expired Token 
$adb->pquery("CREATE TABLE `vtiger_baportaltoken_expired` ( `id` int(11) NOT NULL AUTO_INCREMENT, `token` varchar(250) DEFAULT NULL, PRIMARY KEY (`id`))");
echo "Done.";

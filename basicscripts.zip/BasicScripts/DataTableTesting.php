<?php
chdir(__DIR__ . '/../');	
include_once 'include/Webservices/Relation.php';
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';
ini_set('display_errors' , 'on') ; error_reporting(E_ALL);
global $adb;	
$getSupport = $adb->pquery("select *from vtiger_bacustomerportal left join vtiger_crmentity on vtiger_crmentity.crmid = vtiger_bacustomerportal.bacustomerportalid where vtiger_crmentity.deleted = 0");
while($row = $adb->fetch_array($getSupport)) {
	$supports[] = $row;
}
?>
<html>
<head>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>	
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
	<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
</head>
<body>
<table id ="chat_people">
	<thead>	
		<tr> <th> Recent </th> </tr>
	</thead>
	<tbody> 	
<?php	for($i = 0 ; $i < count($supports) ; $i ++) { ?>

	<tr class="chat_list <?php if($portal_id == $supports[$i]['bacustomerportalid']) { echo"active_chat"; } ?> ">
	    <td class="chat_people" data-portal_id =  <?php echo $supports[$i]['bacustomerportalid']; ?> >
		<div class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
		<div class="chat_ib">
			 <?php  echo $supports[$i]['subject']; ?> <span class="chat_date"> <?php
				$timestamp = $supports[$i]['createdtime'];
				$time = date('H:i',strtotime($timestamp));
				$date = date('d,M', strtotime($timestamp) );
				echo $time ." | ".  $date;
				?>  </span>
	        </div>
	    </td>
	</tr>
		<?php } ?>
	</tbody>
</table>

	<script>
		$(document).ready( function () {
	    		$('#chat_people').DataTable();
		} );	
	</script>
</body>
</html>

		<?php
		require_once 'vtlib/Vtiger/Module.php';
		$vtiger_utils_log = true;

		$modulename = 'Calendar';
		$moduleinstance = vtiger_module::getinstance($modulename);

		require_once 'modules/ModComments/ModComments.php';
		$commentsmodule = vtiger_module::getinstance('Documents');
		$fieldinstance = vtiger_field::getinstance ('related_to', $commentsmodule);
		$fieldinstance-> setrelatedmodules(array($modulename));
		$detailviewblock = modcomments::addwidgetto($modulename);
		echo "Comments section has been created";

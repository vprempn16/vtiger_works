<?php
include_once('vtlib/Vtiger/Module.php');

// Module Instance 
$moduleName='BALetters';
$moduleInstance = Vtiger_Module::getInstance($moduleName);

// Add New Block
$blockInstance = new Vtiger_Block();
$blockInstance->label = 'SR Custom Block';
$moduleInstance->addBlock($blockInstance);

// Add new Field 
$blockInstance = Vtiger_Block::getInstance('SR Custom Block', $moduleInstance); 
$fieldInstance = new Vtiger_Field();
$fieldInstance->name = 'SR Test';
$fieldInstance->table = 'vtiger_baletters';
$fieldInstance->column = 'sr_test';
$fieldInstance->label = 'SR Test Field';
$fieldInstance->columntype = 'VARCHAR(100)';
$fieldInstance->uitype = 2;
$fieldInstance->typeofdata = '';
$blockInstance->addField($fieldInstance);
echo"ok";

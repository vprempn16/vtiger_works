<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once('vtlib/Vtiger/Module.php');

$moduleName='Contacts';
$moduleInstance = Vtiger_Module::getInstance($moduleName);

$blockInstance = Vtiger_Block::getInstance('LBL_CONTACT_INFORMATION', $moduleInstance);

$fieldInstance = new Vtiger_Field();
$fieldInstance->name = 'uploadfile1';
$fieldInstance->table = 'vtiger_contactdetails';
$fieldInstance->column = 'uploadfile1';
$fieldInstance->label='Upload File 1';
$fieldInstance->columntype = 'VARCHAR(200)';
$fieldInstance->uitype = '28';
$fieldInstance->typeofdata = 'V~0';
$blockInstance->addField($fieldInstance);
echo "Done!";

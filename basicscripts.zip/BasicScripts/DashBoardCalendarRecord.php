<?php
include_once 'include/Webservices/Relation.php';
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';
include_once('vtlib/Vtiger/Module.php');
	$moduleInstance = Vtiger_Module::getInstance('Home');
        $moduleInstance->addLink('DASHBOARDWIDGET', 'Calendar Records', 'index.php?module=Home&view=CalendarRecords');
echo "Done";

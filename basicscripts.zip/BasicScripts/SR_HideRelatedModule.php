<?php

include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';

global $adb;
$nextNum = $adb->pquery('select id from vtiger_settings_field_seq');
$fieldId = $adb->query_result($nextNum, 0 , 'id');
$fieldId = $fieldId+1;
$adb->pquery("insert into vtiger_settings_field (fieldid,blockid,name,linkto)values($fieldId ,4 ,'Hide related module' ,'index.php?parent=Settings&module=Vtiger&view=HideRelatedModule')");
$adb->pquery("update vtiger_settings_field_seq set id = ?",array($fieldId));
$adb->pquery("create table srba_hide_rel_mod(id int not null auto_increment primary key, module varchar(20) , rel_module long)"); // Save hide modules in DB	
echo "Done.";

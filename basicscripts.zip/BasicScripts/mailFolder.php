<?php
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';
include_once('vtlib/Vtiger/Module.php');
global $adb;
$adb->pquery("insert into vtiger_settings_field (fieldid,blockid,name,linkto)values(35,4,'Add Folders','index.php?parent=Settings&module=Vtiger&view=MoveMail')");

$adb->pquery("create table vtiger_ba_selectedMailFolders(user_id int not null primary key, folders_name long, bgcolor long,fontcolor long)");
 
?>

<?php
//Summary list view

include_once('vtlib/Vtiger/Module.php');
$moduleInstance = Vtiger_Module::getInstance('Leads');
$accountsModule = Vtiger_Module::getInstance('Contacts');
$relationLabel = 'Contacts';
$moduleInstance->setRelatedList(
$accountsModule, $relationLabel, Array("ADD","SELECT")
);
echo 'Relation Added SAuccessfully ';

<?php 

include_once('vtlib/Vtiger/Module.php');
//$account = Vtiger_Module::getInstance('Accounts');
$custom = Vtiger_Module::getInstance('Leads');
$block = Vtiger_Block::getInstance('LBL_LEAD_INFORMATION', $custom);

// add field
$field = new Vtiger_Field();
$field->name = 'contacts';
$field->label = 'Contact Name'; 
$field->table = 'vtiger_leaddetails';
$field->column = 'contacts';
$field->columntype = 'varchar(255)';
$field->uitype = 10;
$field->typeofdata = 'v~o';
$block->addfield($field);
$field->setrelatedmodules(array('Contacts'));
?>

<?php
include_once('vtlib/Vtiger/Module.php');
$moduleInstance = Vtiger_Module::getInstance('BACustomerPortal');
$moduleInstance->addLink('HEADERSCRIPT', 'BA Customer Portal Script', 'modules/BACustomerPortal/js/BA_Script.js');
echo "Ok";

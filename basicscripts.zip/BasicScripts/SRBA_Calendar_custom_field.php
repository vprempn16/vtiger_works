<?php
include_once('vtlib/Vtiger/Module.php');

// Module Instance 
$moduleName='Events';
$moduleInstance = Vtiger_Module::getInstance($moduleName);
$blockInstance = Vtiger_Block::getInstance('LBL_EVENT_INFORMATION', $moduleInstance); 
if($blockInstance) {
	$fieldInstance = new Vtiger_Field();
	$fieldInstance->name = 'send_mail_notification';
	$fieldInstance->table = 'vtiger_activity';
	$fieldInstance->column = 'send_mail_notification';
	$fieldInstance->label = 'Send Mail Notification';
	$fieldInstance->uitype = '56';
	$fieldInstance->columntype = 'INT(5)';
	$fieldInstance->typeofdata = 'V~O';	
	$blockInstance->addField($fieldInstance);
echo"ok";
} else {
	echo "Block Name is not Found";
}	

jQuery.Class("Atoms_MSmtp",{},{

	registerRedirectModule: function(){
		var form = jQuery("#massEmailForm");		
		if(form.length){
			var prev_module = form.find("input[name='module']").val();
			var source_module = form.find( "input[name='source_module']" ).val();
            var is_module_change = form.find( "input[name='module_change']" ).val();

			if(prev_module == 'Emails' && !is_module_change ){
				var html = '<div class="row "><div class="col-lg-12"><div class="col-lg-2"><span class="pull-right">Subject&nbsp;<span class="redColor">*</span></span></div><div class="col-lg-6"><input type="text" name="subject" value="" data-rule-required="true" id="subject" spellcheck="true" class="inputElement"></div><div class="col-lg-4"></div></div></div>'
				var params = {
					'module' : 'AtomsMSmtp',
					'action': 'getServerSelectHtml'
				};
				app.request.post({'data' : params}).then(
					function(err, data) {
						if(data.success == true){
                            console.log(data.success,'serverMSId');
							jQuery(data.mailServerHtml).insertBefore('.toEmailField');	
							jQuery("#serverMSId").select2({});
				            form.find("input[name='module']").val('AtomsMSmtp');
						}
				}
				);
                form.append('<input type="hidden" name="module_change" value=true>');
			}
		}
	},	
	registerEvents : function(){
		var thisInstance = this;
		thisInstance.registerRedirectModule();
	}
});

jQuery(document).ready(function(e){
                var instance = new Atoms_MSmtp();
                instance.registerEvents();
		$( document ).ajaxComplete(function() {
                	var instance = new Atoms_MSmtp();
                	instance.registerEvents();
		});
});

<?php

class VTAtomCommentsMentions extends CRMEntity {
	function vtlib_handler($moduleName, $eventType) {
		global $adb;
		if($eventType == 'module.postinstall') {
			$this->createCustomTables();
			$this->SettingsLink();
			// TODO Handle actions after this module is installed.
		} else if($eventType == 'module.enabled') {
			// TODO Handle actions when this module is enabled.
		} else if($eventType == 'module.disabled') {
			// TODO Handle actions before this module is being uninstalled.
		} else if($eventType == 'module.preuninstall') {
			// TODO Handle actions when this module is about to be deleted.
		} else if($eventType == 'module.preupdate') {
			// TODO Handle actions before this module is updated.
		} else if($eventType == 'module.postupdate') {
			$this->createCustomTables(); 
			$this->SettingsLink();
		}
	}
	function createCustomTables(){
		global $adb;
		$table_sql['atom_vtcommenton_rel'] = "CREATE TABLE `atom_vtcommenton_rel` (
			`id` int NOT NULL AUTO_INCREMENT,
			`is_checked` varchar(100) NOT NULL,
			`type` varchar(100) NOT NULL,
			PRIMARY KEY (`id`)
				);";
		foreach($table_sql as $table_name => $sql){
			$table_exist_result = $adb->pquery("SHOW TABLES LIKE '$table_name'",array());
			$num_rows = $adb->num_rows($table_exist_result);         
			if($num_rows == 0){
				$adb->pquery($sql,array());
			}
		} 
		$adb->pquery("UPDATE vtiger_tab SET customized = 0 WHERE name = 'VTAtomCommentsMentions'",array());
	}
	function SettingsLink(){
        global $adb;
        $name = "VTAtom Comments Mention License Manager";
        $description = "Configure License Manager";
        $linkto = "index.php?parent=Settings&module=VTAtomCommentsMentions&view=LicenseManagerEdit";
        $result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
        $num_rows = $adb->num_rows($result);
        if($num_rows == 0) {
            $otherSettingsBlock = $adb->pquery('SELECT * FROM vtiger_settings_blocks WHERE label=?', array('LBL_OTHER_SETTINGS'));
            $otherSettingsBlockCount = $adb->num_rows($otherSettingsBlock);

            if ($otherSettingsBlockCount > 0) {
                $blockid = $adb->query_result($otherSettingsBlock, 0, 'blockid');
                $sequenceResult = $adb->pquery("SELECT max(sequence) as sequence FROM vtiger_settings_blocks WHERE blockid=?", array($blockid));
                if ($adb->num_rows($sequenceResult)) {
                    $sequence = $adb->query_result($sequenceResult, 0, 'sequence');
                }
            }
            $fieldid = $adb->getUniqueID('vtiger_settings_field');

            $adb->pquery("INSERT INTO vtiger_settings_field(fieldid, blockid, name, iconpath, description, linkto, sequence, active , pinned) VALUES(?,?,?,?,?,?,?,?,?)", array($fieldid, $blockid, $name, '',$description, $linkto, $sequence++, 0 , 1));

            $adb->pquery("UPDATE vtiger_settings_field_seq SET id = ?",array($fieldid));
        }
	}
    function registerEventHandler(){
        $Vtiger_Utils_Log = true;
        include_once('vtlib/Vtiger/Event.php');
        $class = 'CommentMentionSendMail';
        $result = $adb->pquery("SELECT * FROM vtiger_eventhandlers WHERE handler_class= ?",array($class));
        error_log( "SELECT * FROM vtiger_eventhandlers WHERE handler_class='{$class}'" , 3 , "/tmp/VTAtomCommentsMentions.log" );
        $num_rows = $adb->num_rows($result);
        if($num_rows == 0){
            Vtiger_Event::register('ModComments', 'vtiger.entity.aftersave', $class, 'modules/VTAtomCommentsMentions/CommentMentionSendMail.php');
        }else{
        }
    }
}
?>                                            	

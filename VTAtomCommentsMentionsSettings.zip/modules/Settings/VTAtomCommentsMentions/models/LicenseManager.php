<?php 
class Settings_VTAtomCommentsMentions_LicenseManager_Model extends Vtiger_Base_Model{

    public function getLicenseViewUrl() {
        global $site_URL;
        return $site_URL.'index.php?module=VTAtomCommentsMentions&parent=Settings&view=LicenseManagerEdit';
    }

    public function apiCall($license_key,$action) {
        if($license_key != '' && $action != ''){
            global $site_URL;
            $url = 'https://demo.gamma.atomlines.com/wp/wpstore/wp-json/atomlicense-manageraddon/v1/' .$action. '?license_key=' . urlencode($license_key).'&site_Url='.urlencode($site_URL);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    'Content-Type: application/json',
            ]);
            $response = curl_exec($ch);
            if (curl_errno($ch)) {
                return [
                    'status' => false,
                    'error' => curl_error($ch),
                ];
            }
            curl_close($ch);
            return json_decode($response, true);
        }else{
            return ["License key or Action empty"];
        }
    }
    public function getRecordDetails($id=""){
        global $adb;
        $columns = Array("cmtmention_license_key");
        $return = Array();

        $result = $adb->pquery("SELECT * FROM atom_license_manager",array());
        $num_rows = $adb->num_rows($result);
        if($num_rows > 0){
            for($i=0;$i<$num_rows; $i++){
                $meta_key = $adb->query_result($result,$i,'meta_key');
                $meta_value = $adb->query_result($result,$i,'meta_value');
                $return[$meta_key] =  $meta_value;
            }
        }
        return $return;

    }
    public function ActivateSettings(){
        $this->SettingsLink();
        $this->createCustomTables(); 
        $this->registerEventHandler();
    }
    public function createCustomTables(){
        global $adb;
        $table_sql['atom_vtcommenton_rel'] = "CREATE TABLE `atom_vtcommenton_rel` (
            `id` int NOT NULL AUTO_INCREMENT,
            `is_checked` varchar(100) NOT NULL,
            `type` varchar(100) NOT NULL,
            PRIMARY KEY (`id`)
                );";
        foreach($table_sql as $table_name => $sql){
            $table_exist_result = $adb->pquery("SHOW TABLES LIKE '$table_name'",array());
            $num_rows = $adb->num_rows($table_exist_result);
            if($num_rows == 0){
                $adb->pquery($sql,array());
            }
        }
        $adb->pquery("UPDATE vtiger_tab SET customized = 0 WHERE name = 'VTAtomCommentsMentions'",array());
    }
    public function SettingsLink(){
        global $adb;
        $name = "Atom Comments Mentions";
        $description = "Configure Comments";
        $linkto = "index.php?parent=Settings&module=VTAtomCommentsMentions&view=Edit";
        $result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
        error_log( "SELECT * FROM vtiger_settings_field WHERE name= '{$name}'" , 3 , "/tmp/VTAtomCommentsMentions.log" );
        $num_rows = $adb->num_rows($result);
        if($num_rows == 0) {
            $otherSettingsBlock = $adb->pquery('SELECT * FROM vtiger_settings_blocks WHERE label=?', array('LBL_CONFIGURATION'));
            $otherSettingsBlockCount = $adb->num_rows($otherSettingsBlock);

            if ($otherSettingsBlockCount > 0) {
                $blockid = $adb->query_result($otherSettingsBlock, 0, 'blockid');
                $sequenceResult = $adb->pquery("SELECT max(sequence) as sequence FROM vtiger_settings_blocks WHERE blockid=?", array($blockid));
                if ($adb->num_rows($sequenceResult)) {
                    $sequence = $adb->query_result($sequenceResult, 0, 'sequence');
                }
            }

            $fieldid = $adb->getUniqueID('vtiger_settings_field');
            $adb->pquery("INSERT INTO vtiger_settings_field(fieldid, blockid, name, iconpath, description, linkto, sequence, active , pinned) VALUES(?,?,?,?,?,?,?,?,?)", array($fieldid, $blockid, $name, '',$description, $linkto, $sequence++, 0 , 1));

            $adb->pquery("UPDATE vtiger_settings_field_seq SET id = ?",array($fieldid));
        }else{
        }
    }
    public function registerEventHandler(){
         global $adb;
        $Vtiger_Utils_Log = true;
        include_once('vtlib/Vtiger/Event.php');
        $class = 'CommentMentionSendMail';
        $result = $adb->pquery("SELECT * FROM vtiger_eventhandlers WHERE handler_class= ?",array($class));
        error_log( "SELECT * FROM vtiger_eventhandlers WHERE handler_class='{$class}'" , 3 , "/tmp/VTAtomCommentsMentions.log" );
        $num_rows = $adb->num_rows($result);
        if($num_rows == 0){
            Vtiger_Event::register('ModComments', 'vtiger.entity.aftersave', $class, 'modules/VTAtomCommentsMentions/CommentMentionSendMail.php');
        }else{
        }
    }
    public function DeactivateSettings(){
        $this->removeHeaderJsAndTypes();
        $this->removeSettingsLink(); 
        $this->unregisterEventHandler();
    }
    public function removeHeaderJsAndTypes(){
        global $adb;

        $adb->pquery('UPDATE atom_vtcommenton_rel SET is_checked = ? WHERE type=?',array('off','comment_mentions'));
        $adb->pquery('UPDATE atom_vtcommenton_rel SET is_checked = ? WHERE type=?',array('off','send_commentmail'));

        $linklabel = "VtAtomCommentMentions";
        $linkurl = 'layouts/v7/modules/VTAtomCommentsMentions/resources/'.$linklabel.'.js';
        Vtiger_Link::deleteLink(3,'HEADERSCRIPT',$linklabel,$linkurl);
    }
    public function removeSettingsLink(){
        global $adb;
        $name = "Atom Comments Mentions";
        $description = "Configure Comments";
        $linkto = "index.php?parent=Settings&module=VTAtomCommentsMentions&view=Edit";
        $result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
        $num_rows = $adb->num_rows($result);
        if($num_rows == 1) {
            $adb->pquery("DELETE FROM vtiger_settings_field WHERE name = ?", array($name));
        }
    }
    public function unregisterEventHandler(){
        global $adb;
        $Vtiger_Utils_Log = true;
        include_once('include/events/VTEventsManager.inc');
        $class = 'CommentMentionSendMail';
        $result  = $adb->pquery('SELECT * FROM vtiger_eventhandlers WHERE handler_class =?',array($class));
        if($adb->num_rows($result) > 0){
            $eventsManager = new VTEventsManager($adb);
            $result = $eventsManager->unregisterHandler($class);
            return "success";
        }else{
            return "handler not found";
        }
    }
}

?>


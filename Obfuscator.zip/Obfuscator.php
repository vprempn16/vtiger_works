<?php
ini_set('display_errors','on'); error_reporting(E_ALL); // STRICT DEVELOPMENT
require 'src/Obfuscator.php';

if( isset( $_REQUEST['module'] ) && isset($_REQUEST['orderId']) && isset( $_REQUEST['version'] ) ) {
//	$filename = $_REQUEST['filename'];
	$version = $_REQUEST['version'];
	$module = $_REQUEST['module'];
	$orderId = $_REQUEST['orderId'];
	$domain = 'demo.gamma.atomlines.com';
	require "/var/www/{$domain}/AtomLinesApps/{$module}/configuration.php";

	if (!isset($config[$version])) {
		die("Version {$version} not found in configuration.");
	}

	$filePaths = $config[$version]['filePath'];
	$moduleDir = "/var/www/{$domain}/AtomLinesApps/{$module}/{$module}-{$version}";

	// Create new folder structure
	$obfuscatorDir = "/var/www/{$domain}/AtomLinesApps/obfuscator{$orderId}";
	$newModuleDir = "{$obfuscatorDir}/{$module}-{$version}";
	
	if(!is_dir($obfuscatorDir)) {
       	 	mkdir($obfuscatorDir, 0777, true);
	}
	if(!is_dir($newModuleDir)){
		mkdir($newModuleDir, 0777, true);
	}
	echo"<pre>";print_r([$filePaths,$moduleDir, $obfuscatorDir,$newModuleDir]);die('@');
	
	foreach ($filePaths as $filePath) {
		$fullPath = "/var/www/{$domain}/{$filePath}";

		if (!file_exists($fullPath)) {
			echo "File not found: {$fullPath}\n";
			continue;
		}

		// Read and encrypt file content
		$fileContents = file_get_contents($fullPath);
		$fileContents = str_replace(['<?php', '<?', '?>'], '', $fileContents); // Strip PHP tags
		$obfuscatedData = new Obfuscator($fileContents, 'Class/Code NAME');

		// Determine new file path
		$relativePath = str_replace("AtomLinesApps/{$module}/", '', $filePath);
		$newFilePath = "{$newModuleDir}/{$relativePath}";
		$newFileDir = dirname($newFilePath);

		if (!is_dir($newFileDir)) {
			mkdir($newFileDir, 0777, true);
		}

		// Save obfuscated file
		file_put_contents($newFilePath, '<?php ' . "\r\n" . $obfuscatedData);

		// Remove original file
		unlink($fullPath);
	}

}else{


die('#');
}








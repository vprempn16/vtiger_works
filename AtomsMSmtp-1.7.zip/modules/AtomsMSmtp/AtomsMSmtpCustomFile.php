<?php

class AtomsMSmtpCustom{
	function __construct(){
		error_log( "AtomsMSmtpCustomFile __construct" , 3 , "/tmp/AtomsMSmtp.log" );

	}

	function postInstall(){
	}

	function postEnable(){
		$validator = new Settings_AtomsMSmtp_LicenseManager_Model();

		$licensekey_records = $validator->getRecordDetails();
		$license_key = $licensekey_records['smtp_api_key'];
		$license_key = Vtiger_Functions::fromProtectedText($license_key);
		$is_validate = $validator->apiCall($license_key,'validate');
		$is_active = $validator->apiCall($license_key,'is_active');
		if($is_validate['iskeyvalid'] && $is_active['iskeyactive']){
			$this->SettingsLink();
			$this->addHeaderJs();
		}   
	}

	function postDisable(){
		global $adb;
		$this->removeHeaderJs();
		$this->removeSettingsLink();	
		$this->removeLicenseSettingsLink();
	}

	function postUpdate(){
	
	}
	public function LicenseSettingsLink(){
		global $adb;
		$name = "Atom SMTP License Manager";
		$description = "Configure License Manager";
		$linkto = "index.php?parent=Settings&module=AtomsMSmtp&view=LicenseManagerEdit";
		$result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
		//error_log( "SELECT * FROM vtiger_settings_field WHERE name= '{$name}'" , 3 , "/tmp/AtomsMSmtp.log" );
		$num_rows = $adb->num_rows($result);
		if($num_rows == 0) {
			$otherSettingsBlock = $adb->pquery('SELECT * FROM vtiger_settings_blocks WHERE label=?', array('LBL_OTHER_SETTINGS'));
			$otherSettingsBlockCount = $adb->num_rows($otherSettingsBlock);

			if ($otherSettingsBlockCount > 0) {
				$blockid = $adb->query_result($otherSettingsBlock, 0, 'blockid');
				$sequenceResult = $adb->pquery("SELECT max(sequence) as sequence FROM vtiger_settings_blocks WHERE blockid=?", array($blockid));
				if ($adb->num_rows($sequenceResult)) {
					$sequence = $adb->query_result($sequenceResult, 0, 'sequence');
				}
			}

			$fieldid = $adb->getUniqueID('vtiger_settings_field');

			$adb->pquery("INSERT INTO vtiger_settings_field(fieldid, blockid, name, iconpath, description, linkto, sequence, active , pinned) VALUES(?,?,?,?,?,?,?,?,?)", array($fieldid, $blockid, $name, '',$description, $linkto, $sequence++, 0 , 1));

			$adb->pquery("UPDATE vtiger_settings_field_seq SET id = ?",array($fieldid));
			//echo("$name Settings Added <br/>");
		}else{
			//echo("$name Already present <br/>");
		}
	}
	public function SettingsLink(){
		global $adb;
		$name = "Atom Multiple SMTP";
		$description = "Configure Multiple SMTP";
		$linkto = "index.php?parent=Settings&module=AtomsMSmtp&view=List";
		$result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
		$num_rows = $adb->num_rows($result);
		if($num_rows == 0) {
			$otherSettingsBlock = $adb->pquery('SELECT * FROM vtiger_settings_blocks WHERE label=?', array('LBL_CONFIGURATION'));
			$otherSettingsBlockCount = $adb->num_rows($otherSettingsBlock);

			if ($otherSettingsBlockCount > 0) {
				$blockid = $adb->query_result($otherSettingsBlock, 0, 'blockid');
				$sequenceResult = $adb->pquery("SELECT max(sequence) as sequence FROM vtiger_settings_blocks WHERE blockid=?", array($blockid));
				if ($adb->num_rows($sequenceResult)) {
					$sequence = $adb->query_result($sequenceResult, 0, 'sequence');
				}
			}

			$fieldid = $adb->getUniqueID('vtiger_settings_field');

			$adb->pquery("INSERT INTO vtiger_settings_field(fieldid, blockid, name, iconpath, description, linkto, sequence, active , pinned) VALUES(?,?,?,?,?,?,?,?,?)", array($fieldid, $blockid, $name, '',$description, $linkto, $sequence++, 0 , 1));

			$adb->pquery("UPDATE vtiger_settings_field_seq SET id = ?",array($fieldid));
		}
	}
	public function removeSettingsLink(){
                global $adb;
		$name = "Atom Multiple SMTP";
       	 	$description = "Configure Multiple SMTP";
        	$linkto = "index.php?parent=Settings&module=AtomsMSmtp&view=List";
                $result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
                $num_rows = $adb->num_rows($result);
                if($num_rows == 1) {
                        $adb->pquery("DELETE FROM vtiger_settings_field WHERE name = ?", array($name));
                }
        }
	public function removeLicenseSettingsLink(){
		global $adb;
		$name = "Atom SMTP License Manager";
		$description = "Configure License Manager";
		$linkto = "index.php?parent=Settings&module=AtomsMSmtp&view=LicenseManagerEdit";
		$result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
		$num_rows = $adb->num_rows($result);
		if($num_rows == 1) {
			$adb->pquery("DELETE FROM vtiger_settings_field WHERE name = ?", array($name));
		}
	}
	public function addHeaderJs(){
		global $adb;
		$moduleName='Home';
		$moduleInstance = Vtiger_Module::getInstance($moduleName);
		$moduleInstance->addLink('HEADERSCRIPT' , "AtomsMSmtp" ,  "layouts/v7/modules/AtomsMSmtp/resources/AtomsMSmtp.js" );

	}
	public function removeHeaderJs(){
		global $adb;
		$moduleName='Home';
		$moduleInstance = Vtiger_Module::getInstance($moduleName);
		$moduleInstance->deleteLink('HEADERSCRIPT' , "AtomsMSmtp" ,  "layouts/v7/modules/AtomsMSmtp/resources/AtomsMSmtp.js" );

		$name = "AtomsMSmtp";
                $linkto = "layouts/v7/modules/AtomsMSmtp/resources/AtomsMSmtp.js";
                $result = $adb->pquery("SELECT * FROM vtiger_links WHERE linklabel= ?",array($name));
                $num_rows = $adb->num_rows($result);
		if($num_rows == 1) {
			$adb->pquery("DELETE FROM vtiger_links WHERE linktype='HEADERSCRIPT' AND linklabel=? AND linkurl=?",array($name,$linkto));
		}
	}
}

?>

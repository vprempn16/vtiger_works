/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is: vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
jQuery.Class("Atoms_SettingsList_MSmtp",{},{
	registerDelete : function(){
		jQuery(document).on('click','.atm_row_del',function(e){
			e.preventDefault();
			var serverid = jQuery(this).attr("data-ser-id");	
			console.log(serverid);
			var aDeferred = jQuery.Deferred();
                        var params = {
                        'module' : app.getModuleName(),
                        'parent' : app.getParentModuleName(),
			'serverid':serverid,
                        'action': 'serverDeleteAjax'
                        };

			app.helper.showProgress();
                        app.request.post({'data' : params}).then(
                                        function(err, data) {
						app.helper.hideProgress();
                                                if(err === null){
							jQuery(document).find(".row-"+serverid).remove();
                                                }else {
                                                        jQuery('.errorMessage', form).removeClass('hide');
                                                        aDeferred.reject();
                                                        console.log(data);
                                                }
                                        }
                                        );
                        return aDeferred.promise();
			
		});
	},

	registerEvents: function(){
		var thisInstance = this;
		thisInstance.registerDelete();

	}
});

$(document).ready(function(){
		var instance = new Atoms_SettingsList_MSmtp();
		instance.registerEvents();
});

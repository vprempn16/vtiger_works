<?php

class Settings_AtomsMSmtp_Edit_View extends Settings_Vtiger_Index_View {

    public function preProcess(Vtiger_Request $request , $display=true){
         $recordModel = new Settings_AtomsMSmtp_Record_Model();
        $validator = new Settings_AtomsMSmtp_LicenseManager_Model();

        $licensekey_records = $validator->getRecordDetails();
        $license_key = $licensekey_records['smtp_api_key'];
        $license_key = Vtiger_Functions::fromProtectedText($license_key);
        $maskedKey = substr($license_key, 0, 4) . str_repeat('*', strlen($license_key) - 8) . substr($license_key, -4);
        $is_validate = $validator->apiCall($license_key,'validate');
        $is_active = $validator->apiCall($license_key,'is_active');
        $licenseview_url = $recordModel->getLicenseViewUrl();
        if(!$is_validate['iskeyvalid']){
            header("Location:".$licenseview_url);
            exit();
        }
        if(!$is_active['iskeyactive']){
            header("Location:".$licenseview_url."&keyactive=false");
            exit();
        }
        parent::preProcess($request, false);
        $this->preProcessSettings($request,$display);
    
    }
	public function process(Vtiger_Request $request) {
		//ini_set('display_errors','off');
		$viewer = $this->getViewer($request);
		$qualifiedName = $request->getModule(false);
		$recordId = $request->get('recordId');
		$recordModel = new Settings_AtomsMSmtp_Record_Model();
		if( $recordId == "" ) {
			$record = $recordModel->getRecordDetails();	
		}
		else{
			$record = $recordModel->getRecordDetails($recordId);
		}
		$listview_URL = $recordModel->getListViewUrl(); 
		$record['sharedusers'] = Zend_Json::decode( decode_html( $record['sharedusers'] ) );
		if($record['sharedusers'] == ''){
			$record['sharedusers'] = Array();
		}

		$viewer->assign('RECORD',$record);
		$viewer->assign('recordId' , $recordId );
		$viewer->assign('QUALIFIED_MODULE', $qualifiedName);
		$viewer->assign('CURRENT_USER_MODEL', Users_Record_Model::getCurrentUserModel());
		$USERSLIST = Users_Record_Model::getAll();
		$viewer->assign("USERSLIST" , $USERSLIST );
		$viewer->assign('LSITVIEWURL',$listview_URL);
		$viewer->view('Edit.tpl',$qualifiedName);
	}

        function getPageTitle(Vtiger_Request $request) {
                $qualifiedModuleName = $request->getModule(false);
                return vtranslate('Edit Server',$qualifiedModuleName);
        }

        /**
         * Function to get the list of Script models to be included
         * @param Vtiger_Request $request
         * @return <Array> - List of Vtiger_JsScript_Model instances
         */
        function getHeaderScripts(Vtiger_Request $request) {
                $headerScriptInstances = parent::getHeaderScripts($request);
                $moduleName = $request->getModule();

                $jsFileNames = array(
                        "modules.Settings.$moduleName.resources.SettingsEdit"
                );

                $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
                $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
                return $headerScriptInstances;
        }
}

?>

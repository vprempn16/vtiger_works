<?php
class Settings_AtomsMSmtp_List_View extends Settings_Vtiger_Index_View {
    public function preProcess(Vtiger_Request $request, $display=true){
	     $recordModel = new Settings_AtomsMSmtp_Record_Model();
        $validator = new Settings_AtomsMSmtp_LicenseManager_Model();

        $licensekey_records = $validator->getRecordDetails();
        $license_key = $licensekey_records['smtp_api_key'];
        $license_key = Vtiger_Functions::fromProtectedText($license_key);
        
        $is_validate = $validator->apiCall($license_key,'validate');
        $is_active = $validator->apiCall($license_key,'is_active');
        $licenseview_url = $recordModel->getLicenseViewUrl();
        if(!$is_validate['iskeyvalid']){
            header("Location:".$licenseview_url);
            exit();
        } 
        if(!$is_active['iskeyactive']){
            header("Location:".$licenseview_url."&keyactive=false");
            exit();
        }

        parent::preProcess($request, false);
        $this->preProcessSettings($request,$display);
    }

	public function process(Vtiger_Request $request) {
		$moduleName = $request->getModule();
		$qualifiedModuleName = $request->getModule(false);
		$recordModel = new Settings_AtomsMSmtp_Record_Model();
		

        $records = $recordModel->getListViewRecords();
        $record_count = count($records);
		$listview_headers = $recordModel->getListViewHeaders();
		$editViewUrl = $recordModel->getEditViewUrl();
		$viewer = $this->getViewer($request);
		$viewer->assign("LISTVIEW_HEADERS",$listview_headers);
		$viewer->assign("LISTVIEW_ENTRIES_COUNT",$record_count);
		$viewer->assign("ADD_URL",$editViewUrl);
		$viewer->assign("RECORDS",$records);
		$viewer->view("ListViewContents.tpl", $qualifiedModuleName);
	}

    /**
         * Function to get the list of Script models to be included
         * @param Vtiger_Request $request
         * @return <Array> - List of Vtiger_JsScript_Model instances
         */
        function getHeaderScripts(Vtiger_Request $request) {
                $headerScriptInstances = parent::getHeaderScripts($request);
                $moduleName = $request->getModule();

                $jsFileNames = array(
                        "modules.Settings.$moduleName.resources.SettingsList"
                );

                $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
                $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
                return $headerScriptInstances;
        }
}



?>

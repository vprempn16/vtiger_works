<?php
class AtomMSmtpWorkFlow {

	function vtlib_handler($moduleName, $eventType) {
		global $adb;
		if($eventType == 'module.postinstall') {
			//$this->createCustomWorkflow();
			//$this->insertAtomMSmtpHeaderLink();
			$this->SettingsLink();
			$this->moveVTMSmtpTask();
		} else if($eventType == 'module.enabled') {
			//$this->createCustomWorkflow();
			//$this->insertAtomMSmtpHeaderLink();
			$this->SettingsLink();	
		} else if($eventType == 'module.disabled') {
		} else if($eventType == 'module.preuninstall') {
			// TODO Handle actions when this module is about to be deleted.
		} else if($eventType == 'module.preupdate') {
			// TODO Handle actions before this module is updated.
		} else if($eventType == 'module.postupdate') {
			//$this->createCustomWorkflow();
			//$this->insertAtomMSmtpHeaderLink();
			$this->moveVTMSmtpTask();
			$this->SettingsLink();
		}
	}

	function createCustomWorkflow(){
		global $adb;
		include_once( 'modules/com_vtiger_workflow/VTTaskManager.inc' );
		$taskType = "VTMSmtpTask";
		$result = $adb->pquery("SELECT * FROM com_vtiger_workflow_tasktypes where tasktypename=?",array($taskType));
		if( $adb->num_rows($result) == 0 ) {
			$taskType = array("name"=>$taskType, "label"=>"Send Mail Multiple SMTP", "classname"=>$taskType, "classpath"=>"modules/AtomMSmtpWorkFlow/tasks/$taskType.php", "templatepath"=>"modules/AtomMSmtpWorkFlow/Tasks/$taskType.tpl", "modules"=>$defaultModules, "sourcemodule"=>'AtomMSmtpWorkFlow');
			VTTaskType::registerTaskType($taskType);
		}
	}
	function insertAtomMSmtpHeaderLink(){
                global $adb;
                $linklabel = "AtomMSmtpHeader";
                $linkurl = "layouts/v7/modules/AtomMSmtpWorkFlow/resources/AtomMSmtpHeader.js";
                $result = $adb->pquery("SELECT * FROM vtiger_links WHERE linklabel = ? AND linkurl = ? ",array($linklabel,$linkurl));
                $num_rows = $adb->num_rows($result);
		if($num_rows == 0){
			$sql = $adb->pquery('Select MAX(linkid) as id from vtiger_links',array());
			$linkid = $adb->query_result($sql,'0','id');
			$linkid++;
			$adb->pquery("INSERT INTO `vtiger_links`( `linkid`,`tabid`, `linktype`, `linklabel`, `linkurl`, `linkicon`, `sequence`, `handler_path`, `handler_class`, `handler`, `parent_link`) VALUES (?,?,?,?,?,?,?,?,?,?,?)",array($linkid,'3','HEADERSCRIPT',$linklabel,$linkurl,'','0','','','',NULL));
		}
        }
	function SettingsLink(){
		global $adb;
		$name = "Atom MSmtp Workflow License Manager";
		$description = "Configure License Manager";
		$linkto = "index.php?parent=Settings&module=AtomMSmtpWorkFlow&view=LicenseManagerEdit";
		$result = $adb->pquery("SELECT * FROM vtiger_settings_field WHERE name= ?",array($name));
		$num_rows = $adb->num_rows($result);
		if($num_rows == 0) {
			$otherSettingsBlock = $adb->pquery('SELECT * FROM vtiger_settings_blocks WHERE label=?', array('LBL_CONFIGURATION'));
			$otherSettingsBlockCount = $adb->num_rows($otherSettingsBlock);

			if ($otherSettingsBlockCount > 0) {
				$blockid = $adb->query_result($otherSettingsBlock, 0, 'blockid');
				$sequenceResult = $adb->pquery("SELECT max(sequence) as sequence FROM vtiger_settings_blocks WHERE blockid=?", array($blockid));
				if ($adb->num_rows($sequenceResult)) {
					$sequence = $adb->query_result($sequenceResult, 0, 'sequence');
				}
			}

			$fieldid = $adb->getUniqueID('vtiger_settings_field');

			$adb->pquery("INSERT INTO vtiger_settings_field(fieldid, blockid, name, iconpath, description, linkto, sequence, active , pinned) VALUES(?,?,?,?,?,?,?,?,?)", array($fieldid, $blockid, $name, '',$description, $linkto, $sequence++, 0 , 1));

			$adb->pquery("UPDATE vtiger_settings_field_seq SET id = ?",array($fieldid));
		}
	}
	function moveVTMSmtpTask(){
		$source = 'modules/AtomMSmtpWorkFlow/VTMSmtpTask.inc';
		$destination ='modules/com_vtiger_workflow/tasks/';
		if (!file_exists($source)) {
			//echo("Source file does not exist.<br/>");
		}
		$command = escapeshellcmd("mv $source $destination");
		exec($command, $output, $return_var);
		if ($return_var === 0) {
			return true;
		} else {
			//echo("Failed to move file.<br/>");
		}
	}
}

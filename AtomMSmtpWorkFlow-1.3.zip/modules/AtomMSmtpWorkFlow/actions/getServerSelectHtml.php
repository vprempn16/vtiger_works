<?php

class AtomMSmtpWorkFlow_getServerSelectHtml_Action extends Vtiger_Action_Controller {
    
	public function checkPermission(){
		return true;
	}
    public function process(Vtiger_Request $request) {

        global $adb , $current_user ;
        $return = '';
        $response = new Vtiger_Response();
        $current_user_id = $current_user->id;
        $taskType = $request->get('taskType');
        $recordId = $request->get('task_id');
        $worflowModuleName = $request->get('module_name');
        
        $success = true; 
        if($recordId) {
            $workflowId = $request->get('for_workflow');
            $workflowModel = Settings_Workflows_Record_Model::getInstance($workflowId);
            $worflowModuleName = $workflowModel->get('module_name');
            //$taskTypes = $workflowModel->getTaskTypes();
            $taskModel = Settings_Workflows_TaskRecord_Model::getInstance($recordId);
        } else {
            /*
               $taskType = $request->get('type');
               if(empty($taskType)) {
               $taskType = !empty($taskTypes[0]) ? $taskTypes[0]->getName() : 'VTEmailTask';
               }
             */
            $workflowModel = Settings_Workflows_Record_Model::getCleanInstance($worflowModuleName);
            $taskType = "VTMSmtpTask";
            $taskModel = Settings_Workflows_TaskRecord_Model::getCleanInstance($workflowModel, $taskType);
        }
        $taskObject = $taskModel->getTaskObject();
        $MailServerHtml = $this->getGetMailServerHtml($taskObject);
        $EmailTemplates = $this->getMailTemplatesHtml($worflowModuleName);
        
        $validator = new Settings_AtomMSmtpWorkFlow_LicenseManager_Model();

        $licensekey_records = $validator->getRecordDetails();
        $license_key = $licensekey_records['msmtpworkflow_license_key'];
        $license_key = Vtiger_Functions::fromProtectedText($license_key);
        $maskedKey = substr($license_key, 0, 4) . str_repeat('*', strlen($license_key) - 8) . substr($license_key, -4);
        $is_validate = $validator->apiCall($license_key,'validate');
        $is_active = $validator->apiCall($license_key,'is_active');
        if(!$is_validate['iskeyvalid']){
            $success = false;
            $MailServerHtml = $EmailTemplates = '';
        }
        if(!$is_active['iskeyactive']){
            $success = false;
            $MailServerHtml = $EmailTemplates = '';
        }

        $return = array('success'=>$success,'mailServerHtml'=> $MailServerHtml,'emailTemp'=>$EmailTemplates);
        $response->setResult($return);
        $response->emit();
    }
	function getMailTemplatesHtml($worflowModuleName){
		$return = '';
		$emailTemplates = EmailTemplates_Record_Model::getAllForEmailTask($worflowModuleName);
		if(!empty($emailTemplates)) {
			//	$viewer->assign('EMAIL_TEMPLATES',$emailTemplates);
			$html  = '<div class="row form-group"><div class="col-sm-6 col-xs-6"><div class="row"><div class="col-sm-3 col-xs-3"><span>Email Templates</span></div><div class="col-sm-8 col-xs-8">';
			$html .= '<select data-rule-required ="true" style="min-width: 250px" style="min-width: 250px" id="task-emailtemplates" class="select2" data-placeholder="Select an Option"> ';
			$html .= '<option>Select an option </option>';
			foreach($emailTemplates as $emailtemplate){
				$html .= '<option value="'.$emailtemplate->get('body').'">'.$emailtemplate->get('templatename').'</option>';
			}
			$html .= '</select>';
			$html .= '</div></div></div><div class="col-sm-5 col-xs-5"></div></div>';
			$return = $html;
		}	
		return $return;

	}
	function getGetMailServerHtml($taskObject){
		global $adb, $current_user;
		$return = '';
		$result = $adb->pquery("SELECT * FROM vtiger_atoms_msmtp WHERE config_type = ?",array('public'));		
		$num_rows = $adb->num_rows($result);
		$systemresult = $adb->pquery( "SELECT * FROM vtiger_systems where server_type = ? limit 1" , array( "email" ) );
		$systemnumrows = $adb->num_rows( $systemresult );
		$serverMSId = $taskObject->serverMSId;
		$isSelected = '';
		if($num_rows > 0){
			$html  = '<div class="row form-group"><div class="col-sm-6 col-xs-6"><div class="row"><div class="col-sm-3 col-xs-3"><span>Select Mail Server<span class="redColor">*</span></span></div><div class="col-sm-8 col-xs-8">';
			$html .= '<select data-rule-required ="true" style="min-width: 250px" name="serverMSId" id="serverMSId">';
			$html .= '<option value="">Select an option</value>';
			if( $systemnumrows > 0 ) {
				if($serverMSId == 'default'){
					$isSelected = 'selected';
				}
				$server_username = $adb->query_result($systemresult,0,'server_username');
				$html .= '<option value="default" '.$isSelected.'>'.vtranslate( "Default" , "Vtiger" )." (".$server_username. ")".'</value>';		
			}
			 $isSelected = '';
			for($i=0;$i<$num_rows;$i++){
				$server_username = $adb->query_result($result,$i,'server_username');
				$server_name = $adb->query_result( $result , $i , "name" );
				$server_id = $adb->query_result($result,$i,'id');
				$sharedusers = Zend_Json::decode( decode_html ( $adb->query_result( $result , $i , "sharedusers" ) ) );
				if(!empty($sharedusers)){
					if($server_id ==  $serverMSId){
						$isSelected = 'selected'; 
					}else{
						$isSelected = '';
					}
					$html .= '<option '.$isSelected.' value="'.$server_id.'" >'.$server_name." (".$server_username. ")".'</value>';
				}
			}
			$html .= '</select>';
			$html .= '</div></div></div><div class="col-sm-5 col-xs-5"></div></div>';
			$return = $html;		
		}
		return $return;	
	}
}
?>

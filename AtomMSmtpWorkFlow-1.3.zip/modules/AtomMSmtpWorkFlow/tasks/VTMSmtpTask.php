<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

require_once('modules/com_vtiger_workflow/VTEntityCache.inc');
require_once('modules/com_vtiger_workflow/VTWorkflowUtils.php');
require_once('modules/com_vtiger_workflow/VTEmailRecipientsTemplate.inc');
require_once('modules/Emails/mail.php');
require_once('include/simplehtmldom/simple_html_dom.php');
require_once('modules/Emails/models/Mailer.php');

class VTMSmtpTask extends VTTask {
	public $executeImmediately = false;

	public function getFieldNames(){
		return	array("subject", "content", "recepient", 'emailcc', 'emailbcc', 'fromEmail', 'pdf', 'pdfTemplateId',
			'signature','replyTo','serverMSId');
	}

	public function doTask($entity){
		global $current_user;
		$util = new VTWorkflowUtils();
		$currentUserModel = Users_Record_Model::getCurrentUserModel();
		$admin = $util->adminUser();
		$module = $entity->getModuleName();
		$taskContents = Zend_Json::decode($this->getContents($entity));
		$relatedInfo = Zend_Json::decode($this->getRelatedInfo());
		$from_email     = $taskContents['fromEmail'];
		$from_name      = $taskContents['fromName'];
		//              $to_email       = $taskContents['toEmail'];
		$cc                     = $taskContents['ccEmail'];
		$bcc            = $taskContents['bccEmail'];
		$replyTo        = $taskContents['replyTo'];
		$subject        = $taskContents['subject'];
		$content        = $taskContents['content'];
		$isPdfTemplateEnabled = $this->pdf;
		$pdfTemplateId = $this->pdfTemplateId;

		if (!$entityCache) {
			$entityCache = new VTEntityCache($admin);
		}

		//
		$et = new VTEmailRecipientsTemplate($this->recepient);
		$to_email = $et->render($entityCache, $entity->getId());

		if(!empty($to_email)) {
			//Storing the details of emails
			$entityIdDetails = vtws_getIdComponents($entity->getId());
			$entityId = $entityIdDetails[1];
			$moduleName = 'Emails';
			$userId = $current_user->id;
			$processedContent = Emails_Mailer_Model::getProcessedContent($content); // To remove script tags
			$mailerInstance = Emails_Mailer_Model::getInstance();
			$mailerInstance->isHTML(true);
			$processedContentWithURLS = $mailerInstance->convertToValidURL($processedContent);
			$recordId = '';
			if(!empty($recordId)) {
				$recordModel = Vtiger_Record_Model::getInstanceById($recordId,$moduleName);
				$recordModel->set('mode', 'edit');
			}else{
				$recordModel = Vtiger_Record_Model::getCleanInstance($moduleName);
				$recordModel->set('mode', '');
			}

			//set properties
			$toEmail = trim($to_email,',');
			$toMailInfo =  array( $entityId => array(  $toEmail) ) ;
			$toMailNamesList =  json_encode( [ $entityId => [ ['label' => $toEmail,'value' => $toEmail] ]]);
			$flag = 'SENT';
			//Retrieve MessageID from Mailroom table only if module is not users
			$recordModel->set('description', $processedContentWithURLS);
			$recordModel->set('subject', $subject);
			$recordModel->set('toMailNamesList',$toMailNamesList);
			$recordModel->set('saved_toid', $toEmail);
			$recordModel->set('ccmail', $cc);
			$recordModel->set('bccmail',$bcc);
			$recordModel->set('assigned_user_id', $currentUserModel->getId());
			$recordModel->set('email_flag', $flag);
			$recordModel->set('documentids', $documentIds);
			$recordModel->set('signature',$signature);

			$recordModel->set('toemailinfo', json_encode($toMailInfo));
			foreach($toMailInfo as $recordId=>$emailValueList) {
				if($recordModel->getEntityType($recordId) == 'Users'){
					$parentIds .= $recordId.'@-1|';
				}else{
					$parentIds .= $recordId.'@1|';
				}
			}
			$recordModel->set('parent_id', $parentIds);
			if ($recordModel->checkUploadSize($documentIds)) {
				// Fix content format acceptable to be preserved in table.
				$decodedHtmlDescriptionToSend = $recordModel->get('description');
				$recordModel->set('description', to_html($decodedHtmlDescriptionToSend));
				$recordModel->save();

				// Restore content to be dispatched through HTML mailer.
				$recordModel->set('description', $decodedHtmlDescriptionToSend);

				// To add entry in ModTracker for email relation
				$emailRecordId = $recordModel->getId();
				foreach ($toMailInfo as $recordId => $emailValueList) {
					$relatedModule = $recordModel->getEntityType($recordId);
					if (!empty($relatedModule) && $relatedModule != 'Users') {
						$relatedModuleModel = Vtiger_Module_Model::getInstance($relatedModule);
						$relationModel = Vtiger_Relation_Model::getInstance($relatedModuleModel, $recordModel->getModule());
						if ($relationModel) {
							$relationModel->addRelation($recordId, $emailRecordId);
						}
					}
				}
			}
			$success = true;
			if($flag == 'SENT') {
				$AtomsrecordModel = Vtiger_Record_Model::getCleanInstance('AtomsMSmtp');
				$AtomsrecordModel->set('replyTo',$taskContents['replyTo']);
				$AtomsrecordModel->set('fromName',$taskContents['fromName']);
				$AtomsrecordModel->setId($this->serverMSId);
				$status = $AtomsrecordModel->send($recordModel);

				if ($status === true) {
					// This is needed to set vtiger_email_track table as it is used in email reporting
					$recordModel->setAccessCountValue();
				} else {
					$success = false;
					$message = $status;
				}
			}
		}
	}

	public function getContents($entity, $entityCache=false) {
		if (!$this->contents) {
			global $adb, $current_user;
			$taskContents = array();
			$entityId = $entity->getId();

			$utils = new VTWorkflowUtils();
			$adminUser = $utils->adminUser();
			if (!$entityCache) {
				$entityCache = new VTEntityCache($adminUser);
			}

			$fromUserId = Users::getActiveAdminId();
			$entityOwnerId = $entity->get('assigned_user_id');
			if ($entityOwnerId) {
				list ($moduleId, $fromUserId) = explode('x', $entityOwnerId);
			}

			$ownerEntity = $entityCache->forId($entityOwnerId);
			if($ownerEntity->getModuleName() === 'Groups') {
				list($moduleId, $recordId) = vtws_getIdComponents($entityId);
				$fromUserId = Vtiger_Util_Helper::getCreator($recordId);
			}
			$userObj = CRMEntity::getInstance('Users');
			$userObj->retrieveCurrentUserInfoFromFile($fromUserId);
			if ($this->fromEmail && !($ownerEntity->getModuleName() === 'Groups' && strpos($this->fromEmail, 'assigned_user_id : (Users) ') !== false)) {
				/**From email merge tag have combination of name<email> format, So VTSimpleTemplate only
				 * merge the name not email part because of anchor pair. So we need to explode them and then
				 * assign them to VTSimpleTemplate to merge properly
				 **/
				if(strpos($this->fromEmail, '&lt;') && strpos($this->fromEmail, '&gt;')) {
					list($fromNameTag, $fromEmailTag) = explode('&lt;', $this->fromEmail);
					list($fromEmailTag, $rest) = explode('&gt;', $fromEmailTag);
				}elseif (strpos($this->fromEmail, '<') && strpos($this->fromEmail, '>')) {
					list($fromNameTag, $fromEmailTag) = explode('<', $this->fromEmail);
					list($fromEmailTag, $rest) = explode('>', $fromEmailTag);
				} else {
					/**In this case user entered only email or name and email without anchor tags or mergetag without anchor tags etc..
					 * So we need to check if user given only email and if it is valid, then we will set it as valid email string and
					 * from name as current user name else we will treat it as from name and set from email as active admin's primary email
					 */
					if(filter_var($this->fromEmail,FILTER_VALIDATE_EMAIL)) {
						$fromEmailTag = $this->fromEmail;
						$fromNameTag = $this->fromEmail;
					}else{
						$fromNameTag = $this->fromEmail;
						if($userObj) {
							$fromEmailTag = $userObj->email1;
						}else{
							$fromEmailTag = $this->getDefaultFromEmail($this->fromEmail);
						}
					}
				}
				$et = new VTEmailRecipientsTemplate($fromEmailTag);
				$fromEmail = $et->render($entityCache, $entityId);

				$nt = new VTEmailRecipientsTemplate($fromNameTag);
				$fromName = $nt->render($entityCache, $entityId);
			} else {
				if ($userObj) {
					$fromEmail = $userObj->email1;
					$fromName =     $userObj->userlabel;
				} else {
					$fromEmail = $this->getDefaultFromEmail();
					$userObj = Users::getActiveAdminUser();
					$fromName =     $userObj->userlabel;
				}
			}
			if (!$fromEmail) {
				$utils->revertUser();
				return false;
			}

			$taskContents['fromEmail'] = $fromEmail;
			$taskContents['fromName'] =     $fromName;
			$defReplyTo = $this->getDefaultReplyToEmail();
			if ($this->replyTo && !($ownerEntity->getModuleName() === 'Groups' && strpos($this->replyTo, 'assigned_user_id : (Users) ') !== false)) {
				$et = new VTEmailRecipientsTemplate($this->replyTo);
				$replyToEmailDetails = $et->render($entityCache, $entityId);
				$replyToEmailDetails = trim($replyToEmailDetails,',');
				//ReplyTo might be empty when record's email value is not set
				if(filter_var($replyToEmailDetails,FILTER_VALIDATE_EMAIL)) {
					$replyToEmail = $replyToEmailDetails;
				}else{
					$replyToEmail = $defReplyTo;
				}
			} else {
				$replyToEmail = $defReplyTo;
			}
			$taskContents['replyTo'] = $replyToEmail;

			if ($entity->getModuleName() === 'Events') {
				$contactId = $entity->get('contact_id');
				if ($contactId) {
					$contactIds = '';
					list($wsId, $recordId) = explode('x', $entityId);
					$webserviceObject = VtigerWebserviceObject::fromName($adb, 'Contacts');

					$result = $adb->pquery('SELECT contactid FROM vtiger_cntactivityrel WHERE activityid = ?', array($recordId));
					$numOfRows = $adb->num_rows($result);
					for($i=0; $i<$numOfRows; $i++) {
						$contactIds .= vtws_getId($webserviceObject->getEntityId(), $adb->query_result($result, $i, 'contactid')).',';
					}
				}
				$entity->set('contact_id', trim($contactIds, ','));
				$entityCache->cache[$entityId] = $entity;
			}

			$et = new VTEmailRecipientsTemplate($this->recepient);
			$toEmail = $et->render($entityCache, $entityId);

			$ecct = new VTEmailRecipientsTemplate($this->emailcc);
			$ccEmail = $ecct->render($entityCache, $entityId);
			$ebcct = new VTEmailRecipientsTemplate($this->emailbcc);
			$bccEmail = $ebcct->render($entityCache, $entityId);

			if(strlen(trim($toEmail, " \t\n,")) == 0 && strlen(trim($ccEmail, " \t\n,")) == 0 && strlen(trim($bccEmail, " \t\n,")) == 0) {
				$utils->revertUser();
				return false;
			}

			$taskContents['toEmail'] = $toEmail;
			$taskContents['ccEmail'] = $ccEmail;
			$taskContents['bccEmail'] = $bccEmail;

			$this->parseEmailTemplate($entity);
			//line item merge tags also should replace with proper values for subject
			$st = new VTSimpleTemplate($this->subject);
			$taskContents['subject'] = $st->render($entityCache, $entityId);

			$ct = new VTSimpleTemplate($this->content);
			$taskContents['content'] = $ct->render($entityCache, $entityId);
			//adding signatue to body
			// To handle existing workflows those having signature value as empty so assigning value
			// "Yes" for those workflows.
			if(empty($this->signature)){
				$this->signature = 'Yes';
			}
			$content = $taskContents['content'];
			if($this->signature == 'Yes') {
				$userObj = CRMEntity::getInstance('Users');
				$userObj->retrieveCurrentUserInfoFromFile($fromUserId);
				$content .= '<br><br>'.  decode_html($userObj->signature);
			}
			$taskContents['content'] = $content;
			$this->contents = $taskContents;
			$utils->revertUser();
		}
		if(is_array($this->contents)) {
			$this->contents = Zend_Json::encode($this->contents);
		}
		return $this->contents;
	}

	public function parseEmailTemplate($entity) {
		$moduleName = $entity->getModuleName();
		list($wsId, $recordId) = explode('x', $entity->getId());
		$mergedHtml = getMergedDescription($this->content, $recordId, $moduleName);
		$this->content = $mergedHtml;
	}

	function getFromEmailAddress() {
		$db = PearDatabase::getInstance();

		$currentUserModel = Users_Record_Model::getCurrentUserModel();
		$currentuserid = $currentUserModel->id;

		$serverMSId =  $this->serverMSId; // $this->getId();

		$fromEmail = false;
		if($serverMSId != '' && $serverMSId != "default" ){
			$result = $db->pquery('SELECT from_email_field FROM vtiger_atoms_msmtp WHERE id = ?',array($serverMSId));
			if( $db->num_rows( $result ) == 0 ) {
				$result = $db->pquery('SELECT from_email_field FROM vtiger_systems WHERE server_type=?', array('email'));
			}
		}else{
			$result = $db->pquery('SELECT from_email_field FROM vtiger_systems WHERE server_type=?', array('email'));
		}
		if ($db->num_rows($result)) {
			$fromEmail = decode_html($db->query_result($result, 0, 'from_email_field'));
		}
		if (empty($fromEmail)) $fromEmail = $currentUserModel->get('email1');
		return $fromEmail;
	}

	function getReplyToEmail() {
		$db = PearDatabase::getInstance();
		$defaultReplyTo = vglobal('default_reply_to');
		$currentUserModel = Users_Record_Model::getCurrentUserModel();
		$currentuserid = $currentUserModel->id;
		$replyTo = $currentUserModel->get('email1');

		$serverMSId = $this->serverMSId; //$this->getId();

		if ($defaultReplyTo == 'outgoing_server_from_email') {
			if($serverMSId != '' && $serverMSId != "default" ){
				$result = $db->pquery('SELECT from_email_field FROM vtiger_atoms_msmtp WHERE id = ?',array($serverMSId));
				if( $db->num_rows( $result ) == 0 ) {
					$result = $db->pquery('SELECT from_email_field FROM vtiger_systems WHERE server_type=?', array('email'));
				}
			}else{
				$result = $db->pquery('SELECT from_email_field FROM vtiger_systems WHERE server_type=?', array('email'));
			}
			if ($db->num_rows($result)) {
				$fromEmail = decode_html($db->query_result($result, 0, 'from_email_field'));
			}
			if (!empty($fromEmail)) {
				$replyTo = $fromEmail;
			}
		} else if ($defaultReplyTo == 'hepldesk_support_email') {
			$helpDeskEmail = vglobal('HELPDESK_SUPPORT_EMAIL_ID');
			if (!empty($helpDeskEmail)) {
				$replyTo = $helpDeskEmail;
			}
		}
		return $replyTo;
	}

	function getDefaultReplyToEmail() {
		global $HELPDESK_SUPPORT_EMAIL_REPLY_ID;
		$defaultReplyToEmail = null;
		if (!empty($HELPDESK_SUPPORT_EMAIL_REPLY_ID) && $HELPDESK_SUPPORT_EMAIL_REPLY_ID !== 'support@company-name.com') {
			$defaultReplyToEmail = $HELPDESK_SUPPORT_EMAIL_REPLY_ID;
		} else {
			$cachedOutgoingFromEmail = VTCacheUtils::getOutgoingMailFromEmailAddress();
			if (empty($cachedOutgoingFromEmail)) {
				global $adb;
				$sql = 'SELECT from_email_field FROM vtiger_systems WHERE server_type=?';
				$result = $adb->pquery($sql, array('email'));
				$outgoingFromEamil = $adb->query_result($result, 0, 'from_email_field');
				if (empty($outgoingFromEamil)) {
					$activeAdmin = Users::getActiveAdminUser();
					$defaultReplyToEmail = $activeAdmin->email1;
				} else {
					$defaultReplyToEmail = $outgoingFromEamil;
					VTCacheUtils::setOutgoingMailFromEmailAddress($outgoingFromEamil);
				}
			} else {
				$defaultReplyToEmail = $cachedOutgoingFromEmail;
			}
		}
		return $defaultReplyToEmail;
	}

	function getDefaultFromEmail($fromName = null) {
		$defaultFromEmail = null;
		$cachedOutgoingFromEmail = VTCacheUtils::getOutgoingMailFromEmailAddress();
		if (empty($cachedOutgoingFromEmail)) {
			global $adb;
			$sql = 'SELECT from_email_field FROM vtiger_systems WHERE server_type=?';
			$result = $adb->pquery($sql, array('email'));
			$outgoingFromEamil = $adb->query_result($result, 0, 'from_email_field');
			if (empty($outgoingFromEamil)) {
				if ($fromName) {
					$userEmail = getUserEmailId('user_name', $fromName);
					$defaultFromEmail = $userEmail;
				}
				if (!$defaultFromEmail) {
					$activeAdminUser = Users::getActiveAdminUser();
					$defaultFromEmail = $activeAdminUser->email1;
				}
			} else {
				$defaultFromEmail = $outgoingFromEamil;
				VTCacheUtils::setOutgoingMailFromEmailAddress($outgoingFromEamil);
			}
		} else {
			$defaultFromEmail = $cachedOutgoingFromEmail;
		}
		return $defaultFromEmail;
	}

	function addCCAddress($mailerObj, $address, $isBCC = false) {
		$method = (!empty($isBCC)) ? 'AddBCC' : 'AddCC';
		if (!empty($address)) {
			$addresses = explode(',', trim($address, ','));
			foreach ($addresses as $cc) {
				$name = preg_replace('/([^@]+)@(.*)/', '$1', $cc); // First Part Of Email
				if (stripos($cc, '<')) {
					$nameAddrPair = explode('<', $cc);
					$name = $nameAddrPair[0];
					$cc = trim($nameAddrPair[1], '>');
				}
				if (!empty($cc)) {
					$mailerObj->$method($cc, $name);
				}
			}
		}
	}

}
?>


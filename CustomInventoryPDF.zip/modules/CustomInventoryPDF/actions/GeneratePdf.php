<?php
/* +***********************************************************************************
 * Custom PDF Generator for Sales Order
 * Author: Premnath Task
 * ***********************************************************************************/

class CustomInventoryPDF_GeneratePdf_Action extends Vtiger_Action_Controller {

    public function __construct() {
        parent::__construct();
        $this->exposeMethod('generate');
    }

    public function checkPermission(Vtiger_Request $request) {
        return true; // optionally add permission check for SalesOrder module
    }

    public function process(Vtiger_Request $request) {
	    global $site_URL ,$root_directory;
	$recordId = $request->get('record');
        $moduleName = 'SalesOrder';
        $recordModel = Vtiger_Record_Model::getInstanceById($recordId, $moduleName);

        if(!$recordModel) {
            $response = new Vtiger_Response();
            $response->setError(1, 'Invalid record');
            $response->emit();
            return;
        }

        // Dummy placeholders (replace with your actual SO fields)
        $patientName     = $recordModel->get('contact_id_display') ?: 'B.S.';
        $patientCode     = 'RFQ-' . str_pad($recordId, 5, '0', STR_PAD_LEFT);
        $bonNumber       = 'XXX-' . date('Y-m-d') . '-xxxx';
        $dateEmission    = date('d-m-Y');
        $dateExpiration  = date('d-m-Y', strtotime('+15 days'));
        $productName     = 'Product A';
        $pharmacyName    = 'Pharmacie DDFFR';

        // Folder setup
        $pdfFolder = $root_directory . 'storage/CustomPDFs/';
        if(!is_dir($pdfFolder)) mkdir($pdfFolder, 0777, true);
        $pdfFileName = 'SalesOrder_'.$recordId.'.pdf';
        $pdfFilePath = $pdfFolder . $pdfFileName;
	require_once('vtlib/Vtiger/PDF/TCPDF.php');
        $pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetTitle('Bon de Vente');
        $pdf->SetMargins(15, 15, 15,true);
        //$pdf->SetAutoPageBreak(TRUE, 15);
	
	$pdf->SetPrintHeader(false);
	$pdf->SetPrintFooter(false);
        $pdf->AddPage();

        // === HEADER ===
        $logoLeft  = $root_directory . 'layouts/v7/modules/CustomInventoryPDF/Images/avox_logo-Edited.png'; // placeholder
        $logoRight = $root_directory . 'layouts/v7/modules/CustomInventoryPDF/Images/arabic_logo-Edited.png'; // placeholder

        $pdf->Image($logoLeft, 15, 10, 30, '', '', '', 'T', false, 300);
        $pdf->Image($logoRight, 170, 10, 25, '', '', '', 'T', false, 300);
        $pdf->Ln(45);

        // Center heading text
        $pdf->SetFont('helvetica', '', 11);
        $pdf->MultiCell(0, 8, "Ce bon sera utilisé uniquement dans la pharmacie\ndésignée et pour ce programme", 0, 'C', 0, 1, '', '', true);
        $pdf->Ln(4);

        // BON NUM line
        $pdf->SetFont('helvetica', '', 12);
        $pdf->Cell(0, 8, 'BON NUM ' . $bonNumber, 0, 1, 'C');
        $pdf->Ln(5);

        // 100% big text
        $pdf->SetFont('helvetica', 'B', 30);
        $pdf->Cell(0, 20, '100%', 0, 1, 'C');
        $pdf->Ln(10);

        // === DETAILS TABLE ===
        $pdf->SetFont('helvetica', '', 11);
        $html = '
        <table border="1" cellpadding="6">
            <tr>
                <td width="40%"><b>Patient :</b></td>
                <td width="60%">'.$patientName.'</td>
            </tr>
            <tr>
                <td><b>Code du Patient :</b></td>
                <td>'.$patientCode.'</td>
            </tr>
            <tr>
                <td><b>Numéro de bon :</b></td>
                <td>'.$bonNumber.'</td>
            </tr>
            <tr>
                <td><b>Date d\'émission :</b></td>
                <td>'.$dateEmission.'</td>
            </tr>
            <tr>
                <td><b>Date d\'expiration :</b></td>
                <td>'.$dateExpiration.'</td>
            </tr>
            <tr>
                <td><b>Produit acheté :</b></td>
                <td>'.$productName.'</td>
            </tr>
            <tr>
                <td><b>Nom de la Pharmacie :</b></td>
                <td>'.$pharmacyName.'</td>
            </tr>
        </table>
        ';
        $pdf->writeHTML($html, true, false, false, false, '');
        $pdf->Ln(15);

        // === BOTTOM SIGNATURE TABLE ===
        $htmlBottom = '
        <table border="1" cellpadding="8">
            <tr style="font-weight:bold; text-align:center;">
                <td width="33%">Numéro du lot</td>
                <td width="33%">Date</td>
                <td width="34%">Signature</td>
            </tr>
            <tr>
                <td height="130"></td>
                <td></td>
                <td></td>
            </tr>
        </table>
        ';
        $pdf->writeHTML($htmlBottom, true, false, false, false, '');
        // Save file
	//$pdf->Output($pdfFilePath, 'F');
	$pdf->Output($pdfFileName,'D');
	
	exit;

	// Build public URL (use vtiger base URL)
        //global $site_URL;
        //$pdfUrl = $site_URL . $pdfFilePath;

        // Return JSON
        //$response = new Vtiger_Response();
       // $response->setResult(['result'=> true,'pdfpath' => $pdfUrl]);
        //$response->emit();
    }
}


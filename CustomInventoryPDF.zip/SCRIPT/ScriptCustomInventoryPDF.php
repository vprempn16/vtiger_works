<?php 
chdir('../');

include_once 'config.php';
//ini_set('display_errors','on'); error_reporting(E_ALL); // STRICT DEVELOPMENT
include_once 'config.php';
require_once 'vendor/autoload.php';
include_once 'include/Webservices/Relation.php';

include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';

class ScriptCustomInventoryPDF{

	function __construct(){
		$this->createModule();
		$this->insertHeaderLink();
	} 
	function insertHeaderLink(){
		global $adb;
		$linklabel = "CustomInventoryPDF";
		$linkurl = "layouts/v7/modules/CustomInventoryPDF/resources/CustomInventoryPDF.js";
		$result = $adb->pquery("SELECT * FROM vtiger_links WHERE linklabel = ? AND linkurl = ? ",array($linklabel,$linkurl));
		$num_rows = $adb->num_rows($result);
		if($num_rows == 0){
			$moduleName='Home';
			$moduleInstance = Vtiger_Module::getInstance($moduleName);
			$moduleInstance->addLink('HEADERSCRIPT', $linklabel,$linkurl);
			echo("Header Script Added<br/>");
		}else{
			echo("Header Script Already Present<br/>");
		}
	}
	function createModule(){
		$Vtiger_Utils_Log = true;

		$MODULENAME = 'CustomInventoryPDF';

		$moduleInstance = Vtiger_Module::getInstance($MODULENAME);
		if ($moduleInstance){
			echo "Module already present - choose a different name.";
		}else{
			$moduleInstance = new Vtiger_Module();
			$moduleInstance->name = $MODULENAME;
			$moduleInstance->label = 'CustomInventory PDF';
			$moduleInstance->parent= 'Tools';
			$moduleInstance->save();
		}
	}
}

$ScriptCustomInventoryPDF = new ScriptCustomInventoryPDF
?>

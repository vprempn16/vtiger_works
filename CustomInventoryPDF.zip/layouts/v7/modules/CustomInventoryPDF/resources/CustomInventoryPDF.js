jQuery.Class("CustomInventoryPDF_Js",{

	registerGeneratePdfButton : function() {
		var thisInstance = this;
		var currentModule = app.getModuleName();
		if (["SalesOrder"].indexOf(currentModule) === -1 || app.getViewName() != 'Detail') {
			return;
		}
		jQuery(document).on('click', '#generatePdfBtn', function(e){
			e.preventDefault();

			var recordId = app.getRecordId(); // Get current Sales Order ID
			if(!recordId) {
				app.helper.showErrorNotification({message: 'No record found.'});
				return;
			}
			        var pdfUrl = 'index.php?module=CustomInventoryPDF&action=GeneratePdf&record=' + recordId;
			        window.open(pdfUrl, '_blank');
			/*
			 *
			app.helper.showProgress();

			var params = {
				module: 'CustomInventoryPDF',
				action: 'GeneratePdf',
				record: recordId
			};

			app.request.post({data: params}).then(
				function(err, data) {
					app.helper.hideProgress();

					if(err === null && data && data.result) {
						var pdfUrl = data.pdfpath;
						if(pdfUrl) {
							//app.helper.showSuccessNotification({message: 'PDF Generated Successfully'});
							window.open(pdfUrl, '_blank'); // Open PDF in new tab
						} else {
							app.helper.showErrorNotification({message: 'PDF path not found!'});
						}
					} else {
						app.helper.showErrorNotification({message: 'Error generating PDF.'});
					}
				}
			);*/
		});
	},
	addGeneratePdfButton : function() {
		var thisInstance = this;
		var currentModule = app.getModuleName();
		if (["SalesOrder"].indexOf(currentModule) === -1 || app.getViewName() != 'Detail') {
			return;
		}
		setTimeout(function(){
			var editBtn = jQuery('.detailViewButtoncontainer #SalesOrder_detailView_basicAction_LBL_EDIT');
			if(editBtn.length > 0 && jQuery('#generatePdfBtn').length === 0) {
				var newBtn = jQuery('<button id="generatePdfBtn" class="btn btn-default"><i class="fa fa-file-pdf-o"></i> Generate PDF</button>');
				editBtn.after(newBtn);
			}

		}, 1000);
	},
	registerEvents : function(){
		var thisInstance = this;
		thisInstance.addGeneratePdfButton();
		thisInstance.registerGeneratePdfButton();
	}

});
jQuery(document).ready(function(e){
    var instance = new CustomInventoryPDF_Js();
    instance.registerEvents();
});


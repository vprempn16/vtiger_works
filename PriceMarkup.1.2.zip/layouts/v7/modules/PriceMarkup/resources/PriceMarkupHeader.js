jQuery.Class("PriceMarkupHeader_Js",{},{ 
    eventName : '',
    lineItemsHolder : false,
    taxTypeElement : false,
    numOfCurrencyDecimals : false,
    popupPageContentsContainer : false,
    loadCustomProductPopupExt : false,
    ListViewEntryClickExt : false,
    currencyElement : false,
    initializeVariables : function() { 
        this.lineItemsHolder = jQuery('#lineItemTab');
        this.taxTypeElement = jQuery('#taxtype');
         this.currencyElement = jQuery('#currency_id');
        this.numOfCurrencyDecimals = parseInt(jQuery('.numberOfCurrencyDecimal').val());
    },
    setEventName : function(eventName) {
        this.eventName = eventName;
    },
    getEventName : function() {
        return this.eventName;
    },
    getPopupPageContainer : function(){
        if(this.popupPageContentsContainer == false) {
            this.popupPageContentsContainer = $('body').find('#popupPageContainer'); 
        }
        return this.popupPageContentsContainer;

    },
    addColumnInPageLoad: function (){
        var clonerow = jQuery('#lineItemTab tr.lineItemCloneCopy');
        var cloneTd = clonerow.find('td').eq(1);
        var cloneQuantityTd = clonerow.find('td').eq(2);
        var pricehikeTd = clonerow.find(".atompricehike-td");
        var headTr = jQuery('#lineItemTab tbody tr').eq(0);
        var headQuantityTd = headTr.find('td').eq(2);
        var priceHikeHeader = headTr.find(".atom-pricehike-header");
        clonerow.append("<input type='hidden' name='atomsorgprice' value=''>");
        var previewSelector = 'span.atom-hike-preview';
        var sellingPriceInput = clonerow.find("input[name='listPrice0']");
        var preview = clonerow.find(previewSelector);
        if (priceHikeHeader.length === 0) {
            headQuantityTd.after('<td class="atom-pricehike-header"><strong>Price Markup</strong></td>');
        }
        if(pricehikeTd.length === 0){
            cloneQuantityTd.after('<td style="width:300px;" class="atompricehike-td"><input type="text" name="atompricehike" value="" class="smallInputBox inputElement"> </td>');
        }

        if(preview.length === 0){
           sellingPriceInput.before('<div style="font-size: 11px; color: #888;"><span class="atom-hike-preview" ></span> </div>');
            }

        var thisInstance = this;
        var currentModule = app.getModuleName();
        if (["Invoice", "SalesOrder", "Quotes","PurchaseOrder"].indexOf(currentModule) === -1  && app.getViewName() != 'Edit') {
            return;
        }
        var recordId = jQuery("input[name='record']").val();
        if(recordId === ""){
            var url = window.location.href;
            var params = new URLSearchParams(url.split('?')[1]);
            recordId = ['invoice_id', 'quote_id', 'salesorder_id', 'purchaseorder_id','record'].map(p => new URLSearchParams(window.location.search).get(p)).find(Boolean);
        }

        if(!recordId) {
            return;
        }
        var params = {
            module: "PriceMarkup",
            action: "GetLineItemVariantDetails",
            record: recordId,
        };
        app.helper.showProgress();
        app.request.post({ data: params }).then(
        function(err, data) {
            app.helper.hideProgress();
                if (err === null && data.success === true) { 
                    var variantData = JSON.parse(data.variantDetails);
                    var global_pricehike = parseFloat(variantData.globalpricehike || 0);
                    jQuery(".global-pricehike-wrapper").find("#global_pricehike").val(global_pricehike);
                    jQuery("table#lineItemTab tbody tr").each(function() {
                            var lineItemRow = jQuery(this);
                            var rowNum = lineItemRow.attr("data-row-num"); // Get row number (1,2,3...)
                            var atomsorgprice = "atomsorgprice"+rowNum
                            var basePrice = lineItemRow.find("input[name='listPrice" + rowNum + "']").val();
                            if(rowNum != undefined && rowNum != 0){
                                var productInput = jQuery("input[name='hdnProductId" + rowNum + "']"); // Find Product ID field
                                var productId = productInput.val();
                                var quantityTd = lineItemRow.find('td').eq(2);
                                if (lineItemRow.find(".atompricehike-td").length === 0) {
                                    var savedHikeInput = lineItemRow.find("input[name='atompricehike" + rowNum + "']");
                                    var savedValue = savedHikeInput.length ? savedHikeInput.val() : '';
                                    quantityTd.after('<td class="atompricehike-td"><input type="text" name="atompricehike' + rowNum + '" value="' + savedValue + '" class="smallInputBox inputElement"></td>');
                                }

                                if (!productId) {
                                    return; 
                                }
                                var matchedVariant = null;
                                if (variantData[rowNum].productid == productId ) {
                                        matchedVariant = variantData[rowNum];
                                }
				var pricehike = parseFloat(matchedVariant.pricehike);
				if (isNaN(pricehike)) {
				    pricehike = parseFloat(global_pricehike) || 0;
				}
                               // var listPirce =  parseFloat(matchedVariant.atomorgprice || matchedVariant.listprice || 0).toFixed(2);
				var listPriceNum = parseFloat(matchedVariant.atomorgprice || matchedVariant.listprice || 0) || 0;    
                                lineItemRow.find("input[name='atomsorgprice']").remove();
                                lineItemRow.append("<input type='hidden' name='"+ atomsorgprice +"'  value='" + listPriceNum + "'>");
                                lineItemRow.find(".atompricehike-td").find("input[name='atompricehike"+rowNum+"']").val(pricehike);
                                var previewSelector = 'span.atom-hike-preview';
                                var sellingPriceInput = lineItemRow.find("input[name='listPrice" + rowNum + "']");
                                var preview = lineItemRow.find(previewSelector);
                                //var newPrice = listPirce + (listPirce * pricehike / 100);
                                //newPrice = newPrice.toFixed(2);
				//var markupAmount = (listPirce * pricehike / 100).toFixed(2);
                                //var newPrice = parseFloat(listPirce + markupAmount).toFixed(2);
				var markupAmountNum = (listPriceNum * pricehike / 100);
				var newPriceNum = listPriceNum + markupAmountNum;

				var listPirce = listPriceNum.toFixed(2);
				var markupAmount = markupAmountNum.toFixed(2);
				var newPrice = newPriceNum.toFixed(2);
				if(preview.length === 0){
                                     sellingPriceInput.before('<div style="font-size: 11px; color: #888;"><span class="atom-hike-preview"></span> </div>');
                                     preview = lineItemRow.find(previewSelector);
                                }
                                //var previewText = pricehike + '% of '+listPirce +' + ' + listPirce + ' = ' + newPrice;
                                //var previewText = 'Markup = ' + markupAmount + ' + Price = ' + listPirce + ' = ' + newPrice; 
				var previewText = 'Markup = ' + markupAmount + ' + Price = ' + listPirce + ' = ' + newPrice;
				    console.log(previewText );
				preview.text(previewText);
                            }
                    });
                }
        }); 
    },
    showPriceHikeInDetailView : function(){
        var thisInstance = this;
            var url = window.location.href;
            var params = new URLSearchParams(url.split('?')[1]);
            var currentModule = app.getModuleName();
            if (["Invoice", "SalesOrder", "Quotes","PurchaseOrder" ].indexOf(currentModule) === -1  && app.getViewName() != 'Detail' && params.get('requestMode') != 'full'){
                return;
            }
            var headTr = jQuery('.lineItemsTable tbody tr').eq(0);
            jQuery('.lineItemTableDiv .lineItemsTable thead tr th').eq(0).after("<th class='lineItemBlockHeader global-pricehike-head'>Price Markup : </th>");
            var headTd = headTr.find('td').eq(0);
            var quantityHead = headTr.find('td').eq(1);
            if(headTr.find('.pricehike-header').length === 0){
                quantityHead.after('<td class="pricehike-header" ><strong>Price Markup </strong></td>');
            }
            var recordId = jQuery("input#recordId").val();
            if (!recordId) {
                return;
            }
            var params = {
                module: "PriceMarkup",
                action: "GetLineItemVariantDetails",
                record: recordId,
            };
            app.helper.showProgress();
            app.request.post({ data: params }).then(
            function(err, data) {
                app.helper.hideProgress();
                    if (err === null && data.success === true) {   
                    var variantData = JSON.parse(data.variantDetails);
                    var i = 0;
                    var global_pricehike = parseFloat(variantData.globalpricehike || 0);
                    jQuery(".lineItemTableDiv table.lineItemsTable tbody tr").each(function() {
                            var lineItemRow = jQuery(this);
                            var rowNum = lineItemRow.attr("data-row-num"); 
                            if(i != 0){
                                var pricehikeTd = lineItemRow.find(".pricehike-value");

                                if (pricehikeTd.length === 0) {
                                    lineItemRow.find("td").eq(1).after('<td class="pricehike-value"></td>');
                                    pricehikeTd = lineItemRow.find(".pricehike-value");
                                }
                                var matchedVariant = {};
                                if(variantData[i]){
                                        matchedVariant = variantData[i];
                                }
                                var tdfieldValue = lineItemRow.find("td").eq(0).find('a.fieldValue');
                                var productUrl = tdfieldValue.attr('href');
                                var productParams = new URLSearchParams(productUrl.split('?')[1]);
                                var productRecordId = productParams.get('record'); 
                                if (productRecordId == matchedVariant.productid) {
                                    var pricehikeValue = parseFloat(matchedVariant.pricehike);
                                    if(pricehikeValue == ''){
                                         pricehikeValue = parseFloat(global_pricehike || 0);
                                    }
                                    var listPriceText = matchedVariant.atomorgprice;
                                    var listPrice = parseFloat(listPriceText);
                                    if (!isNaN(pricehikeValue) && !isNaN(listPrice)) {
                                        var increased = ((pricehikeValue / 100) * listPrice).toFixed(2);
                                        var finalPrice = (listPrice + parseFloat(increased)).toFixed(2);
                                        var previewHtml = `<div style="font-size: 11px; color: #888;"><span class="atom-hike-preview"> ${pricehikeValue}% of ${listPrice} + ${listPrice} = ${finalPrice}</span> </div>`;
                                        var priceTd = lineItemRow.find("td").eq(3); 
                                        if(priceTd.find('.atom-hike-preview').length === 0) {
                                            priceTd.prepend(previewHtml);
                                        }
                                    }
                                    pricehikeTd.text(pricehikeValue); 
                                }
                            }
                            i++;
                     });
                     $('.global-pricehike-head').text(`Price Markup : ${global_pricehike}`);
                }
            });
    }, 
    loadCustomProductPopup: function () {
        var thisInstance = this;
        if(!thisInstance.loadCustomProductPopupExt){
        thisInstance.loadCustomProductPopupExt = true;
        thisInstance.lineItemsHolder.on('click','.lineItemPopupVariant',function(e){
            if ( app.getModuleName() === "SalesOrder" || app.getModuleName() === "Invoice" || app.getModuleName() === "Quotes" ){
                var triggerer = jQuery(e.currentTarget);
                thisInstance.showLineItemPopup({'view': triggerer.data('popup')});
                var popupReferenceModule = triggerer.data('moduleName');
                var variantinfo = {};
                var postPopupHandler = function(e, data){ 
                    data = JSON.parse(data);
                    if(!$.isArray(data)){
                        data = [data];
                    }
                     thisInstance.postLineItemSelectionActions(triggerer.closest('tr'), data, popupReferenceModule);
                    thisInstance.showVariantDetailsInLineItem(triggerer.closest('tr'), data, popupReferenceModule );
                }
                app.event.off('post.LineItemPopupSelection.click');
                app.event.one('post.LineItemPopupSelection.click', postPopupHandler);
                vtUtils.showSelect2ElementView(jQuery("#popupModal").find(".modal-content select.select2"));
            }
        });
        }
    }, 
    postLineItemSelectionActions : function(itemRow, selectedLineItemsData, lineItemSelectedModuleName ){
         for(var index in selectedLineItemsData) {
            if(index != 0) {
                if(lineItemSelectedModuleName == 'Products') {
                    jQuery('#addProduct').trigger('click', selectedLineItemsData[index]);
                }
            }else{
                itemRow.find('.lineItemType').val(lineItemSelectedModuleName);
                var inventeryInstance =  new Inventory_Edit_Js();
                inventeryInstance.mapResultsToFields(itemRow, selectedLineItemsData[index]);
            }
        }
    },
    showVariantDetailsInLineItem : function(itemRow,data,lineItemSelectedModuleName  ){
       if(data != undefined){
        var rowNum = itemRow.attr('data-row-num');
        var atomsorgprice = "atomsorgprice"+rowNum;
        var headTr = jQuery('#lineItemTab tbody tr').eq(0);
        var cloneQuantityTd = itemRow.find('td').eq(2);
        var pricehikeTd = itemRow.find(".atompricehike-td");

        var headTd = headTr.find('td').eq(1);
        var rowtd = jQuery('input.productName', itemRow).closest('td');
        var headQuantityTd = headTr.find('td').eq(2);
        var priceHikeHeader = headTr.find(".atom-pricehike-header");
        var basePrice= itemRow.find("input[name='listPrice" + rowNum + "']").val();
        console.log(data,'showVariantDetailsInLineItem');
        if(priceHikeHeader.length === 0){
                headQuantityTd.after('<td class="atom-pricehike-header"><strong>Price Markup</strong></td>');
        }
        if(pricehikeTd.length === 0){
            cloneQuantityTd.after('<td style="width:300px;" class="atompricehike-td"><input type="text" name="atompricehike0" value="" class="smallInputBox inputElement"> </td>');
        }   
        
        if( itemRow.find("input[name='atomsorgprice']").length){
            itemRow.find("input[name='atomsorgprice']").remove();
        }
        if(  itemRow.find("input[name='atomsorgprice"+rowNum+"']").length){
            itemRow.find("input[name='atomsorgprice"+rowNum+"']").remove();
        }
        if(itemRow.find("input[name='atompricehike0']").length){
            itemRow.find("input[name='atompricehike0']").remove();
            pricehikeTd.append('<input type="text" name="atompricehike'+rowNum+'" value="" class="smallInputBox inputElement">'); 
        }
        itemRow.append("<input type='hidden' name='"+atomsorgprice+"' value='" + basePrice + "'>");
        }
    },
    showLineItemPopup : function(callerParams){    
        var params = {
            'module' : app.module(),
            'multi_select' : true,
            'currency_id' : this.currencyElement.val()
        };
        params = jQuery.extend(params, callerParams);
        var popupInstance = Vtiger_Popup_Js.getInstance();
        popupInstance.showPopup(params, 'post.LineItemPopupSelection.click');
    
    },
    registerEventForListViewEntryClick : function(){
        var thisInstance = this;
       // if(!thisInstance.ListViewEntryClickExt){
            thisInstance.ListViewEntryClickExt = true;
            var popupPageContentsContainer = this.getPopupPageContainer();

            //popupPageContentsContainer.off('click', '.listViewVariantEntries');
            //popupPageContentsContainer.on('click','.listViewVariantEntries',function(e){
            $('body').on('click','.listViewPriceEntries',function(e){
        	console.log(e,'showVariantDetailsInLineItem');
                thisInstance.getListViewEntries(e);
            });
        //}
    },
    getListViewEntries: function(e){
        e.preventDefault();
        var preEvent = jQuery.Event('pre.popupSelect.click');
        app.event.trigger(preEvent);
        if(preEvent.isDefaultPrevented()){
            return;
        }
        var thisInstance = this;
        var row  = jQuery(e.currentTarget);
        var dataUrl = row.data('url');
        var variantInfo = row.data('variantinfo');
        var variantid = row.data('variantid');
        if(typeof dataUrl != 'undefined'){
            dataUrl = dataUrl+'&currency_id='+jQuery('#currencyId').val();

            app.request.post({"url":dataUrl}).then(function(err,data){
                    for(var id in data){
                        if(typeof data[id] == "object"){
                            var recordData = data[id];
                        }
                    }
                    for(var id in data){
                         if(typeof data[id] == "object"){
                            var record = data[id];
                            for(var prodid in record){
                                record = record[prodid];
                                record.variantinfo = variantInfo;
                                record.variantid = variantid;
                            }
                        }
                    }
        console.log(data,'showVariantDetailsInLineItem');
                thisInstance.done(data,thisInstance.getEventName());
            });
                         e.preventDefault();
        } else {
            var id = row.data('id');
            var recordName = row.attr('data-name');
            var recordInfo = row.data('info');
            var referenceModule = jQuery('#popupPageContainer').find('#module').val();
            var response ={};
            response[id] = {'name' : recordName,'info' : recordInfo, 'module' : referenceModule};
            thisInstance.done(response,thisInstance.getEventName());
            e.preventDefault();
        }
    },
    done : function(result,eventToTrigger){
        var event = "post.popupSelection.click";
        if(typeof eventToTrigger !== 'undefined'){
            event = eventToTrigger;
        }
        if(typeof event == 'function') {
            event(JSON.stringify(result));
        } else {
            app.event.trigger(event, JSON.stringify(result));
        }
        app.helper.hidePopup();
    },
    calculateListPrice : function(){ 
                            jQuery(document).on('input', 'input[name^="listPrice"]', function () {
                                     var listPriceInput = jQuery(this);
                                     var row = listPriceInput.closest('tr');
                                     var rowNum = row.attr('data-row-num');

                                     if (!rowNum) return;

                                     var newOriginalPrice = parseFloat(listPriceInput.val());
                                     if (isNaN(newOriginalPrice)) return;

                                     var newPrice = parseFloat(listPriceInput.val());
				     var hikePercent = parseFloat(row.find('.atompricehike-td input').val());
				     if(hikePercent == '' || hikePercent == 0 ){	
                                       hikePercent = parseFloat(jQuery('#global_pricehike').val() || 0);
				     }
                                     var newOriginalPrice = newPrice / (1 + hikePercent / 100);
                                     newOriginalPrice = newOriginalPrice.toFixed(2);
				     var markupAmount = parseFloat((newPrice - newOriginalPrice));
					markupAmount = markupAmount.toFixed(2);
					newPrice = newPrice.toFixed(2);
                                     var originalPriceInput = row.find("input[name='atomsorgprice" + rowNum + "']");
                                     if (originalPriceInput.length > 0) {
                                        originalPriceInput.val(newOriginalPrice);
                                     } else {
                                     row.append("<input type='hidden' name='atomsorgprice" + rowNum + "' value='" + newOriginalPrice + "'>");

                                    }                                  
                                    var priceCell = listPriceInput.closest('td');
                                    var previewSelector = 'span.atom-hike-preview';
                                    var preview = priceCell.find(previewSelector);

                                    if (preview.length === 0) {
                                        priceCell.prepend('<div style="font-size: 11px; color: #888;"><span class="atom-hike-preview" ></span></div>');
                                        preview = priceCell.find(previewSelector);
                                    }
                                    //var previewText = hikePercent + '% of '+newOriginalPrice+' + ' + newOriginalPrice + ' = ' + newPrice;
                                     var previewText = 'Markup = ' + markupAmount + ' + Price = ' + newOriginalPrice + ' = ' + newPrice;
				    preview.text(previewText);

                             });
                             jQuery(document).on('input', '.atompricehike-td input', function () {
                                     var priceHikeInput = jQuery(this);
                                     var row = priceHikeInput.closest('tr');
                                     var rowNum = row.attr('data-row-num');

                                     if (!rowNum) return;

                                     var originalPrice = parseFloat(row.find("input[name='atomsorgprice" + rowNum + "']").val());
                                     if (isNaN(originalPrice)) return;

                                     var hikePercent = parseFloat(priceHikeInput.val());
                                     if (isNaN(hikePercent)) hikePercent = 0;

                                     //var newPrice = originalPrice + (originalPrice * hikePercent / 100);
                                     //newPrice = newPrice.toFixed(2);
				     var markupAmount = (originalPrice * hikePercent / 100);
                                     var newPrice = originalPrice + markupAmount;
				     newPrice = newPrice.toFixed(2);
                                     var listPriceInput = row.find("input[name='listPrice" + rowNum + "']");
                                     
				     //var sellingPriceInput = row.find("input[name='listPrice" + rowNum + "']");
                                     listPriceInput.val(newPrice).blur();
                                     var priceCell = listPriceInput.closest('td');
                                     var previewSelector = 'span.atom-hike-preview';
                                     var preview = row.find(previewSelector);

                                     if (preview.length === 0) {
                                        // sellingPriceInput.before('<div class="atom-hike-preview" style="font-size: 11px; color: #888;"></div>');
                                        // preview = row.find(previewSelector);
                                         priceCell.prepend('<div style="font-size: 11px; color: #888;"><span  class="atom-hike-preview" ></span> </div>');
                                         preview = priceCell.find(previewSelector);

                                     }
                                     //var previewText = hikePercent + '% of '+originalPrice+' + ' + originalPrice + ' = ' + newPrice;
				     var previewText = 'Markup = ' + markupAmount.toFixed(2) + ' + Price = ' + originalPrice.toFixed(2) + ' = ' + newPrice;
                                     preview.text(previewText);
                             });

                         },
                         appendGlobalPriceHikeField : function() {
                            jQuery('.well .row .col-sm-4').each(function () {
                                jQuery(this).removeClass('col-sm-4').addClass('col-sm-3');
                            });

/*
                             var currencyContainer = jQuery("label:contains('Tax Region')")
                                 .closest('.col-sm-3');
*/
                             var wrappercontainer = jQuery('.well .row');
                             var $firstCol = wrappercontainer.find('.col-sm-3').first();

                             if (jQuery('.global-pricehike-wrapper').length > 0) return;

                             var globalPriceHikeHtml = `
                                 <div class="col-sm-3 global-pricehike-wrapper">
                                 <div class="pull-right">
                                 <i class="fa fa-info-circle"></i>&nbsp;
                                 <label>Price Markup (%)</label>
                                 <input type="text" class="smallInputBox inputElement" id="global_pricehike"
                                 name="global_pricehike" style="width: 100px;"  />
                                 </div>
                                 </div>
                                 `;

                                 $firstCol.after(globalPriceHikeHtml);
                                 jQuery(document).on('input', '#global_pricehike', function () {
                                         var hikePercent = parseFloat(jQuery(this).val());
                                         if (isNaN(hikePercent)) hikePercent = 0;

                                         jQuery("table#lineItemTab tbody tr").each(function () {
                                                 var row = jQuery(this);
                                                 var rowNum = row.attr("data-row-num");

                                                 if (!rowNum || rowNum == "0") return;

                                                 var originalPrice = parseFloat(row.find("input[name='atomsorgprice" + rowNum + "']").val());

                                                 console.log(rowNum,hikePercent,originalPrice);
                                                 if (isNaN(originalPrice)) return;

                                                 //var newPrice = originalPrice + (originalPrice * hikePercent / 100);
                                                 //newPrice = newPrice.toFixed(2);
						 var markupAmount = (originalPrice * hikePercent / 100);
        					 var newPrice = originalPrice + markupAmount;
						 newPrice = newPrice.toFixed(2);

                                                 var listPriceInput = row.find("input[name='listPrice" + rowNum + "']");
                                                 listPriceInput.val(newPrice).blur();

                                                 var priceCell = listPriceInput.closest('td');
                                                 var previewSelector = 'span.atom-hike-preview';
                                                 var preview = priceCell.find(previewSelector);

                                                 if (preview.length === 0) {
                                                  priceCell.prepend('<div style="font-size: 11px; color: #888;"><span class="atom-hike-preview"></span> </div>');
                                                  preview = priceCell.find(previewSelector);
                                                 }

                                                 //var previewText = hikePercent + '% of ' + originalPrice + ' + ' + originalPrice + ' = ' + newPrice;
                                                 var previewText = 'Markup = ' + markupAmount.toFixed(2) + ' + Price = ' + originalPrice.toFixed(2) + ' = ' + newPrice;

						 preview.text(previewText);
						 row.find("input[name='atompricehike" + rowNum + "']").val(hikePercent);
                                         });
                            });
                         },
	updateRowPreview : function(lineItemRow) {
		var previewSelector = 'span.atom-hike-preview';
		var sellingPriceInput = lineItemRow.find("input.listPrice");
		var preview = lineItemRow.find(previewSelector);
		var rowNum = lineItemRow.attr('data-row-num');
		var global_pricehike = jQuery(".global-pricehike-wrapper").find("#global_pricehike").val();
		var pricehike = parseFloat(lineItemRow.find('.atompricehike-td input').val());
		if (isNaN(pricehike)) {
			pricehike = parseFloat(global_pricehike) || 0;
		}
		var recordId = jQuery("input[name=hdnProductId"+rowNum+"]").val();
		if(!recordId) {
			return;
		}
		var params = {
			module: "PriceMarkup",
			action: "GetBasePrice",
			record: recordId,
		};
		app.request.get({ data: params }).then(
			function(err, data) {
				console.log(data,typeof data);
				if (err === null && data.success === true) {
					var basePrice = parseFloat(data.baseprice) || 0;

					// Get conversion rate for the selected currency (from hidden field or table)
					conversionRate = parseFloat(jQuery('#conversion_rate').val()) || 1;

					// Convert base price to selected currency
					var convertedOrgPrice = basePrice * conversionRate;

					// Update atomorgprice field
					var atomorgprice = 'atomsorgprice'+rowNum;
					lineItemRow.find("input[name="+atomorgprice+"]").val(convertedOrgPrice.toFixed(2));

					// Calculate markup & new price
					var markupAmountNum = (convertedOrgPrice * pricehike / 100);
					var newPriceNum = convertedOrgPrice + markupAmountNum;

					var listPrice = convertedOrgPrice.toFixed(2);
					var markupAmount = markupAmountNum.toFixed(2);
					var newPrice = newPriceNum.toFixed(2);

					// Insert preview if not exists
					if (preview.length === 0) {
						sellingPriceInput.before('<div style="font-size: 11px; color: #888;"><span class="atom-hike-preview"></span></div>');
						preview = lineItemRow.find(previewSelector);
					}

					var previewText = 'Markup = ' + markupAmount + ' + Price = ' + listPrice + ' = ' + newPrice;
					preview.text(previewText);
					
				}
			});
	},

		currencyOnchange : function(){ 
			var thisInstance =  this;
			$(document).on('change', 'select[name="currency_id"]', function () {
				setTimeout(function () {
					$(".lineItemRow").each(function () {
						thisInstance.updateRowPreview($(this));
					});
				}, 300); 
			});
	
		}, 
    registerEvents : function(){
        var thisInstance = this;
        thisInstance.initializeVariables();
    }
});
jQuery(document).ready(function(e){
        var instance = new PriceMarkupHeader_Js();
        instance.registerEvents();
        instance.loadCustomProductPopup();
        instance.addColumnInPageLoad();
        //instance.showPriceHikeInDetailView();
        instance.calculateListPrice();
        instance.appendGlobalPriceHikeField();
	instance.currencyOnchange();
        app.event.on("post.Popup.Load",function(event,params){
	console.log(params,'Popup.Load',$('#popupContentsDiv').find('.listViewEntriesTable').find('.listViewEntries'));
            $('#popupContentsDiv').find('.listViewEntriesTable').find('.listViewEntries').removeClass('listViewEntries').addClass('listViewPriceEntries');
		var eventToTrigger = params.eventToTrigger;
            if(typeof eventToTrigger != "undefined"){
                instance.setEventName(params.eventToTrigger);
                instance.registerEventForListViewEntryClick();
           }
        });
        $(document).ajaxComplete(function( event,xhr,settings ){
            if (settings.hasOwnProperty("url") ){
                var url =settings.url;
                if(url != ''){
                    var params = new URLSearchParams(url.split('?')[1]);
                    var module =  params.get('module');
                    var requestMode = params.get('requestMode');
                    var view = params.get('view');
                    if(requestMode == 'full' && view == 'Detail'){
                        //instance.showPriceHikeInDetailView();
                    }
                }
            }

        });
});

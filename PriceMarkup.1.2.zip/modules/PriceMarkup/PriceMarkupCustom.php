<?php 
class PriceMarkupCustom{
    public function postEnable(){
        $this->addHeaderJs();
        $this->eventhandler();
    }
    public function postInstall(){
        $this->createInventoryFields();
        $this->addHeaderJs();
        $this->eventhandler();
    }
    public function postDisable(){
        global $adb;
        $this->removeHeaderJs();
        $this->unregisterEventHandler();
    }
    public function postUpdate(){
        $this->rmvField();
        $this->createInventoryFields();
    } 
    public function addHeaderJs(){
        global $adb;
        $linklabel = "PriceMarkupHeader";
        $linkurl = "layouts/v7/modules/PriceMarkup/resources/PriceMarkupHeader.js";
        $result = $adb->pquery("SELECT * FROM vtiger_links WHERE linklabel = ? AND linkurl = ? ",array($linklabel,$linkurl));
        $num_rows = $adb->num_rows($result);
        if($num_rows == 0){
            $moduleName='Home';
            $moduleInstance = Vtiger_Module::getInstance($moduleName);
            $moduleInstance->addLink('HEADERSCRIPT', $linklabel,$linkurl);
        }
    }
    public function removeHeaderJs(){
        $linklabel = "PriceMarkupHeader";
        $linkurl = "layouts/v7/modules/PriceMarkup/resources/PriceMarkupHeader.js";
        Vtiger_Link::deleteLink( 3 , 'HEADERSCRIPT' , $linklabel , $linkurl );
    }
    public function eventhandler(){
        $Vtiger_Utils_Log = true;
        include_once('vtlib/Vtiger/Event.php');
        Vtiger_Event::register('Vtiger', 'vtiger.entity.aftersave', 'PriceMarkupHandler', 'modules/PriceMarkup/PriceMarkupHandler.php');
    }
    public function unregisterEventHandler(){
        global $adb;
        $Vtiger_Utils_Log = true;
        include_once('include/events/VTEventsManager.inc');
        $class = 'PriceMarkupHandler';    
        $result  = $adb->pquery('SELECT * FROM vtiger_eventhandlers WHERE handler_class =?',array($class));
        if($adb->num_rows($result) > 0){
            $eventsManager = new VTEventsManager($adb);
            $result = $eventsManager->unregisterHandler($class);
            return "success";
        }else{
            return "handler not found";
        }
    }
    public function createInventoryFields(){
        $modules = ["Invoice","SalesOrder","Quotes","PurchaseOrder"];
        foreach($modules as $module){
            $moduleName = $MODULENAME = $module;
            $moduleInstance = Vtiger_Module::getInstance($moduleName);
            $blockInstance = new Vtiger_Block();
            $blockInstance->label = 'LBL_ITEM_DETAILS';
            $blockInstance = $blockInstance->getInstance($blockInstance->label,$moduleInstance);
            $field5 = Vtiger_Field::getInstance("atomorgprice",$moduleInstance);
            if(!$field5 ){
                $field5 = new Vtiger_Field();
                $field5->name = "atomorgprice";
                $field5->label = "Original Price";
                $field5->column = "atomorgprice";
                $field5->columntype = 'VARCHAR(250)';
                $field5->table  ='vtiger_inventoryproductrel';
                $field5->uitype = 1;
                $blockInstance->addField($field5);
            }
	    $field4 = Vtiger_Field::getInstance("atompricehike",$moduleInstance);
	    if(!$field4 ){
		    $field4 = new Vtiger_Field();
		    $field4->name = "atompricehike";
		    $field4->label = "Price Hike";
		    $field4->column = "atompricehike";
		    $field4->columntype = 'VARCHAR(250)';
		    $field4->table  ='vtiger_inventoryproductrel';
		    $field4->uitype = 1;
		    $blockInstance->addField($field4);
	    }	
            $field6 = Vtiger_Field::getInstance("atomglobalpricehike",$moduleInstance);
            if(!$field6 ){
                $field6 = new Vtiger_Field();
                $field6->name = "atomglobalpricehike";
                $field6->label = "Global Price Hike";
                $field6->column = "atomglobalpricehike";
                $field6->columntype = 'VARCHAR(250)';
                $field6->uitype = 1;
                $blockInstance->addField($field6);
            }
        }
    }
     function rmvField(){
        $moduleInstance = new Vtiger_Module();
        $modules =   ["Invoice","SalesOrder","Quotes","PurchaseOrder"];
        foreach($modules as $module){
            $moduleInstance = Vtiger_Module::getInstance ($module );
            $fields = array('atomglobalpricehike');
            foreach($fields as $field){
                $fieldInstance = Vtiger_Field::getInstance ( $field, $moduleInstance );
                if ($fieldInstance) {
                    $fieldInstance->delete();
                }
            }
        }
    }
}


?>
